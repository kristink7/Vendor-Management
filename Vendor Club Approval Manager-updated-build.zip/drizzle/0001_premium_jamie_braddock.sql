CREATE TABLE `access_attempts` (
	`identifier` text PRIMARY KEY NOT NULL,
	`failures` integer NOT NULL,
	`window_started` text NOT NULL,
	`locked_until` text
);
--> statement-breakpoint
CREATE TABLE `access_invites` (
	`email` text PRIMARY KEY NOT NULL,
	`role` text NOT NULL,
	`code_hash` text NOT NULL,
	`code_hint` text NOT NULL,
	`status` text NOT NULL,
	`expires_at` text,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`last_used_at` text,
	`created_by` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `access_sessions` (
	`id_hash` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`role` text NOT NULL,
	`created_at` text NOT NULL,
	`expires_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `access_sessions_email_idx` ON `access_sessions` (`email`);--> statement-breakpoint
CREATE INDEX `access_sessions_expires_idx` ON `access_sessions` (`expires_at`);
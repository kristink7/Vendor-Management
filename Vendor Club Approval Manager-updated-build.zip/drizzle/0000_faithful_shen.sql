CREATE TABLE `access_contacts` (
	`email` text PRIMARY KEY NOT NULL,
	`display_name` text NOT NULL,
	`permission` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `campus_assignments` (
	`campus` text PRIMARY KEY NOT NULL,
	`state` text NOT NULL,
	`contact_name` text NOT NULL,
	`contact_role` text NOT NULL,
	`email` text NOT NULL,
	`asana_gid` text NOT NULL,
	`updated_at` text NOT NULL
);

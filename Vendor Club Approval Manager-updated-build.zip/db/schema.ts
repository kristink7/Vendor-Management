import { index, integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const accessContacts = sqliteTable("access_contacts", {
  email: text("email").primaryKey(),
  displayName: text("display_name").notNull(),
  permission: text("permission", {
    enum: ["Executive", "Procurement", "Accounting"],
  }).notNull(),
  updatedAt: text("updated_at").notNull(),
});

export const campusAssignments = sqliteTable("campus_assignments", {
  campus: text("campus").primaryKey(),
  state: text("state").notNull(),
  contactName: text("contact_name").notNull(),
  contactRole: text("contact_role").notNull(),
  email: text("email").notNull(),
  asanaGid: text("asana_gid").notNull(),
  updatedAt: text("updated_at").notNull(),
});

export const accessInvites = sqliteTable("access_invites", {
  email: text("email").primaryKey(),
  role: text("role", { enum: ["admin", "user"] }).notNull(),
  codeHash: text("code_hash").notNull(),
  codeHint: text("code_hint").notNull(),
  status: text("status", { enum: ["active", "revoked"] }).notNull(),
  expiresAt: text("expires_at"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
  lastUsedAt: text("last_used_at"),
  createdBy: text("created_by").notNull(),
});

export const accessSessions = sqliteTable(
  "access_sessions",
  {
    idHash: text("id_hash").primaryKey(),
    email: text("email").notNull(),
    role: text("role", { enum: ["admin", "user"] }).notNull(),
    createdAt: text("created_at").notNull(),
    expiresAt: text("expires_at").notNull(),
  },
  (table) => [
    index("access_sessions_email_idx").on(table.email),
    index("access_sessions_expires_idx").on(table.expiresAt),
  ],
);

export const accessAttempts = sqliteTable("access_attempts", {
  identifier: text("identifier").primaryKey(),
  failures: integer("failures").notNull(),
  windowStarted: text("window_started").notNull(),
  lockedUntil: text("locked_until"),
});

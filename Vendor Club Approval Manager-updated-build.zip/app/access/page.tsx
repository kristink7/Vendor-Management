import { headers } from "next/headers";
import { redirect } from "next/navigation";
import AccessGate from "@/app/components/AccessGate";
import { getSessionFromCookieHeader } from "@/app/lib/auth-store";

export const dynamic = "force-dynamic";

export default async function AccessPage() {
  const requestHeaders = await headers();
  const session = await getSessionFromCookieHeader(requestHeaders.get("cookie"));
  if (session) redirect("/");
  return <AccessGate />;
}

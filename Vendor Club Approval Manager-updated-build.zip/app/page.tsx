import { headers } from "next/headers";
import { redirect } from "next/navigation";
import VendorClubManager from "./components/VendorClubManager";
import { accessForEmailWithDirectory } from "./lib/access";
import { getSessionFromCookieHeader } from "./lib/auth-store";
import { getAssignmentDirectory } from "./lib/assignment-store";

export const dynamic = "force-dynamic";

export default async function Home() {
  const requestHeaders = await headers();
  const session = await getSessionFromCookieHeader(requestHeaders.get("cookie"));
  if (!session) redirect("/access");

  const email = session.email;
  const directory = await getAssignmentDirectory();
  const access = accessForEmailWithDirectory(email, directory);

  return (
    <VendorClubManager
      currentUserName={access.displayName}
      currentUserEmail={email}
      isSystemAdmin={access.isSystemAdmin}
      isExecutive={access.isExecutive}
      canTakeAction={access.canTakeAction}
      actionRole={access.actionRole}
      allowedCampuses={access.allowedCampuses}
      asanaUserGids={access.asanaUserGids}
      accessLabel={access.accessLabel}
      initialDirectory={directory}
    />
  );
}

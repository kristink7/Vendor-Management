import {
  deleteAccessContact,
  getAssignmentDirectory,
  saveAccessContact,
  saveCampusAssignment,
} from "@/app/lib/assignment-store";
import {
  hasTrustedSameOrigin,
  requireAdminSession,
  requireRequestSession,
} from "@/app/lib/auth-store";
import type {
  AccessContact,
  CampusContact,
} from "@/app/lib/vendor-clubs";

type DirectoryPayload =
  | { kind: "access"; record: AccessContact }
  | { kind: "campus"; record: CampusContact };

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    await requireRequestSession(request);
    return Response.json(await getAssignmentDirectory());
  } catch {
    return Response.json({ error: "Sign in to continue." }, { status: 401 });
  }
}

export async function PUT(request: Request) {
  if (!hasTrustedSameOrigin(request)) {
    return Response.json({ error: "Request rejected." }, { status: 403 });
  }
  try {
    await requireAdminSession(request);
  } catch {
    return Response.json(
      { error: "Only the System Administrator can edit assignments." },
      { status: 403 },
    );
  }

  try {
    const payload = (await request.json()) as DirectoryPayload;
    if (payload.kind === "access") {
      await saveAccessContact(payload.record);
    } else if (payload.kind === "campus") {
      await saveCampusAssignment(payload.record);
    } else {
      return Response.json(
        { error: "Choose a valid directory record." },
        { status: 400 },
      );
    }
    return Response.json({
      ok: true,
      directory: await getAssignmentDirectory(),
    });
  } catch (error) {
    return Response.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "The directory update failed.",
      },
      { status: 400 },
    );
  }
}

export async function DELETE(request: Request) {
  if (!hasTrustedSameOrigin(request)) {
    return Response.json({ error: "Request rejected." }, { status: 403 });
  }
  try {
    await requireAdminSession(request);
  } catch {
    return Response.json(
      { error: "Only the System Administrator can edit assignments." },
      { status: 403 },
    );
  }

  try {
    const email = new URL(request.url).searchParams.get("email") ?? "";
    await deleteAccessContact(email);
    return Response.json({
      ok: true,
      directory: await getAssignmentDirectory(),
    });
  } catch (error) {
    return Response.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "The directory update failed.",
      },
      { status: 400 },
    );
  }
}

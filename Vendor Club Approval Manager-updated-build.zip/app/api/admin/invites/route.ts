import {
  AuthError,
  createOrRotateInvite,
  hasTrustedSameOrigin,
  listAccessInvites,
  requireAdminSession,
  revokeInvite,
} from "@/app/lib/auth-store";

export const dynamic = "force-dynamic";

function errorResponse(error: unknown) {
  const authError =
    error instanceof AuthError
      ? error
      : new AuthError("The access update failed.", 500);
  return Response.json({ error: authError.message }, { status: authError.status });
}
export async function GET(request: Request) {
  try {
    await requireAdminSession(request);
    return Response.json(
      { invites: await listAccessInvites() },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request) {
  if (!hasTrustedSameOrigin(request)) {
    return Response.json({ error: "Request rejected." }, { status: 403 });
  }
  try {
    const admin = await requireAdminSession(request);
    const payload = (await request.json()) as {
      email?: string;
      expiresInDays?: number | null;
    };
    const result = await createOrRotateInvite(
      payload.email ?? "",
      payload.expiresInDays === null ? null : Number(payload.expiresInDays ?? 14),
      admin.email,
    );
    return Response.json(
      { ok: true, ...result, invites: await listAccessInvites() },
      { status: 201, headers: { "Cache-Control": "no-store" } },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function DELETE(request: Request) {
  if (!hasTrustedSameOrigin(request)) {
    return Response.json({ error: "Request rejected." }, { status: 403 });
  }
  try {
    await requireAdminSession(request);
    const email = new URL(request.url).searchParams.get("email") ?? "";
    await revokeInvite(email);
    return Response.json({ ok: true, invites: await listAccessInvites() });
  } catch (error) {
    return errorResponse(error);
  }
}

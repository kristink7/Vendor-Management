import {
  addTaskComment,
  advanceTask,
  asanaToken,
  createClubRequest,
  getClubRequestForAuthorization,
  markDocumentReceived,
  syncAssignment,
  updateRequestFields,
} from "@/app/lib/asana";
import {
  accessForEmailWithDirectory,
  canActOnClubRequest,
  canCreateClubRequest,
} from "@/app/lib/access";
import {
  hasTrustedSameOrigin,
  requireRequestSession,
} from "@/app/lib/auth-store";
import { getAssignmentDirectory } from "@/app/lib/assignment-store";
import {
  STAGES,
  type EditableRequestFields,
  type NewClubRequestInput,
  type StageKey,
} from "@/app/lib/vendor-clubs";

type ActionPayload = {
  action?:
    | "advance"
    | "syncAssignment"
    | "comment"
    | "documentReceived"
    | "createRequest"
    | "updateFields";
  taskGid?: string;
  targetStage?: StageKey;
  text?: string;
  documentOptionGid?: string;
  requestData?: NewClubRequestInput;
  fields?: EditableRequestFields;
};

export async function POST(request: Request) {
  if (!hasTrustedSameOrigin(request)) {
    return Response.json({ error: "Request rejected." }, { status: 403 });
  }
  let principal;
  try {
    principal = await requireRequestSession(request);
  } catch {
    return Response.json({ error: "Sign in to continue." }, { status: 401 });
  }
  const directory = await getAssignmentDirectory();
  const actorAccess = accessForEmailWithDirectory(
    principal.email,
    directory,
  );
  if (!actorAccess.canTakeAction) {
    return Response.json(
      { error: "You have view-only access to this workspace." },
      { status: 403 },
    );
  }

  try {
    const payload = (await request.json()) as ActionPayload;
    if (payload.action === "createRequest") {
      if (
        !payload.requestData ||
        !canCreateClubRequest(actorAccess, payload.requestData.campus)
      ) {
        return Response.json(
          {
            error:
              "New requests can only be submitted for a campus assigned to you.",
          },
          { status: 403 },
        );
      }
      if (!asanaToken()) {
        return Response.json(
          { error: "Asana is not configured for this site yet." },
          { status: 503 },
        );
      }
      const created = await createClubRequest(
        payload.requestData,
        actorAccess.email,
        directory.campusContacts,
      );
      return Response.json(
        {
          ok: true,
          taskGid: created.gid,
          permalinkUrl: created.permalink_url,
        },
        { status: 201 },
      );
    }

    if (!asanaToken()) {
      return Response.json(
        { error: "Asana is not configured for this site yet." },
        { status: 503 },
      );
    }

    const taskGid = payload.taskGid?.trim() ?? "";
    if (!taskGid) {
      return Response.json({ error: "taskGid is required." }, { status: 400 });
    }

    const clubRequest = await getClubRequestForAuthorization(
      taskGid,
      directory.campusContacts,
    );
    if (
      !canActOnClubRequest(
        actorAccess,
        clubRequest,
        payload.action === "advance" ? payload.targetStage : undefined,
      )
    ) {
      return Response.json(
        {
          error:
            "This request is outside your assigned role, campus, or process stage.",
        },
        { status: 403 },
      );
    }

    if (payload.action === "syncAssignment") {
      await syncAssignment(taskGid, directory.campusContacts);
    } else if (payload.action === "advance") {
      const target = payload.targetStage;
      if (!target || !STAGES.some((stage) => stage.key === target)) {
        return Response.json(
          { error: "A valid target stage is required." },
          { status: 400 },
        );
      }
      await advanceTask(taskGid, target, directory.campusContacts);
    } else if (payload.action === "documentReceived") {
      if (!payload.documentOptionGid) {
        return Response.json(
          { error: "documentOptionGid is required." },
          { status: 400 },
        );
      }
      await markDocumentReceived(taskGid, payload.documentOptionGid);
    } else if (payload.action === "comment") {
      await addTaskComment(taskGid, payload.text ?? "");
    } else if (payload.action === "updateFields") {
      if (!payload.fields) {
        return Response.json(
          { error: "Request fields are required." },
          { status: 400 },
        );
      }
      await updateRequestFields(taskGid, payload.fields);
    } else {
      return Response.json({ error: "Unknown action." }, { status: 400 });
    }

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json(
      {
        error:
          error instanceof Error ? error.message : "The Asana update failed.",
      },
      { status: 502 },
    );
  }
}

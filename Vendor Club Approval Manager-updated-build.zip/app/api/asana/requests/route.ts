import { asanaToken, getProjectRequests } from "@/app/lib/asana";
import { requireRequestSession } from "@/app/lib/auth-store";
import { getAssignmentDirectory } from "@/app/lib/assignment-store";
import { ASANA_PROJECT_GID } from "@/app/lib/vendor-clubs";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    await requireRequestSession(request);
  } catch {
    return Response.json({ error: "Sign in to continue." }, { status: 401 });
  }
  if (!asanaToken()) {
    return Response.json({
      configured: false,
      projectGid: ASANA_PROJECT_GID,
      requests: [],
    });
  }

  try {
    const directory = await getAssignmentDirectory();
    const requests = await getProjectRequests(directory.campusContacts);
    return Response.json({
      configured: true,
      projectGid: ASANA_PROJECT_GID,
      syncedAt: new Date().toISOString(),
      requests,
    });
  } catch (error) {
    return Response.json(
      {
        configured: true,
        error: error instanceof Error ? error.message : "Asana sync failed.",
      },
      { status: 502 },
    );
  }
}

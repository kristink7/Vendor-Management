import {
  asanaToken,
  getClubRequestForAuthorization,
  markDocumentsUploaded,
  uploadTaskAttachment,
} from "@/app/lib/asana";
import {
  accessForEmailWithDirectory,
  canActOnClubRequest,
} from "@/app/lib/access";
import {
  hasTrustedSameOrigin,
  requireRequestSession,
} from "@/app/lib/auth-store";
import { getAssignmentDirectory } from "@/app/lib/assignment-store";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!hasTrustedSameOrigin(request)) {
    return Response.json({ error: "Request rejected." }, { status: 403 });
  }
  let principal;
  try {
    principal = await requireRequestSession(request);
  } catch {
    return Response.json({ error: "Sign in to continue." }, { status: 401 });
  }
  const directory = await getAssignmentDirectory();
  const actorAccess = accessForEmailWithDirectory(
    principal.email,
    directory,
  );
  if (!actorAccess.canTakeAction) {
    return Response.json(
      { error: "You have view-only access to this workspace." },
      { status: 403 },
    );
  }
  if (!asanaToken()) {
    return Response.json(
      { error: "Asana is not configured for this site yet." },
      { status: 503 },
    );
  }

  try {
    const formData = await request.formData();
    const taskGids = Array.from(
      new Set(
        formData
          .getAll("taskGid")
          .map((value) => String(value).trim())
          .filter(Boolean),
      ),
    );
    const documentOptionGids = Array.from(
      new Set(
        formData
          .getAll("documentOptionGid")
          .map((value) => String(value).trim())
          .filter(Boolean),
      ),
    );
    const file = formData.get("file");
    if (!taskGids.length) {
      return Response.json(
        { error: "Select at least one task for this vendor." },
        { status: 400 },
      );
    }
    if (taskGids.length > 25) {
      return Response.json(
        { error: "Select no more than 25 tasks at a time." },
        { status: 400 },
      );
    }
    if (!(file instanceof File)) {
      return Response.json(
        { error: "Choose a document to upload." },
        { status: 400 },
      );
    }

    const clubRequests = [];
    for (const taskGid of taskGids) {
      const clubRequest = await getClubRequestForAuthorization(
        taskGid,
        directory.campusContacts,
      );
      if (!canActOnClubRequest(actorAccess, clubRequest)) {
        return Response.json(
          {
            error:
              "One or more selected tasks are outside your assigned role, campus, or process stage.",
          },
          { status: 403 },
        );
      }
      clubRequests.push(clubRequest);
    }

    const vendorKey = (value: string) =>
      value.trim().toLowerCase().replace(/\s+/g, " ");
    const expectedVendor = vendorKey(clubRequests[0].vendor);
    if (clubRequests.some((clubRequest) => vendorKey(clubRequest.vendor) !== expectedVendor)) {
      return Response.json(
        { error: "Bulk uploads can only be applied to tasks for the same vendor." },
        { status: 400 },
      );
    }

    const attachments = [];
    for (const taskGid of taskGids) {
      const attachment = await uploadTaskAttachment(taskGid, file);
      await markDocumentsUploaded(taskGid, documentOptionGids);
      attachments.push({ taskGid, attachment });
    }
    return Response.json(
      { ok: true, attachments, taskCount: taskGids.length },
      { status: 201 },
    );
  } catch (error) {
    return Response.json(
      {
        error:
          error instanceof Error ? error.message : "The document upload failed.",
      },
      { status: 502 },
    );
  }
}

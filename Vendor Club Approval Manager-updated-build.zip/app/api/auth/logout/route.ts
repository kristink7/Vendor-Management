import {
  endSession,
  hasTrustedSameOrigin,
} from "@/app/lib/auth-store";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!hasTrustedSameOrigin(request)) {
    return Response.json({ error: "Request rejected." }, { status: 403 });
  }
  return Response.json(
    { ok: true },
    { headers: { "Set-Cookie": await endSession(request), "Cache-Control": "no-store" } },
  );
}

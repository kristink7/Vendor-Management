import {
  AuthError,
  authenticateAccess,
  hasTrustedSameOrigin,
} from "@/app/lib/auth-store";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!hasTrustedSameOrigin(request)) {
    return Response.json({ error: "Request rejected." }, { status: 403 });
  }
  try {
    const payload = (await request.json()) as { email?: string; code?: string };
    const authenticated = await authenticateAccess(
      request,
      payload.email ?? "",
      payload.code ?? "",
    );
    return Response.json(
      { ok: true, role: authenticated.principal.role },
      { headers: { "Set-Cookie": authenticated.cookie, "Cache-Control": "no-store" } },
    );
  } catch (error) {
    if (!(error instanceof AuthError)) {
      console.error(
        "Access sign-in failed",
        error instanceof Error
          ? { name: error.name, message: error.message }
          : { type: typeof error },
      );
    }
    const authError =
      error instanceof AuthError
        ? error
        : new AuthError("Sign-in failed.", 500);
    return Response.json(
      { error: authError.message },
      {
        status: authError.status,
        headers: authError.retryAfter
          ? { "Retry-After": String(authError.retryAfter) }
          : undefined,
      },
    );
  }
}

import type { Metadata } from "next";
import { headers } from "next/headers";
import "./globals.css";

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host =
    requestHeaders.get("x-forwarded-host")?.split(",")[0]?.trim() ??
    requestHeaders.get("host") ??
    "lts-vendor-club-approvals.vertex-educa-5906.chatgpt.site";
  const protocol =
    requestHeaders.get("x-forwarded-proto")?.split(",")[0]?.trim() ??
    (host.startsWith("localhost") ? "http" : "https");
  const socialImage = `${protocol}://${host}/og.png`;

  return {
    title: "Vendor Club Approval Manager | Legacy Traditional Schools",
    description:
      "Securely manage vendor club approvals, campus assignments, and team handoffs across Legacy Traditional Schools.",
    icons: {
      icon: "/favicon.svg",
      shortcut: "/favicon.svg",
    },
    openGraph: {
      title: "Vendor Club Approval Manager",
      description: "Invitation-required access for every vendor-club handoff.",
      images: [
        {
          url: socialImage,
          alt: "Vendor Clubs Approval Manager with document and multi-task workflow",
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: "Vendor Club Approval Manager",
      description: "Invitation-required access for every vendor-club handoff.",
      images: [socialImage],
    },
  };
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

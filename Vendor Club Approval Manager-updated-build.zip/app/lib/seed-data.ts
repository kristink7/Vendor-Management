import {
  ACCOUNTING_OWNER,
  ASANA_PROJECT_URL,
  campusContact,
  type ClubRequest,
  PROCUREMENT_OWNER,
  stageDefinition,
  suggestedOwner,
  type StageKey,
} from "./vendor-clubs";

type SeedInput = {
  gid: string;
  title: string;
  vendor: string;
  club: string;
  campus: string;
  state: string;
  stage: StageKey;
  owner?: { name: string; gid: string };
  startDate?: string;
  missing?: Array<{ gid: string; name: string }>;
  attachments?: string[];
  nonprofit?: string;
};

const seeds: SeedInput[] = [
  { gid: "preview-01", title: "Think Move Chess — Columbia", vendor: "Think Move Chess", club: "Chess Club", campus: "Columbia", state: "SC", stage: "new", startDate: "2026-08-17", owner: PROCUREMENT_OWNER },
  { gid: "preview-02", title: "STEM Lab — Columbia", vendor: "STEM Lab", club: "Robotics Lab", campus: "Columbia", state: "SC", stage: "new", startDate: "2026-08-24" },
  { gid: "preview-03", title: "Strong Minds — Columbia", vendor: "Strong Minds", club: "Mindfulness Club", campus: "Columbia", state: "SC", stage: "docs", startDate: "2026-08-10", owner: PROCUREMENT_OWNER, missing: [{ gid: "1216932922061396", name: "COI Vertex" }, { gid: "1216932922061399", name: "Vendor contract" }], attachments: ["Strong Minds W-9.pdf"] },
  { gid: "preview-04", title: "Arizona Instruction — NW Tucson", vendor: "Arizona Instruction", club: "Art Studio", campus: "Northwest Tucson", state: "AZ", stage: "docs", startDate: "2026-08-03", owner: PROCUREMENT_OWNER, missing: [{ gid: "1216932922061397", name: "COI LTS" }] },
  { gid: "preview-05", title: "Bricks 4 Kidz — Queen Creek", vendor: "Bricks 4 Kidz", club: "LEGO Engineering", campus: "Queen Creek", state: "AZ", stage: "contract", startDate: "2026-08-18", owner: PROCUREMENT_OWNER },
  { gid: "preview-06", title: "Golf Squad — Surprise", vendor: "Golf Squad", club: "Junior Golf", campus: "Surprise", state: "AZ", stage: "roster", startDate: "2026-08-11", owner: { name: "Kayla Legge", gid: "1212346381627349" }, missing: [{ gid: "1216932922061401", name: "Roster" }, { gid: "1216932922061402", name: "Fingerprint cards" }], attachments: ["Fall roster.xlsx", "Fingerprint clearances.pdf"] },
  { gid: "preview-07", title: "Young Rembrandts — NW Tucson", vendor: "Young Rembrandts", club: "Drawing Club", campus: "Northwest Tucson", state: "AZ", stage: "roster", startDate: "2026-08-05", owner: { name: "Ana Vinas", gid: "1206396012911505" }, missing: [{ gid: "1216932922061402", name: "Fingerprint cards" }] },
  { gid: "preview-08", title: "Pearl Legends — Alamo Ranch", vendor: "Pearl Legends", club: "Dance Team", campus: "Alamo Ranch", state: "TX", stage: "invoice", startDate: "2026-08-20", owner: ACCOUNTING_OWNER, nonprofit: "No" },
  { gid: "preview-09", title: "Girls on the Run — Cibolo", vendor: "Girls on the Run", club: "Running Club", campus: "Cibolo", state: "TX", stage: "invoice", startDate: "2026-08-13", owner: PROCUREMENT_OWNER, nonprofit: "Yes" },
  { gid: "preview-10", title: "Genova — Cadence", vendor: "Genova", club: "Soccer Skills", campus: "Cadence", state: "NV", stage: "approved", startDate: "2026-08-15", owner: ACCOUNTING_OWNER },
  { gid: "preview-11", title: "Code Ninjas — Chandler", vendor: "Code Ninjas", club: "Coding Club", campus: "Chandler", state: "AZ", stage: "approved", startDate: "2026-08-06", owner: ACCOUNTING_OWNER },
];

export const SEED_REQUESTS: ClubRequest[] = seeds.map((seed) => {
  const suggestion = suggestedOwner(seed.stage, seed.campus);
  const dso = campusContact(seed.campus);
  return {
    gid: seed.gid,
    title: seed.title,
    vendor: seed.vendor,
    legalName: seed.vendor,
    club: seed.club,
    campus: seed.campus,
    state: seed.state,
    stage: seed.stage,
    status: stageDefinition(seed.stage).label,
    ownerName: seed.owner?.name ?? "Unassigned",
    ownerGid: seed.owner?.gid,
    suggestedOwnerName: suggestion.name,
    suggestedOwnerGid: suggestion.gid,
    assignmentMatches: seed.owner?.gid === suggestion.gid,
    startDate: seed.startDate,
    ltsc: `LTSC-${40 + Number(seed.gid.slice(-2))}`,
    contactName: "Vendor contact",
    email: "vendor@example.org",
    tuition: seed.nonprofit === "Yes" ? "$120" : "$145",
    nonprofit: seed.nonprofit ?? "No",
    instructorNames: "Pending final roster",
    attachments: (seed.attachments ?? []).map((name, index) => ({
      gid: `${seed.gid}-attachment-${index + 1}`,
      name,
      resourceSubtype: "asana",
      permanentUrl: ASANA_PROJECT_URL,
    })),
    uploadedDocuments: [],
    missingDocuments: seed.missing ?? [],
    dsoNames: dso ? [dso.name] : [],
    modifiedAt: new Date().toISOString(),
    permalinkUrl: ASANA_PROJECT_URL,
  };
});

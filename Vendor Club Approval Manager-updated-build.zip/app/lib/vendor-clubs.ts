export const ASANA_PROJECT_GID = "1215986344159670";
export const ASANA_PROJECT_URL =
  "https://app.asana.com/1/1202515054453280/project/1215986344159670";

export const FIELD_GIDS = {
  status: "1215985865576890",
  ltsc: "1215985865576907",
  campus: "1215985826062048",
  startDate: "1215985826062109",
  endDate: "1215985826062111",
  state: "1216309171852244",
  vendorName: "1216608477798774",
  legalName: "1216608477798776",
  contactName: "1216608477798778",
  phone: "1216608477798780",
  email: "1216608477798782",
  clubs: "1216608477798784",
  vendorDocuments: "1216608477798786",
  nonprofit: "1216608477798788",
  daysOffered: "1216608477798792",
  clubSession: "1216609530619017",
  instructorNames: "1216609866009587",
  tuition: "1216609866009589",
  missingDocuments: "1216932922061395",
  uploadedDocuments: "1217200537737052",
  dsoContact: "1216965022118639",
  physicalAddress: "1217031444862804",
  mailingAddress: "1217031444862806",
  fein: "1217031514439791",
} as const;

export const NEW_REQUEST_STATUS_OPTION_GID = "1215985865576891";
export const NEW_REQUEST_SECTION_GID = "1215986344159671";

export const CAMPUS_OPTION_GIDS: Record<string, string> = {
  Avondale: "1215985826062049",
  "Casa Grande": "1215985826062050",
  Chandler: "1215985826062051",
  "Deer Valley": "1215985826062052",
  "East Mesa": "1215985826062053",
  "East Tucson": "1215985826062054",
  Gilbert: "1215985826062055",
  Glendale: "1215985826062056",
  Goodyear: "1215985826062057",
  Laveen: "1215985826062058",
  Maricopa: "1215985826062060",
  Mesa: "1215985826062061",
  "North Chandler": "1215985826062062",
  "North Phoenix": "1215985826062063",
  "Northwest Tucson": "1215985826062064",
  Peoria: "1215985826062065",
  Phoenix: "1215985826062066",
  "Queen Creek": "1215985826062067",
  "San Tan": "1215985826062068",
  Surprise: "1215985826062069",
  "West Surprise": "1215985826062070",
  Columbia: "1216927238361534",
  Cadence: "1216927238361535",
  Cibolo: "1216927238361536",
  "Southwest Las Vegas": "1216927238361537",
  "North Valley": "1216927238361538",
  "Alamo Ranch": "1216927238361539",
};

export const STATE_OPTION_GIDS: Record<string, string> = {
  AZ: "1216309171852245",
  NV: "1216309171852246",
  SC: "1216309171852247",
  TX: "1216309171852248",
};

export const NONPROFIT_OPTION_GIDS: Record<string, string> = {
  Yes: "1216608477798789",
  No: "1216608477798790",
};

export const DAY_OPTION_GIDS: Record<string, string> = {
  Monday: "1216608477798793",
  Tuesday: "1216608521089711",
  Wednesday: "1216608521089712",
  Thursday: "1216608521089713",
  Friday: "1216608521089714",
};

export const SESSION_OPTION_GIDS: Record<string, string> = {
  "Quarter 1": "1216609530619018",
  "Quarter 2": "1216609530619019",
  "Quarter 3": "1216609530619020",
  "Quarter 4": "1216609530619021",
  "Semester 1": "1216609530619022",
  "Semester 2": "1216609530619023",
};

export const UPLOADED_DOCUMENT_OPTIONS = [
  { gid: "1217200537737053", name: "Contract" },
  { gid: "1217200537737054", name: "COI" },
  { gid: "1217200537737055", name: "Roster" },
  { gid: "1217200537737056", name: "Fingerprint cards" },
] as const;

export const UPLOADED_DOCUMENT_OPTION_GIDS = new Set<string>(
  UPLOADED_DOCUMENT_OPTIONS.map((option) => option.gid),
);

export const UPLOADED_TO_MISSING_DOCUMENT_GIDS: Record<string, string[]> = {
  "1217200537737053": ["1216932922061399"],
  "1217200537737054": ["1216932922061396", "1216932922061397"],
  "1217200537737055": ["1216932922061401"],
  "1217200537737056": ["1216932922061402"],
};

export type NewRequestKind = "vendor" | "club";

export type ClubAttachment = {
  gid: string;
  name: string;
  resourceSubtype?: string;
  permanentUrl?: string;
};

export type EditableRequestFields = {
  vendorName: string;
  legalName: string;
  club: string;
  startDate: string;
  endDate: string;
  contactName: string;
  email: string;
  phone: string;
  tuition: string;
  nonprofit: "Yes" | "No" | "";
  instructorNames: string;
};

export type NewClubRequestInput = {
  kind: NewRequestKind;
  vendorName: string;
  legalName: string;
  contactName: string;
  phone: string;
  email: string;
  nonprofit: "Yes" | "No" | "";
  fein: string;
  physicalAddress: string;
  mailingAddress: string;
  vendorDocuments: string;
  club: string;
  campus: string;
  state: string;
  startDate: string;
  endDate: string;
  daysOffered: string[];
  clubSession: string;
  instructorNames: string;
  tuition: string;
  notes: string;
};

export type StageKey =
  | "new"
  | "no_documents"
  | "docs"
  | "waiting_contract"
  | "contract"
  | "roster"
  | "invoice"
  | "approved"
  | "incomplete";

export type RoleKey = "Procurement" | "DSO" | "Accounting";
export type AccessPermission = "Executive" | "Procurement" | "Accounting";

export type AccessContact = {
  name: string;
  email: string;
  permission: AccessPermission;
};

export type CampusContact = {
  name: string;
  role: string;
  email: string;
  campus: string;
  state: string;
  asanaGid: string;
};

export type AssignmentDirectory = {
  accessContacts: AccessContact[];
  campusContacts: CampusContact[];
};

export type ClubRequest = {
  gid: string;
  title: string;
  vendor: string;
  legalName?: string;
  club: string;
  campus: string;
  state: string;
  stage: StageKey;
  status: string;
  ownerName: string;
  ownerGid?: string;
  suggestedOwnerName: string;
  suggestedOwnerGid?: string;
  assignmentMatches: boolean;
  startDate?: string;
  endDate?: string;
  ltsc?: string;
  contactName?: string;
  email?: string;
  phone?: string;
  fein?: string;
  physicalAddress?: string;
  mailingAddress?: string;
  daysOffered?: string;
  tuition?: string;
  nonprofit?: string;
  instructorNames?: string;
  attachments: ClubAttachment[];
  uploadedDocuments: Array<{ gid: string; name: string }>;
  missingDocuments: Array<{ gid: string; name: string }>;
  dsoNames: string[];
  dsoGids?: string[];
  modifiedAt?: string;
  permalinkUrl: string;
};

export const PROCUREMENT_OWNER = {
  name: "Kaden Matthews",
  gid: "1205227099815099",
};

export const ACCOUNTING_OWNER = {
  name: "Anna Villa",
  gid: "1210621284155017",
};

export const STAGES: Array<{
  key: StageKey;
  label: string;
  shortLabel: string;
  owner: RoleKey | "—";
  optionGid: string;
  step: string;
}> = [
  {
    key: "new",
    label: "New Request",
    shortLabel: "New",
    owner: "Procurement",
    optionGid: "1215985865576891",
    step: "Intake",
  },
  {
    key: "no_documents",
    label: "No documents submitted",
    shortLabel: "No documents submitted",
    owner: "Procurement",
    optionGid: "1217200537736992",
    step: "Document intake",
  },
  {
    key: "docs",
    label: "In Progress - waiting on documents",
    shortLabel: "Waiting on docs",
    owner: "Procurement",
    optionGid: "1216965022118637",
    step: "Document package",
  },
  {
    key: "waiting_contract",
    label: "Waiting on contract",
    shortLabel: "Waiting on contract",
    owner: "Procurement",
    optionGid: "1217200679468708",
    step: "Contract collection",
  },
  {
    key: "contract",
    label: "In progress - contract review",
    shortLabel: "Contract review",
    owner: "Procurement",
    optionGid: "1215985865576892",
    step: "Contract + Workday",
  },
  {
    key: "roster",
    label: "Approved pending roster review",
    shortLabel: "Roster review",
    owner: "DSO",
    optionGid: "1215985865576893",
    step: "Roster + FPCC",
  },
  {
    key: "invoice",
    label: "Contract approved - Ready for first invoice",
    shortLabel: "Ready to invoice",
    owner: "Accounting",
    optionGid: "1215985865576894",
    step: "First invoice",
  },
  {
    key: "approved",
    label: "Approved",
    shortLabel: "Approved",
    owner: "—",
    optionGid: "1215985826062031",
    step: "Complete",
  },
  {
    key: "incomplete",
    label: "Incomplete/Not approved",
    shortLabel: "Not approved",
    owner: "Procurement",
    optionGid: "1215985826062032",
    step: "Needs resolution",
  },
];

export const ROLE_STAGE_TARGETS: Record<RoleKey, StageKey[]> = {
  Procurement: [
    "new",
    "no_documents",
    "docs",
    "waiting_contract",
    "contract",
    "roster",
    "incomplete",
  ],
  DSO: ["contract", "roster", "invoice", "incomplete"],
  Accounting: ["roster", "invoice", "approved", "incomplete"],
};

export const CAMPUS_CONTACTS: CampusContact[] = [
  { name: "Mark Owens", role: "DSO", email: "mark.owens@legacytraditional.org", campus: "Avondale", state: "AZ", asanaGid: "1209953835562142" },
  { name: "Clifford Arellano", role: "DSO", email: "clifford.arellano@legacytraditional.org", campus: "Casa Grande", state: "AZ", asanaGid: "1210526824961340" },
  { name: "Jennifer Gerber", role: "DSO", email: "jennifer.gerber@legacytraditional.org", campus: "Chandler", state: "AZ", asanaGid: "1206396012911328" },
  { name: "Aleta Elmore", role: "DSO", email: "aleta.elmore@legacytraditional.org", campus: "Deer Valley", state: "AZ", asanaGid: "1206396012911409" },
  { name: "Heather Morey", role: "DSO", email: "heather.morey@legacytraditional.org", campus: "East Mesa", state: "AZ", asanaGid: "1206396012911473" },
  { name: "Murray Lewis", role: "DSO", email: "murray.lewis@legacytraditional.org", campus: "East Tucson", state: "AZ", asanaGid: "1209292183241314" },
  { name: "Vanessa Pierce", role: "DSO", email: "vanessa.pierce@legacytraditional.org", campus: "Gilbert", state: "AZ", asanaGid: "1209885671707521" },
  { name: "Dirk Olmstead", role: "DSO", email: "dirk.olmstead@legacytraditional.org", campus: "Glendale", state: "AZ", asanaGid: "1216762820830732" },
  { name: "Kathryn Blevins", role: "DSO", email: "kathryn.blevins@legacytraditional.org", campus: "Goodyear", state: "AZ", asanaGid: "1204660409654267" },
  { name: "Sandy Leadbetter (Uterhardt)", role: "DSO", email: "sandra.leadbetter@legacytraditional.org", campus: "Laveen", state: "AZ", asanaGid: "1211073628097580" },
  { name: "Andrea McHenry", role: "DSO", email: "andrea.mchenry@legacytraditional.org", campus: "Maricopa", state: "AZ", asanaGid: "1206396012911355" },
  { name: "Megan Whitsett", role: "DSO", email: "megan.whitsett@legacytraditional.org", campus: "Mesa", state: "AZ", asanaGid: "1206396012911380" },
  { name: "Brandon Bailey", role: "DSO", email: "brandon.bailey@legacytraditional.org", campus: "North Chandler", state: "AZ", asanaGid: "1206396012911471" },
  { name: "Candice Barnes", role: "DSO", email: "candice.barnes@legacytraditional.org", campus: "North Phoenix", state: "AZ", asanaGid: "1210526962223000" },
  { name: "Ana Vinas", role: "DSO", email: "ana.vinas@legacytraditional.org", campus: "Northwest Tucson", state: "AZ", asanaGid: "1206396012911505" },
  { name: "Marlene Mettes", role: "DSO", email: "marlene.mettes@legacytraditional.org", campus: "Peoria", state: "AZ", asanaGid: "1206396012911540" },
  { name: "Candice Barnes", role: "DSO", email: "candice.barnes@legacytraditional.org", campus: "Phoenix", state: "AZ", asanaGid: "1210526962223000" },
  { name: "Devin Miller", role: "DSO", email: "devin.miller@legacytraditional.org", campus: "Queen Creek", state: "AZ", asanaGid: "1209500514710815" },
  { name: "Sara Polina", role: "DSO", email: "sara.polina@legacytraditional.org", campus: "San Tan", state: "AZ", asanaGid: "1206396012911641" },
  { name: "Kayla Legge", role: "DSO", email: "kayla.legge@legacytraditional.org", campus: "Surprise", state: "AZ", asanaGid: "1212346381627349" },
  { name: "Kristin Lucas", role: "DSO", email: "kristin.lucas@legacytraditional.org", campus: "West Surprise", state: "AZ", asanaGid: "1206396012911712" },
  { name: "Tony Davis", role: "Principal", email: "tony.davis@legacytraditional.org", campus: "Cadence", state: "NV", asanaGid: "1210433953473746" },
  { name: "Brian Meadows", role: "Principal", email: "brian.meadows@legacytraditional.org", campus: "North Valley", state: "NV", asanaGid: "1210564332752272" },
  { name: "Stephanie Chapman", role: "Assistant Principal", email: "stephanie.chapman@legacytraditional.org", campus: "Southwest Las Vegas", state: "NV", asanaGid: "1206396012911990" },
  { name: "Christina Albrecht", role: "DSO", email: "christina.albrecht@legacytraditional.org", campus: "Columbia", state: "SC", asanaGid: "1206396012911676" },
  { name: "Carmen Maglievaz", role: "DSO", email: "carmen.maglievaz@legacytraditional.org", campus: "Cibolo", state: "TX", asanaGid: "1216304499316987" },
  { name: "Ashley Escammilla", role: "DSO", email: "ashley.escamilla@legacytraditional.org", campus: "Alamo Ranch", state: "TX", asanaGid: "1209174007598872" },
];

const CAMPUS_ALIASES: Record<string, string> = {
  "nw tucson": "Northwest Tucson",
  "northwest tucson": "Northwest Tucson",
  "sw las vegas": "Southwest Las Vegas",
  "southwest las vegas": "Southwest Las Vegas",
};

export function normalizeCampus(value: string) {
  const withoutState = value.replace(/^[A-Z]{2}\s*[-–]\s*/i, "").trim();
  return CAMPUS_ALIASES[withoutState.toLowerCase()] ?? withoutState;
}

export function campusContact(
  value: string,
  contacts: CampusContact[] = CAMPUS_CONTACTS,
) {
  const normalized = normalizeCampus(value);
  return contacts.find(
    (contact) => contact.campus.toLowerCase() === normalized.toLowerCase(),
  );
}

export function stageFromStatus(value?: string | null): StageKey {
  const normalized = (value ?? "").trim().toLowerCase();
  return (
    STAGES.find((stage) => stage.label.toLowerCase() === normalized)?.key ??
    "new"
  );
}

export function stageDefinition(key: StageKey) {
  return STAGES.find((stage) => stage.key === key) ?? STAGES[0];
}

export function suggestedOwner(
  stage: StageKey,
  campus: string,
  contacts: CampusContact[] = CAMPUS_CONTACTS,
) {
  if (stage === "roster") {
    const contact = campusContact(campus, contacts);
    return contact
      ? { name: contact.name, gid: contact.asanaGid }
      : { name: "Campus contact needed", gid: undefined };
  }
  if (stage === "invoice" || stage === "approved") return ACCOUNTING_OWNER;
  return PROCUREMENT_OWNER;
}

export function nextStage(stage: StageKey): StageKey | null {
  const sequence: StageKey[] = [
    "new",
    "no_documents",
    "docs",
    "waiting_contract",
    "contract",
    "roster",
    "invoice",
    "approved",
  ];
  const index = sequence.indexOf(stage);
  return index >= 0 && index < sequence.length - 1 ? sequence[index + 1] : null;
}

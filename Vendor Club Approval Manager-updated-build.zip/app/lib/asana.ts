import {
  ASANA_PROJECT_GID,
  CAMPUS_OPTION_GIDS,
  campusContact,
  DAY_OPTION_GIDS,
  FIELD_GIDS,
  NEW_REQUEST_SECTION_GID,
  NEW_REQUEST_STATUS_OPTION_GID,
  NONPROFIT_OPTION_GIDS,
  normalizeCampus,
  PROCUREMENT_OWNER,
  SESSION_OPTION_GIDS,
  STATE_OPTION_GIDS,
  stageDefinition,
  stageFromStatus,
  suggestedOwner,
  UPLOADED_DOCUMENT_OPTION_GIDS,
  UPLOADED_TO_MISSING_DOCUMENT_GIDS,
  type CampusContact,
  type ClubAttachment,
  type ClubRequest,
  type EditableRequestFields,
  type NewClubRequestInput,
  type StageKey,
} from "./vendor-clubs";

const ASANA_API = "https://app.asana.com/api/1.0";

type AsanaCustomField = {
  gid: string;
  display_value?: string | null;
  text_value?: string | null;
  enum_value?: { gid: string; name: string } | null;
  multi_enum_values?: Array<{ gid: string; name: string }>;
  people_value?: Array<{ gid: string; name: string; email?: string }>;
  date_value?: { date?: string | null; date_time?: string | null } | null;
};

type AsanaTask = {
  gid: string;
  name: string;
  completed?: boolean;
  start_on?: string | null;
  due_on?: string | null;
  modified_at?: string;
  permalink_url?: string;
  assignee?: { gid: string; name: string } | null;
  custom_fields?: AsanaCustomField[];
  memberships?: Array<{ project?: { gid: string } }>;
};

type AsanaAttachment = {
  gid: string;
  name: string;
  resource_subtype?: string;
  permanent_url?: string;
};

type AsanaEnvelope<T> = {
  data: T;
  next_page?: { offset?: string } | null;
  errors?: Array<{ message?: string }>;
};

export function asanaToken() {
  return process.env.ASANA_ACCESS_TOKEN?.trim() ?? "";
}

async function asanaFetch<T>(
  path: string,
  init: RequestInit = {},
): Promise<AsanaEnvelope<T>> {
  const token = asanaToken();
  if (!token) throw new Error("Asana is not configured for this site yet.");

  const response = await fetch(`${ASANA_API}${path}`, {
    ...init,
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${token}`,
      ...(init.body ? { "Content-Type": "application/json" } : {}),
      ...init.headers,
    },
  });
  const payload = (await response.json()) as AsanaEnvelope<T>;
  if (!response.ok) {
    const message =
      payload.errors?.map((error) => error.message).filter(Boolean).join(" ") ||
      `Asana returned ${response.status}.`;
    throw new Error(message);
  }
  return payload;
}

function fieldMap(task: AsanaTask) {
  return new Map((task.custom_fields ?? []).map((field) => [field.gid, field]));
}

function display(field?: AsanaCustomField) {
  return (
    field?.display_value?.trim() ||
    field?.text_value?.trim() ||
    field?.enum_value?.name?.trim() ||
    ""
  );
}

export function normalizeTask(
  task: AsanaTask,
  campusContacts?: CampusContact[],
  attachments: ClubAttachment[] = [],
): ClubRequest | null {
  const fields = fieldMap(task);
  const status = display(fields.get(FIELD_GIDS.status));
  if (!status) return null;

  const rawCampus = display(fields.get(FIELD_GIDS.campus));
  const campus = normalizeCampus(rawCampus);
  const stage = stageFromStatus(status);
  const suggestion = suggestedOwner(stage, campus, campusContacts);
  const stateValues = fields.get(FIELD_GIDS.state)?.multi_enum_values ?? [];
  const dsoValues = fields.get(FIELD_GIDS.dsoContact)?.people_value ?? [];
  const missing =
    fields.get(FIELD_GIDS.missingDocuments)?.multi_enum_values ?? [];
  const uploaded =
    fields.get(FIELD_GIDS.uploadedDocuments)?.multi_enum_values ?? [];
  const club = display(fields.get(FIELD_GIDS.clubs));
  const vendor =
    display(fields.get(FIELD_GIDS.vendorName)) ||
    task.name.split(/[—-]/)[0]?.trim() ||
    task.name;

  return {
    gid: task.gid,
    title: task.name,
    vendor,
    legalName: display(fields.get(FIELD_GIDS.legalName)),
    club,
    campus: campus || "Campus not set",
    state:
      stateValues.map((value) => value.name).join(", ") ||
      campusContact(campus, campusContacts)?.state ||
      "",
    stage,
    status,
    ownerName: task.assignee?.name ?? "Unassigned",
    ownerGid: task.assignee?.gid,
    suggestedOwnerName: suggestion.name,
    suggestedOwnerGid: suggestion.gid,
    assignmentMatches: Boolean(
      suggestion.gid && task.assignee?.gid === suggestion.gid,
    ),
    startDate:
      fields.get(FIELD_GIDS.startDate)?.date_value?.date ||
      display(fields.get(FIELD_GIDS.startDate)) ||
      task.start_on ||
      undefined,
    endDate:
      fields.get(FIELD_GIDS.endDate)?.date_value?.date ||
      display(fields.get(FIELD_GIDS.endDate)) ||
      task.due_on ||
      undefined,
    ltsc: display(fields.get(FIELD_GIDS.ltsc)) || undefined,
    contactName: display(fields.get(FIELD_GIDS.contactName)) || undefined,
    email: display(fields.get(FIELD_GIDS.email)) || undefined,
    phone: display(fields.get(FIELD_GIDS.phone)) || undefined,
    fein: display(fields.get(FIELD_GIDS.fein)) || undefined,
    physicalAddress:
      display(fields.get(FIELD_GIDS.physicalAddress)) || undefined,
    mailingAddress:
      display(fields.get(FIELD_GIDS.mailingAddress)) || undefined,
    daysOffered: display(fields.get(FIELD_GIDS.daysOffered)) || undefined,
    tuition: display(fields.get(FIELD_GIDS.tuition)) || undefined,
    nonprofit: display(fields.get(FIELD_GIDS.nonprofit)) || undefined,
    instructorNames: display(fields.get(FIELD_GIDS.instructorNames)) || undefined,
    attachments,
    uploadedDocuments: uploaded.map(({ gid, name }) => ({ gid, name })),
    missingDocuments: missing.map(({ gid, name }) => ({ gid, name })),
    dsoNames: dsoValues.map((person) => person.name),
    dsoGids: dsoValues.map((person) => person.gid),
    modifiedAt: task.modified_at,
    permalinkUrl:
      task.permalink_url ??
      `https://app.asana.com/0/${ASANA_PROJECT_GID}/${task.gid}`,
  };
}

const TASK_FIELDS = [
  "gid",
  "name",
  "completed",
  "start_on",
  "due_on",
  "modified_at",
  "permalink_url",
  "assignee.gid",
  "assignee.name",
  "custom_fields.gid",
  "custom_fields.display_value",
  "custom_fields.text_value",
  "custom_fields.enum_value.gid",
  "custom_fields.enum_value.name",
  "custom_fields.multi_enum_values.gid",
  "custom_fields.multi_enum_values.name",
  "custom_fields.people_value.gid",
  "custom_fields.people_value.name",
  "custom_fields.people_value.email",
  "custom_fields.date_value.date",
].join(",");

export async function getProjectRequests(campusContacts?: CampusContact[]) {
  const tasks: AsanaTask[] = [];
  let offset = "";
  do {
    const params = new URLSearchParams({
      limit: "100",
      completed_since: "now",
      opt_fields: TASK_FIELDS,
    });
    if (offset) params.set("offset", offset);
    const response = await asanaFetch<AsanaTask[]>(
      `/projects/${ASANA_PROJECT_GID}/tasks?${params}`,
    );
    tasks.push(...response.data);
    offset = response.next_page?.offset ?? "";
  } while (offset);

  const tasksWithAttachments: Array<{
    task: AsanaTask;
    attachments: ClubAttachment[];
  }> = [];
  const attachmentBatchSize = 8;
  for (let index = 0; index < tasks.length; index += attachmentBatchSize) {
    const batch = tasks.slice(index, index + attachmentBatchSize);
    tasksWithAttachments.push(
      ...(await Promise.all(
        batch.map(async (task) => ({
          task,
          attachments: await getTaskAttachments(task.gid),
        })),
      )),
    );
  }

  return tasksWithAttachments
    .map(({ task, attachments }) =>
      normalizeTask(task, campusContacts, attachments),
    )
    .filter((task): task is ClubRequest => task !== null);
}

export async function getTaskAttachments(
  taskGid: string,
): Promise<ClubAttachment[]> {
  if (!/^\d+$/.test(taskGid)) return [];
  const params = new URLSearchParams({
    parent: taskGid,
    limit: "100",
    opt_fields: "gid,name,resource_subtype,permanent_url",
  });
  const response = await asanaFetch<AsanaAttachment[]>(
    `/attachments?${params}`,
  );
  return response.data.map((attachment) => ({
    gid: attachment.gid,
    name: attachment.name,
    resourceSubtype: attachment.resource_subtype,
    permanentUrl: attachment.permanent_url,
  }));
}

async function getWritableTask(taskGid: string) {
  if (!/^\d+$/.test(taskGid)) throw new Error("That task cannot be updated.");
  const optFields = [
    TASK_FIELDS,
    "memberships.project.gid",
  ].join(",");
  const response = await asanaFetch<AsanaTask>(
    `/tasks/${taskGid}?opt_fields=${encodeURIComponent(optFields)}`,
  );
  const belongsToProject = response.data.memberships?.some(
    (membership) => membership.project?.gid === ASANA_PROJECT_GID,
  );
  if (!belongsToProject) throw new Error("This task is not in the club project.");
  return response.data;
}

export async function getClubRequestForAuthorization(
  taskGid: string,
  campusContacts?: CampusContact[],
) {
  const task = await getWritableTask(taskGid);
  const normalized = normalizeTask(task, campusContacts);
  if (!normalized) {
    throw new Error("This request does not have a status.");
  }
  return normalized;
}

async function updateTask(
  taskGid: string,
  data: Record<string, unknown>,
) {
  return asanaFetch<AsanaTask>(`/tasks/${taskGid}`, {
    method: "PUT",
    body: JSON.stringify({ data }),
  });
}

function assignmentData(
  task: AsanaTask,
  stageOverride?: StageKey,
  campusContacts?: CampusContact[],
) {
  const normalized = normalizeTask(task, campusContacts);
  if (!normalized) throw new Error("This request does not have a status.");
  const stage = stageOverride ?? normalized.stage;
  const suggestion = suggestedOwner(stage, normalized.campus, campusContacts);
  if (!suggestion.gid) {
    throw new Error(`No campus contact is mapped for ${normalized.campus}.`);
  }
  const dso = campusContact(normalized.campus, campusContacts);
  const customFields: Record<string, string | string[]> = {};
  if (dso) customFields[FIELD_GIDS.dsoContact] = [dso.asanaGid];
  return {
    assignee: suggestion.gid,
    custom_fields: customFields,
  };
}

export async function syncAssignment(
  taskGid: string,
  campusContacts?: CampusContact[],
) {
  const task = await getWritableTask(taskGid);
  return updateTask(taskGid, assignmentData(task, undefined, campusContacts));
}

export async function advanceTask(
  taskGid: string,
  target: StageKey,
  campusContacts?: CampusContact[],
) {
  const task = await getWritableTask(taskGid);
  const stage = stageDefinition(target);
  const assignment = assignmentData(task, target, campusContacts);
  return updateTask(taskGid, {
    ...assignment,
    custom_fields: {
      ...assignment.custom_fields,
      [FIELD_GIDS.status]: stage.optionGid,
    },
  });
}

export async function markDocumentReceived(
  taskGid: string,
  documentOptionGid: string,
) {
  const task = await getWritableTask(taskGid);
  const fields = fieldMap(task);
  const currentMissing =
    fields
      .get(FIELD_GIDS.missingDocuments)
      ?.multi_enum_values?.map((value) => value.gid) ?? [];
  const currentUploaded =
    fields
      .get(FIELD_GIDS.uploadedDocuments)
      ?.multi_enum_values?.map((value) => value.gid) ?? [];
  const matchingUploadedOption = Object.entries(
    UPLOADED_TO_MISSING_DOCUMENT_GIDS,
  ).find(([, missingGids]) => missingGids.includes(documentOptionGid))?.[0];
  const nextUploaded = matchingUploadedOption
    ? Array.from(new Set([...currentUploaded, matchingUploadedOption]))
    : currentUploaded;
  return updateTask(taskGid, {
    custom_fields: {
      [FIELD_GIDS.missingDocuments]: currentMissing.filter(
        (gid) => gid !== documentOptionGid,
      ),
      [FIELD_GIDS.uploadedDocuments]: nextUploaded,
    },
  });
}

export async function markDocumentsUploaded(
  taskGid: string,
  documentOptionGids: string[],
) {
  const validOptionGids = Array.from(
    new Set(
      documentOptionGids.filter((gid) =>
        UPLOADED_DOCUMENT_OPTION_GIDS.has(gid),
      ),
    ),
  );
  if (!validOptionGids.length) return;

  const task = await getWritableTask(taskGid);
  const fields = fieldMap(task);
  const currentUploaded =
    fields
      .get(FIELD_GIDS.uploadedDocuments)
      ?.multi_enum_values?.map((value) => value.gid) ?? [];
  const currentMissing =
    fields
      .get(FIELD_GIDS.missingDocuments)
      ?.multi_enum_values?.map((value) => value.gid) ?? [];
  const receivedMissingGids = new Set(
    validOptionGids.flatMap(
      (gid) => UPLOADED_TO_MISSING_DOCUMENT_GIDS[gid] ?? [],
    ),
  );

  return updateTask(taskGid, {
    custom_fields: {
      [FIELD_GIDS.uploadedDocuments]: Array.from(
        new Set([...currentUploaded, ...validOptionGids]),
      ),
      [FIELD_GIDS.missingDocuments]: currentMissing.filter(
        (gid) => !receivedMissingGids.has(gid),
      ),
    },
  });
}

export async function addTaskComment(taskGid: string, text: string) {
  await getWritableTask(taskGid);
  const trimmed = text.trim();
  if (!trimmed) throw new Error("Write a comment first.");
  if (trimmed.length > 5000) throw new Error("The comment is too long.");
  return asanaFetch(`/tasks/${taskGid}/stories`, {
    method: "POST",
    body: JSON.stringify({ data: { text: trimmed } }),
  });
}

export const MAX_ATTACHMENT_BYTES = 90 * 1024 * 1024;

export async function uploadTaskAttachment(taskGid: string, file: File) {
  await getWritableTask(taskGid);
  const filename = file.name.replace(/[\r\n]/g, " ").trim();
  if (!filename) throw new Error("Choose a document to upload.");
  if (!file.size) throw new Error(`${filename} is empty.`);
  if (file.size > MAX_ATTACHMENT_BYTES) {
    throw new Error(`${filename} exceeds the 90 MB upload limit.`);
  }
  if (/\.(?:exe|msi|bat|cmd|com|scr|ps1|sh|js|jar)$/i.test(filename)) {
    throw new Error("That file type is not allowed.");
  }

  const token = asanaToken();
  if (!token) throw new Error("Asana is not configured for this site yet.");
  const formData = new FormData();
  formData.append("parent", taskGid);
  formData.append("file", file, filename);
  const response = await fetch(
    `${ASANA_API}/attachments?opt_fields=${encodeURIComponent(
      "gid,name,resource_subtype,permanent_url",
    )}`,
    {
      method: "POST",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    },
  );
  const payload = (await response.json()) as AsanaEnvelope<AsanaAttachment>;
  if (!response.ok) {
    const message =
      payload.errors?.map((error) => error.message).filter(Boolean).join(" ") ||
      `Asana returned ${response.status}.`;
    throw new Error(message);
  }
  return {
    gid: payload.data.gid,
    name: payload.data.name,
    resourceSubtype: payload.data.resource_subtype,
    permanentUrl: payload.data.permanent_url,
  } satisfies ClubAttachment;
}

const requiredText = (
  value: unknown,
  label: string,
  maxLength = 1024,
) => {
  const normalized = typeof value === "string" ? value.trim() : "";
  if (!normalized) throw new Error(`${label} is required.`);
  if (normalized.length > maxLength) {
    throw new Error(`${label} is too long.`);
  }
  return normalized;
};

const optionalText = (value: unknown, label: string, maxLength = 1024) => {
  if (typeof value !== "string") return "";
  const normalized = value.trim();
  if (normalized.length > maxLength) {
    throw new Error(`${label} is too long.`);
  }
  return normalized;
};

function optionalDate(value: unknown, label: string) {
  const normalized = optionalText(value, label, 10);
  if (normalized && !/^\d{4}-\d{2}-\d{2}$/.test(normalized)) {
    throw new Error(`Enter a valid ${label.toLowerCase()}.`);
  }
  return normalized;
}

function validateEditableFields(input: EditableRequestFields) {
  const vendorName = requiredText(input.vendorName, "Vendor name");
  const club = requiredText(input.club, "Club name");
  const startDate = optionalDate(input.startDate, "Start date");
  const endDate = optionalDate(input.endDate, "End date");
  if (startDate && endDate && endDate < startDate) {
    throw new Error("The end date must be on or after the start date.");
  }

  const email = optionalText(input.email, "Vendor email");
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new Error("Enter a valid vendor email.");
  }

  const nonprofit = optionalText(input.nonprofit, "Nonprofit status", 3);
  if (nonprofit && !NONPROFIT_OPTION_GIDS[nonprofit]) {
    throw new Error("Choose a valid nonprofit status.");
  }

  return {
    vendorName,
    legalName: optionalText(input.legalName, "Legal business name"),
    club,
    startDate,
    endDate,
    contactName: optionalText(input.contactName, "Vendor contact"),
    email,
    phone: optionalText(input.phone, "Vendor phone"),
    tuition: optionalText(input.tuition, "Student tuition"),
    nonprofit,
    instructorNames: optionalText(input.instructorNames, "Instructor names"),
  };
}

export async function updateRequestFields(
  taskGid: string,
  input: EditableRequestFields,
) {
  const task = await getWritableTask(taskGid);
  const current = normalizeTask(task);
  if (!current) throw new Error("This request does not have a status.");
  const fields = validateEditableFields(input);
  const customFields: Record<string, unknown> = {
    [FIELD_GIDS.vendorName]: fields.vendorName,
    [FIELD_GIDS.legalName]: fields.legalName,
    [FIELD_GIDS.clubs]: fields.club,
    [FIELD_GIDS.startDate]: fields.startDate
      ? { date: fields.startDate }
      : null,
    [FIELD_GIDS.endDate]: fields.endDate ? { date: fields.endDate } : null,
    [FIELD_GIDS.contactName]: fields.contactName,
    [FIELD_GIDS.email]: fields.email,
    [FIELD_GIDS.phone]: fields.phone,
    [FIELD_GIDS.tuition]: fields.tuition,
    [FIELD_GIDS.instructorNames]: fields.instructorNames,
    [FIELD_GIDS.nonprofit]: fields.nonprofit
      ? NONPROFIT_OPTION_GIDS[fields.nonprofit]
      : null,
  };

  return updateTask(taskGid, {
    name: `${fields.vendorName} — ${fields.club} — ${current.campus}`,
    start_on: fields.startDate || null,
    due_on: fields.endDate || null,
    custom_fields: customFields,
  });
}

function validateNewRequest(
  input: NewClubRequestInput,
  campusContacts?: CampusContact[],
) {
  if (input.kind !== "vendor" && input.kind !== "club") {
    throw new Error("Choose a valid request type.");
  }

  const campus = normalizeCampus(requiredText(input.campus, "Campus"));
  const contact = campusContact(campus, campusContacts);
  const campusOption = CAMPUS_OPTION_GIDS[campus];
  if (!contact || !campusOption) {
    throw new Error("That campus is not available in the assignment map.");
  }

  const state = requiredText(input.state, "State");
  const stateOption = STATE_OPTION_GIDS[state];
  if (!stateOption || contact.state !== state) {
    throw new Error("The selected state does not match the campus.");
  }

  const nonprofit = requiredText(input.nonprofit, "Nonprofit status");
  const nonprofitOption = NONPROFIT_OPTION_GIDS[nonprofit];
  if (!nonprofitOption) throw new Error("Choose a valid nonprofit status.");

  const daysOffered = Array.isArray(input.daysOffered)
    ? Array.from(new Set(input.daysOffered))
    : [];
  const dayOptions = daysOffered.map((day) => DAY_OPTION_GIDS[day]).filter(Boolean);
  if (!dayOptions.length || dayOptions.length !== daysOffered.length) {
    throw new Error("Choose at least one valid day offered.");
  }

  const clubSession = requiredText(input.clubSession, "Club session");
  const sessionOption = SESSION_OPTION_GIDS[clubSession];
  if (!sessionOption) throw new Error("Choose a valid club session.");

  const startDate = requiredText(input.startDate, "Start date");
  const endDate = requiredText(input.endDate, "End date");
  if (
    !/^\d{4}-\d{2}-\d{2}$/.test(startDate) ||
    !/^\d{4}-\d{2}-\d{2}$/.test(endDate)
  ) {
    throw new Error("Enter valid start and end dates.");
  }
  if (endDate < startDate) {
    throw new Error("The end date must be on or after the start date.");
  }

  const email = requiredText(input.email, "Vendor email");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new Error("Enter a valid vendor email.");
  }

  const vendorDocuments = optionalText(
    input.vendorDocuments,
    "Vendor document details",
  );
  const fein = optionalText(input.fein, "FEIN");
  const physicalAddress = optionalText(
    input.physicalAddress,
    "Physical address",
  );
  const mailingAddress = optionalText(input.mailingAddress, "Mailing address");
  if (input.kind === "vendor") {
    if (!fein) throw new Error("FEIN is required for a new vendor.");
    if (!physicalAddress) {
      throw new Error("Physical address is required for a new vendor.");
    }
    if (!mailingAddress) {
      throw new Error("Mailing address is required for a new vendor.");
    }
    if (!vendorDocuments) {
      throw new Error("Vendor document details are required for a new vendor.");
    }
  }

  return {
    ...input,
    campus,
    contact,
    campusOption,
    state,
    stateOption,
    nonprofit,
    nonprofitOption,
    daysOffered,
    dayOptions,
    clubSession,
    sessionOption,
    startDate,
    endDate,
    email,
    vendorName: requiredText(input.vendorName, "Vendor name"),
    legalName: requiredText(input.legalName, "Legal business name"),
    contactName: requiredText(input.contactName, "Vendor contact"),
    phone: requiredText(input.phone, "Vendor phone"),
    club: requiredText(input.club, "Club name"),
    instructorNames: requiredText(input.instructorNames, "Instructor names"),
    tuition: requiredText(input.tuition, "Per-student tuition"),
    fein,
    physicalAddress,
    mailingAddress,
    vendorDocuments,
    notes: optionalText(input.notes, "Additional notes", 5000),
  };
}

export async function createClubRequest(
  input: NewClubRequestInput,
  submittedBy: string,
  campusContacts?: CampusContact[],
) {
  const request = validateNewRequest(input, campusContacts);
  const customFields: Record<string, string | string[]> = {
    [FIELD_GIDS.status]: NEW_REQUEST_STATUS_OPTION_GID,
    [FIELD_GIDS.campus]: request.campusOption,
    [FIELD_GIDS.state]: [request.stateOption],
    [FIELD_GIDS.vendorName]: request.vendorName,
    [FIELD_GIDS.legalName]: request.legalName,
    [FIELD_GIDS.contactName]: request.contactName,
    [FIELD_GIDS.phone]: request.phone,
    [FIELD_GIDS.email]: request.email,
    [FIELD_GIDS.clubs]: request.club,
    [FIELD_GIDS.nonprofit]: request.nonprofitOption,
    [FIELD_GIDS.daysOffered]: request.dayOptions,
    [FIELD_GIDS.clubSession]: request.sessionOption,
    [FIELD_GIDS.instructorNames]: request.instructorNames,
    [FIELD_GIDS.tuition]: request.tuition,
    [FIELD_GIDS.dsoContact]: [request.contact.asanaGid],
  };

  const optionalFields: Array<[string, string]> = [
    [FIELD_GIDS.vendorDocuments, request.vendorDocuments],
    [FIELD_GIDS.physicalAddress, request.physicalAddress],
    [FIELD_GIDS.mailingAddress, request.mailingAddress],
    [FIELD_GIDS.fein, request.fein],
  ];
  optionalFields.forEach(([gid, value]) => {
    if (value) customFields[gid] = value;
  });

  const notes = [
    `Submitted from the Vendor Club Approval Manager as an “Add new ${request.kind}” request.`,
    `Submitted by: ${submittedBy || "Authenticated workspace user"}`,
    "",
    "Vendor details",
    `Vendor/organization: ${request.vendorName}`,
    `Legal business name: ${request.legalName}`,
    `Nonprofit: ${request.nonprofit}`,
    `FEIN: ${request.fein || "Already on file / not supplied"}`,
    `Physical address: ${request.physicalAddress || "Already on file / not supplied"}`,
    `Mailing address: ${request.mailingAddress || "Already on file / not supplied"}`,
    `Contact: ${request.contactName}`,
    `Email: ${request.email}`,
    `Phone: ${request.phone}`,
    `Document package: ${request.vendorDocuments || "Already on file / not supplied"}`,
    "",
    "Club details",
    `Club: ${request.club}`,
    `Campus: ${request.campus}, ${request.state}`,
    `Session: ${request.clubSession}`,
    `Dates: ${request.startDate} through ${request.endDate}`,
    `Days offered: ${request.daysOffered.join(", ")}`,
    `Instructor(s): ${request.instructorNames}`,
    `Per-student tuition: ${request.tuition}`,
    ...(request.notes ? ["", "Additional notes", request.notes] : []),
  ].join("\n");

  const created = await asanaFetch<AsanaTask>(
    `/tasks?opt_fields=${encodeURIComponent("gid,name,permalink_url")}`,
    {
      method: "POST",
      body: JSON.stringify({
        data: {
          name: `${request.vendorName} — ${request.club} — ${request.campus}`,
          notes,
          projects: [ASANA_PROJECT_GID],
          assignee: PROCUREMENT_OWNER.gid,
          start_on: request.startDate,
          due_on: request.endDate,
          custom_fields: customFields,
        },
      }),
    },
  );

  await asanaFetch(`/sections/${NEW_REQUEST_SECTION_GID}/addTask`, {
    method: "POST",
    body: JSON.stringify({ data: { task: created.data.gid } }),
  }).catch(() => undefined);

  return created.data;
}

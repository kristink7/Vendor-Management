import {
  CAMPUS_CONTACTS,
  normalizeCampus,
  ROLE_STAGE_TARGETS,
  type AccessContact,
  type AssignmentDirectory,
  type ClubRequest,
  type RoleKey,
  type StageKey,
} from "./vendor-clubs";

export const SYSTEM_ADMIN_EMAIL = "kristin.kiesler@vertexeducation.com";

export const DEFAULT_ACCESS_CONTACTS: AccessContact[] = [
  {
    email: "autumn.barber@vertexeducation.com",
    name: "Autumn Barber",
    permission: "Executive",
  },
  {
    email: "hugh.jensen@vertexeducation.com",
    name: "Hugh Jensen",
    permission: "Executive",
  },
  {
    email: "suzanne.smailagic@vertexeducation.com",
    name: "Suzanne Smailagic",
    permission: "Executive",
  },
  {
    email: "kaden.matthews@vertexeducation.com",
    name: "Kaden Matthews",
    permission: "Procurement",
  },
  {
    email: "trisha.speir@vertexeducation.com",
    name: "Trisha Speir",
    permission: "Procurement",
  },
  {
    email: "anna.villa@vertexeducation.com",
    name: "Anna Villa",
    permission: "Accounting",
  },
];

export type SiteAccess = {
  email: string;
  displayName: string;
  isSystemAdmin: boolean;
  isExecutive: boolean;
  canTakeAction: boolean;
  actionRole: RoleKey | null;
  allowedCampuses: string[];
  asanaUserGids: string[];
  accessLabel: string;
};

const normalizeEmail = (email?: string | null) =>
  email?.trim().toLowerCase() ?? "";

export function isSystemAdminEmail(email?: string | null) {
  return normalizeEmail(email) === SYSTEM_ADMIN_EMAIL;
}

export function accessForEmail(email?: string | null): SiteAccess {
  return accessForEmailWithDirectory(email);
}

export function accessForEmailWithDirectory(
  email?: string | null,
  directory?: AssignmentDirectory,
): SiteAccess {
  const normalized = normalizeEmail(email);
  const accessContacts =
    directory?.accessContacts ?? DEFAULT_ACCESS_CONTACTS;
  const campusDirectory = directory?.campusContacts ?? CAMPUS_CONTACTS;
  if (isSystemAdminEmail(normalized)) {
    return {
      email: normalized,
      displayName: "Kristin Kiesler",
      isSystemAdmin: true,
      isExecutive: false,
      canTakeAction: true,
      actionRole: null,
      allowedCampuses: [],
      asanaUserGids: [],
      accessLabel: "System Administrator",
    };
  }

  const executive = accessContacts.find(
    (contact) =>
      normalizeEmail(contact.email) === normalized &&
      contact.permission === "Executive",
  );
  if (executive) {
    return {
      email: normalized,
      displayName: executive.name,
      isSystemAdmin: false,
      isExecutive: true,
      canTakeAction: true,
      actionRole: null,
      allowedCampuses: [],
      asanaUserGids: [],
      accessLabel: "Executive",
    };
  }

  const roleContact = accessContacts.find(
    (contact) =>
      normalizeEmail(contact.email) === normalized &&
      contact.permission !== "Executive",
  );
  if (roleContact) {
    return {
      email: normalized,
      displayName: roleContact.name,
      isSystemAdmin: false,
      isExecutive: false,
      canTakeAction: true,
      actionRole: roleContact.permission as RoleKey,
      allowedCampuses: [],
      asanaUserGids: [],
      accessLabel: `${roleContact.permission} action contact`,
    };
  }

  const campusContacts = campusDirectory.filter(
    (contact) => normalizeEmail(contact.email) === normalized,
  );
  if (campusContacts.length) {
    return {
      email: normalized,
      displayName: campusContacts[0].name,
      isSystemAdmin: false,
      isExecutive: false,
      canTakeAction: true,
      actionRole: "DSO",
      allowedCampuses: campusContacts.map((contact) => contact.campus),
      asanaUserGids: Array.from(
        new Set(campusContacts.map((contact) => contact.asanaGid)),
      ),
      accessLabel: "Campus action contact",
    };
  }

  return {
    email: normalized,
    displayName: normalized || "Workspace viewer",
    isSystemAdmin: false,
    isExecutive: false,
    canTakeAction: false,
    actionRole: null,
    allowedCampuses: [],
    asanaUserGids: [],
    accessLabel: "Workspace viewer",
  };
}

export function requestUserEmail(request: Request) {
  return normalizeEmail(
    request.headers.get("oai-authenticated-user-email"),
  );
}

const ROLE_STAGES: Record<RoleKey, StageKey[]> = {
  Procurement: [
    "new",
    "no_documents",
    "docs",
    "waiting_contract",
    "contract",
    "incomplete",
  ],
  DSO: ["roster"],
  Accounting: ["invoice"],
};

export function canActOnClubRequest(
  access: SiteAccess,
  request: ClubRequest,
  targetStage?: StageKey,
) {
  if (access.isSystemAdmin || access.isExecutive) return true;
  if (!access.canTakeAction || !access.actionRole) return false;
  if (!ROLE_STAGES[access.actionRole].includes(request.stage)) return false;

  if (access.actionRole === "DSO") {
    const assignedDsoGids = request.dsoGids ?? [];
    const isAssignedDso = assignedDsoGids.length
      ? access.asanaUserGids.some((gid) => assignedDsoGids.includes(gid))
      : access.allowedCampuses.some(
          (campus) =>
            normalizeCampus(campus).toLowerCase() ===
            normalizeCampus(request.campus).toLowerCase(),
        );
    if (!isAssignedDso) return false;
  }

  if (!targetStage) return true;
  return (
    targetStage !== request.stage &&
    ROLE_STAGE_TARGETS[access.actionRole].includes(targetStage)
  );
}

export function canCreateClubRequest(access: SiteAccess, campus: string) {
  if (access.isSystemAdmin || access.isExecutive) {
    return Boolean(normalizeCampus(campus));
  }
  if (!access.canTakeAction || access.actionRole !== "DSO") return false;
  return access.allowedCampuses.some(
    (allowedCampus) =>
      normalizeCampus(allowedCampus).toLowerCase() ===
      normalizeCampus(campus).toLowerCase(),
  );
}

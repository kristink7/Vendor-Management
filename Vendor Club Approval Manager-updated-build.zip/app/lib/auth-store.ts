import { SYSTEM_ADMIN_EMAIL } from "./access";

const SESSION_COOKIE = "vc_access";
const SESSION_TTL_SECONDS = 12 * 60 * 60;
const ATTEMPT_WINDOW_MS = 15 * 60 * 1000;
const MAX_ATTEMPTS = 5;
const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const PBKDF2_ITERATIONS = 100_000;

type RuntimeEnv = {
  DB?: D1Database;
  AUTH_PEPPER?: string;
  BOOTSTRAP_ADMIN_CODE?: string;
};

type InviteRow = {
  email: string;
  role: "admin" | "user";
  code_hash: string;
  code_hint: string;
  status: "active" | "revoked";
  expires_at: string | null;
  created_at: string;
  updated_at: string;
  last_used_at: string | null;
  created_by: string;
};

type AttemptRow = {
  failures: number;
  window_started: string;
  locked_until: string | null;
};

type SessionRow = {
  email: string;
  role: "admin" | "user";
  expires_at: string;
};

export type AccessInvite = {
  email: string;
  role: "admin" | "user";
  codeHint: string;
  status: "active" | "revoked" | "expired";
  expiresAt: string | null;
  createdAt: string;
  updatedAt: string;
  lastUsedAt: string | null;
  createdBy: string;
};

export type SessionPrincipal = {
  email: string;
  role: "admin" | "user";
  expiresAt: string;
};

export class AuthError extends Error {
  status: number;
  retryAfter?: number;

  constructor(message: string, status = 401, retryAfter?: number) {
    super(message);
    this.status = status;
    this.retryAfter = retryAfter;
  }
}
function normalizeEmail(value?: string | null) {
  return value?.trim().toLowerCase() ?? "";
}

function normalizeCode(value?: string | null) {
  return value?.toUpperCase().replace(/[^A-Z0-9]/g, "") ?? "";
}

function validEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function bytesToHex(bytes: Uint8Array) {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function hexToBytes(value: string) {
  if (!/^[0-9a-f]+$/i.test(value) || value.length % 2) return new Uint8Array();
  return Uint8Array.from(
    value.match(/.{2}/g) ?? [],
    (pair) => Number.parseInt(pair, 16),
  );
}

function bytesToBase64Url(bytes: Uint8Array) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function constantTimeEqual(left: string, right: string) {
  const max = Math.max(left.length, right.length);
  let mismatch = left.length ^ right.length;
  for (let index = 0; index < max; index += 1) {
    mismatch |= (left.charCodeAt(index) || 0) ^ (right.charCodeAt(index) || 0);
  }
  return mismatch === 0;
}

async function runtimeEnvironment(): Promise<RuntimeEnv> {
  try {
    const { env } = await import("cloudflare:workers");
    return env as RuntimeEnv;
  } catch {
    return {};
  }
}

async function database(explicitDatabase?: D1Database) {
  if (explicitDatabase) return explicitDatabase;
  return (await runtimeEnvironment()).DB;
}

async function requiredDatabase(explicitDatabase?: D1Database) {
  const db = await database(explicitDatabase);
  if (!db) throw new AuthError("Access control is temporarily unavailable.", 503);
  return db;
}

async function secret(name: "AUTH_PEPPER" | "BOOTSTRAP_ADMIN_CODE") {
  const runtime = await runtimeEnvironment();
  const configured = runtime[name] ?? process.env[name];
  if (configured?.trim()) return configured.trim();
  if (process.env.NODE_ENV === "development") {
    return name === "AUTH_PEPPER"
      ? "local-development-pepper-do-not-use-in-production"
      : "LOCAL-ADMIN-2026";
  }
  return "";
}

export async function ensureAuthSchema(explicitDatabase?: D1Database) {
  const db = await requiredDatabase(explicitDatabase);
  await db.batch([
    db.prepare(`
      CREATE TABLE IF NOT EXISTS access_invites (
        email TEXT PRIMARY KEY NOT NULL,
        role TEXT NOT NULL,
        code_hash TEXT NOT NULL,
        code_hint TEXT NOT NULL,
        status TEXT NOT NULL,
        expires_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        last_used_at TEXT,
        created_by TEXT NOT NULL
      )
    `),
    db.prepare(`
      CREATE TABLE IF NOT EXISTS access_sessions (
        id_hash TEXT PRIMARY KEY NOT NULL,
        email TEXT NOT NULL,
        role TEXT NOT NULL,
        created_at TEXT NOT NULL,
        expires_at TEXT NOT NULL
      )
    `),
    db.prepare(`
      CREATE TABLE IF NOT EXISTS access_attempts (
        identifier TEXT PRIMARY KEY NOT NULL,
        failures INTEGER NOT NULL,
        window_started TEXT NOT NULL,
        locked_until TEXT
      )
    `),
    db.prepare(
      "CREATE INDEX IF NOT EXISTS access_sessions_email_idx ON access_sessions (email)",
    ),
    db.prepare(
      "CREATE INDEX IF NOT EXISTS access_sessions_expires_idx ON access_sessions (expires_at)",
    ),
  ]);
  return db;
}

async function hmac(value: string, pepper: string) {
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(pepper),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const digest = await crypto.subtle.sign("HMAC", key, encoder.encode(value));
  return bytesToHex(new Uint8Array(digest));
}

async function sha256(value: string) {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(value),
  );
  return bytesToHex(new Uint8Array(digest));
}

async function legacyCodeHash(email: string, code: string) {
  const pepper = await secret("AUTH_PEPPER");
  if (!pepper) throw new AuthError("Access control is not configured.", 503);
  return hmac(`${normalizeEmail(email)}\n${normalizeCode(code)}`, pepper);
}

async function derivedCodeHash(
  email: string,
  code: string,
  salt: Uint8Array,
  iterations = PBKDF2_ITERATIONS,
) {
  const pepper = await secret("AUTH_PEPPER");
  if (!pepper) throw new AuthError("Access control is not configured.", 503);
  const material = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(`${normalizeCode(code)}\n${pepper}`),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const combinedSalt = new TextEncoder().encode(
    `${normalizeEmail(email)}\n${bytesToHex(salt)}`,
  );
  const digest = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      hash: "SHA-256",
      iterations,
      salt: combinedSalt,
    },
    material,
    256,
  );
  return bytesToHex(new Uint8Array(digest));
}

async function newCodeHash(email: string, code: string) {
  const salt = new Uint8Array(16);
  crypto.getRandomValues(salt);
  const digest = await derivedCodeHash(email, normalizeCode(code), salt);
  return `pbkdf2-sha256$${PBKDF2_ITERATIONS}$${bytesToHex(salt)}$${digest}`;
}

async function verifyCodeHash(stored: string, email: string, code: string) {
  const [algorithm, iterationsValue, saltValue, expected] = stored.split("$");
  if (algorithm === "pbkdf2-sha256" && expected) {
    const iterations = Number(iterationsValue);
    const salt = hexToBytes(saltValue);
    if (
      !Number.isInteger(iterations) ||
      iterations < 100_000 ||
      iterations > PBKDF2_ITERATIONS ||
      salt.length < 16
    ) {
      return false;
    }
    return constantTimeEqual(
      await derivedCodeHash(email, code, salt, iterations),
      expected,
    );
  }
  return constantTimeEqual(await legacyCodeHash(email, code), stored);
}

function cookieValue(cookieHeader?: string | null) {
  if (!cookieHeader) return "";
  for (const entry of cookieHeader.split(";")) {
    const [name, ...valueParts] = entry.trim().split("=");
    if (name === SESSION_COOKIE) return valueParts.join("=");
  }
  return "";
}

function sessionCookie(token: string, maxAge = SESSION_TTL_SECONDS) {
  const secure = process.env.NODE_ENV === "development" ? "" : "; Secure";
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secure}`;
}

function expiredInvite(row: InviteRow, now = Date.now()) {
  return Boolean(row.expires_at && Date.parse(row.expires_at) <= now);
}

function publicInvite(row: InviteRow): AccessInvite {
  return {
    email: row.email,
    role: row.role,
    codeHint: row.code_hint,
    status: expiredInvite(row) ? "expired" : row.status,
    expiresAt: row.expires_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    lastUsedAt: row.last_used_at,
    createdBy: row.created_by,
  };
}

function generateCode() {
  const random = new Uint8Array(26);
  crypto.getRandomValues(random);
  const characters = Array.from(
    random,
    (byte) => CODE_ALPHABET[byte % CODE_ALPHABET.length],
  ).join("");
  return [
    characters.slice(0, 5),
    characters.slice(5, 10),
    characters.slice(10, 15),
    characters.slice(15, 20),
    characters.slice(20),
  ].join("-");
}

function clientAddress(request: Request) {
  return (
    request.headers.get("cf-connecting-ip") ??
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    "unknown"
  );
}

async function attemptIdentifier(email: string, request: Request) {
  return sha256(`${normalizeEmail(email)}\n${clientAddress(request)}`);
}

async function currentAttempt(
  db: D1Database,
  identifier: string,
): Promise<AttemptRow | null> {
  return db
    .prepare(
      `SELECT failures, window_started, locked_until
       FROM access_attempts WHERE identifier = ?`,
    )
    .bind(identifier)
    .first<AttemptRow>();
}

async function recordFailure(db: D1Database, identifier: string) {
  const now = Date.now();
  const existing = await currentAttempt(db, identifier);
  const windowStarted = existing ? Date.parse(existing.window_started) : 0;
  const inWindow = now - windowStarted < ATTEMPT_WINDOW_MS;
  const failures = inWindow ? existing!.failures + 1 : 1;
  const lockedUntil =
    failures >= MAX_ATTEMPTS
      ? new Date(now + ATTEMPT_WINDOW_MS).toISOString()
      : null;
  await db
    .prepare(
      `INSERT INTO access_attempts
       (identifier, failures, window_started, locked_until)
       VALUES (?, ?, ?, ?)
       ON CONFLICT(identifier) DO UPDATE SET
         failures = excluded.failures,
         window_started = excluded.window_started,
         locked_until = excluded.locked_until`,
    )
    .bind(
      identifier,
      failures,
      inWindow && existing
        ? existing.window_started
        : new Date(now).toISOString(),
      lockedUntil,
    )
    .run();
}

async function assertNotLocked(db: D1Database, identifier: string) {
  const attempt = await currentAttempt(db, identifier);
  const lockedUntil = attempt?.locked_until
    ? Date.parse(attempt.locked_until)
    : 0;
  if (lockedUntil > Date.now()) {
    const retryAfter = Math.max(1, Math.ceil((lockedUntil - Date.now()) / 1000));
    throw new AuthError(
      "Too many attempts. Try again in a few minutes.",
      429,
      retryAfter,
    );
  }
}

async function createSession(
  db: D1Database,
  email: string,
  role: "admin" | "user",
) {
  const tokenBytes = new Uint8Array(32);
  crypto.getRandomValues(tokenBytes);
  const token = bytesToBase64Url(tokenBytes);
  const idHash = await sha256(token);
  const createdAt = new Date();
  const expiresAt = new Date(
    createdAt.getTime() + SESSION_TTL_SECONDS * 1000,
  );
  await db.batch([
    db
      .prepare(
        `INSERT INTO access_sessions
         (id_hash, email, role, created_at, expires_at)
         VALUES (?, ?, ?, ?, ?)`,
      )
      .bind(
        idHash,
        email,
        role,
        createdAt.toISOString(),
        expiresAt.toISOString(),
      ),
    db
      .prepare("DELETE FROM access_sessions WHERE expires_at <= ?")
      .bind(createdAt.toISOString()),
  ]);
  return {
    principal: {
      email,
      role,
      expiresAt: expiresAt.toISOString(),
    } satisfies SessionPrincipal,
    cookie: sessionCookie(token),
  };
}

export function hasTrustedSameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin) return false;
  return request.headers.get("sec-fetch-site") !== "cross-site";
}

export async function authenticateAccess(
  request: Request,
  emailValue: string,
  codeValue: string,
) {
  const email = normalizeEmail(emailValue);
  const normalizedAccessCode = normalizeCode(codeValue);
  if (!validEmail(email) || normalizedAccessCode.length < 8) {
    throw new AuthError("That email and access code do not match.");
  }

  const db = await ensureAuthSchema();
  const identifier = await attemptIdentifier(email, request);
  await assertNotLocked(db, identifier);

  const row = await db
    .prepare(
      `SELECT email, role, code_hash, code_hint, status, expires_at,
              created_at, updated_at, last_used_at, created_by
       FROM access_invites WHERE email = ?`,
    )
    .bind(email)
    .first<InviteRow>();

  let role: "admin" | "user" | null = null;
  let matches = false;
  let usedAdminRecovery = false;
  const bootstrapCode =
    email === SYSTEM_ADMIN_EMAIL
      ? normalizeCode(await secret("BOOTSTRAP_ADMIN_CODE"))
      : "";
  const bootstrapMatches =
    email === SYSTEM_ADMIN_EMAIL &&
    Boolean(bootstrapCode) &&
    constantTimeEqual(normalizedAccessCode, bootstrapCode);
  if (bootstrapMatches) {
    matches = true;
    role = "admin";
    usedAdminRecovery = Boolean(row);
  } else if (row && row.status === "active" && !expiredInvite(row)) {
    matches = await verifyCodeHash(row.code_hash, email, normalizedAccessCode);
    role = row.role;
  } else {
    await newCodeHash(email, normalizedAccessCode);
  }

  if (!matches || !role) {
    await recordFailure(db, identifier);
    throw new AuthError("That email and access code do not match.");
  }

  const now = new Date().toISOString();
  const statements: D1PreparedStatement[] = [
    db
      .prepare("DELETE FROM access_attempts WHERE identifier = ?")
      .bind(identifier),
  ];
  if (!row) {
    const formattedBootstrapCode = codeValue.trim().toUpperCase();
    statements.push(
      db
        .prepare(
          `INSERT INTO access_invites
           (email, role, code_hash, code_hint, status, expires_at,
            created_at, updated_at, last_used_at, created_by)
           VALUES (?, 'admin', ?, ?, 'active', NULL, ?, ?, ?, 'system bootstrap')`,
        )
        .bind(
          email,
          await newCodeHash(email, formattedBootstrapCode),
          normalizeCode(formattedBootstrapCode).slice(-4),
          now,
          now,
          now,
        ),
    );
  } else {
    if (usedAdminRecovery) {
      statements.push(
        db
          .prepare(
            `UPDATE access_invites
             SET role = 'admin', code_hash = ?, code_hint = ?, status = 'active',
                 expires_at = NULL, updated_at = ?, last_used_at = ?,
                 created_by = 'system recovery'
             WHERE email = ?`,
          )
          .bind(
            await newCodeHash(email, normalizedAccessCode),
            normalizedAccessCode.slice(-4),
            now,
            now,
            email,
          ),
        db.prepare("DELETE FROM access_sessions WHERE email = ?").bind(email),
      );
    } else {
      statements.push(
        db
          .prepare("UPDATE access_invites SET last_used_at = ? WHERE email = ?")
          .bind(now, email),
      );
      if (!row.code_hash.startsWith("pbkdf2-sha256$")) {
        statements.push(
          db
            .prepare("UPDATE access_invites SET code_hash = ? WHERE email = ?")
            .bind(await newCodeHash(email, normalizedAccessCode), email),
        );
      }
    }
  }
  await db.batch(statements);
  return createSession(db, email, role);
}

export async function getSessionFromCookieHeader(
  cookieHeader?: string | null,
  explicitDatabase?: D1Database,
): Promise<SessionPrincipal | null> {
  const token = cookieValue(cookieHeader);
  if (!token) return null;
  const db = await database(explicitDatabase);
  if (!db) return null;
  try {
    await ensureAuthSchema(db);
    const row = await db
      .prepare(
        `SELECT sessions.email, sessions.role, sessions.expires_at
         FROM access_sessions AS sessions
         INNER JOIN access_invites AS invites ON invites.email = sessions.email
         WHERE sessions.id_hash = ?
           AND sessions.expires_at > ?
           AND invites.status = 'active'
           AND (invites.expires_at IS NULL OR invites.expires_at > ?)`,
      )
      .bind(await sha256(token), new Date().toISOString(), new Date().toISOString())
      .first<SessionRow>();
    return row
      ? { email: row.email, role: row.role, expiresAt: row.expires_at }
      : null;
  } catch {
    return null;
  }
}

export async function getRequestSession(
  request: Request,
  explicitDatabase?: D1Database,
) {
  return getSessionFromCookieHeader(
    request.headers.get("cookie"),
    explicitDatabase,
  );
}

export async function requireRequestSession(request: Request) {
  const principal = await getRequestSession(request);
  if (!principal) throw new AuthError("Sign in to continue.", 401);
  return principal;
}

export async function requireAdminSession(request: Request) {
  const principal = await requireRequestSession(request);
  if (principal.role !== "admin" || principal.email !== SYSTEM_ADMIN_EMAIL) {
    throw new AuthError("Only the System Administrator can manage access.", 403);
  }
  return principal;
}

export async function endSession(request: Request) {
  const token = cookieValue(request.headers.get("cookie"));
  const db = await database();
  if (db && token) {
    await ensureAuthSchema(db);
    await db
      .prepare("DELETE FROM access_sessions WHERE id_hash = ?")
      .bind(await sha256(token))
      .run();
  }
  return sessionCookie("", 0);
}

export async function listAccessInvites() {
  const db = await ensureAuthSchema();
  const result = await db
    .prepare(
      `SELECT email, role, code_hash, code_hint, status, expires_at,
              created_at, updated_at, last_used_at, created_by
       FROM access_invites
       ORDER BY role ASC, email ASC`,
    )
    .all<InviteRow>();
  return (result.results ?? []).map(publicInvite);
}

export async function createOrRotateInvite(
  emailValue: string,
  expiresInDays: number | null,
  createdBy: string,
) {
  const email = normalizeEmail(emailValue);
  if (!validEmail(email)) throw new AuthError("Enter a valid email address.", 400);
  if (
    expiresInDays !== null &&
    (!Number.isInteger(expiresInDays) || expiresInDays < 1 || expiresInDays > 365)
  ) {
    throw new AuthError("Choose an expiration between 1 and 365 days.", 400);
  }
  const code = generateCode();
  const now = new Date();
  const expiresAt =
    expiresInDays === null
      ? null
      : new Date(now.getTime() + expiresInDays * 24 * 60 * 60 * 1000).toISOString();
  const role = email === SYSTEM_ADMIN_EMAIL ? "admin" : "user";
  const db = await ensureAuthSchema();
  await db.batch([
    db
      .prepare(
        `INSERT INTO access_invites
         (email, role, code_hash, code_hint, status, expires_at,
          created_at, updated_at, last_used_at, created_by)
         VALUES (?, ?, ?, ?, 'active', ?, ?, ?, NULL, ?)
         ON CONFLICT(email) DO UPDATE SET
           role = excluded.role,
           code_hash = excluded.code_hash,
           code_hint = excluded.code_hint,
           status = 'active',
           expires_at = excluded.expires_at,
           updated_at = excluded.updated_at,
           last_used_at = NULL,
           created_by = excluded.created_by`,
      )
      .bind(
        email,
        role,
        await newCodeHash(email, code),
        normalizeCode(code).slice(-4),
        expiresAt,
        now.toISOString(),
        now.toISOString(),
        createdBy,
      ),
    db.prepare("DELETE FROM access_sessions WHERE email = ?").bind(email),
  ]);
  return { code, invite: publicInvite({
    email,
    role,
    code_hash: "",
    code_hint: normalizeCode(code).slice(-4),
    status: "active",
    expires_at: expiresAt,
    created_at: now.toISOString(),
    updated_at: now.toISOString(),
    last_used_at: null,
    created_by: createdBy,
  }) };
}

export async function revokeInvite(emailValue: string) {
  const email = normalizeEmail(emailValue);
  if (!validEmail(email)) throw new AuthError("Enter a valid email address.", 400);
  if (email === SYSTEM_ADMIN_EMAIL) {
    throw new AuthError("The System Administrator cannot be revoked.", 400);
  }
  const db = await ensureAuthSchema();
  await db.batch([
    db
      .prepare(
        "UPDATE access_invites SET status = 'revoked', updated_at = ? WHERE email = ?",
      )
      .bind(new Date().toISOString(), email),
    db.prepare("DELETE FROM access_sessions WHERE email = ?").bind(email),
  ]);
}

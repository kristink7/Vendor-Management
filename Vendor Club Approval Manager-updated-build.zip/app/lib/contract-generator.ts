import PizZip from "pizzip";

export const AZ_CONTRACT_TEMPLATE_URL =
  "/contracts/az-26-27-vendor-contract-template.docx";

export type AzContractFields = {
  effectiveDate: string;
  campus: string;
  vendorName: string;
  ein: string;
  entityType: "For-Profit" | "Non-Profit" | "";
  facilityLine1: string;
  facilityLine2: string;
  premises: string;
  daysHours: string;
  signerName: string;
  signatureDate: string;
};

const DOCX_MIME =
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

const markerNames = [
  "effective_date",
  "campus",
  "facility_line_1",
  "facility_line_2",
  "premises",
  "days_hours",
  "vendor_and_ein",
  "entity_type",
  "signer_name",
  "signature_date",
] as const;

function oneLine(value: string) {
  return value.replace(/\s+/g, " ").trim();
}

function xmlEscape(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function formatContractDate(value: string) {
  if (!value) return "______________";
  const date = new Date(`${value.slice(0, 10)}T12:00:00`);
  if (Number.isNaN(date.getTime())) return oneLine(value);
  return new Intl.DateTimeFormat("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  }).format(date);
}

function paddedLine(value: string, targetLength = 76) {
  const normalized = oneLine(value);
  if (!normalized) return "_".repeat(targetLength);
  return `${normalized} ${"_".repeat(Math.max(8, targetLength - normalized.length - 1))}`;
}

function replacementValues(fields: AzContractFields) {
  return {
    effective_date: formatContractDate(fields.effectiveDate),
    campus: oneLine(fields.campus) || "________________",
    facility_line_1: paddedLine(fields.facilityLine1),
    facility_line_2: paddedLine(fields.facilityLine2),
    premises: paddedLine(fields.premises),
    days_hours: oneLine(fields.daysHours) || "__________________________",
    vendor_and_ein: paddedLine(
      [oneLine(fields.vendorName), fields.ein ? `EIN ${oneLine(fields.ein)}` : ""]
        .filter(Boolean)
        .join(" · "),
      70,
    ),
    entity_type: paddedLine(fields.entityType, 70),
    signer_name: paddedLine(fields.signerName, 70),
    signature_date: paddedLine(
      fields.signatureDate ? formatContractDate(fields.signatureDate) : "",
      70,
    ),
  };
}

export async function generateAzVendorContract(fields: AzContractFields) {
  const response = await fetch(AZ_CONTRACT_TEMPLATE_URL, { cache: "force-cache" });
  if (!response.ok) {
    throw new Error("The Arizona contract template could not be loaded.");
  }

  const zip = new PizZip(await response.arrayBuffer());
  const documentPart = zip.file("word/document.xml");
  if (!documentPart) {
    throw new Error("The Arizona contract template is missing its document content.");
  }

  let documentXml = documentPart.asText();
  const values = replacementValues(fields);
  for (const markerName of markerNames) {
    const marker = `{${markerName}}`;
    if (!documentXml.includes(marker)) {
      throw new Error(`The contract template is missing ${markerName}.`);
    }
    documentXml = documentXml.replace(marker, xmlEscape(values[markerName]));
  }

  if (markerNames.some((markerName) => documentXml.includes(`{${markerName}}`))) {
    throw new Error("The contract template contains an unfilled field.");
  }

  zip.file("word/document.xml", documentXml);
  return zip.generate({ type: "blob", mimeType: DOCX_MIME });
}

export function contractFileName(fields: AzContractFields) {
  const details = [fields.vendorName, fields.campus]
    .map((value) => oneLine(value).replace(/[<>:"/\\|?*]+/g, "-"))
    .filter(Boolean)
    .join(" - ");
  return `AZ 26_27 Vendor Contract${details ? ` - ${details}` : ""}.docx`;
}

export function emailDraftLink(
  fields: AzContractFields,
  recipient: string,
  filename: string,
) {
  const campus = oneLine(fields.campus);
  const vendor = oneLine(fields.vendorName);
  const subject = `Legacy Traditional Schools Arizona vendor contract${campus ? ` — ${campus}` : ""}`;
  const contractDescription = [
    vendor ? `for ${vendor}` : "",
    campus ? `at Legacy Traditional School - ${campus}` : "",
  ]
    .filter(Boolean)
    .join(" ");
  const body = [
    `Hello${fields.signerName ? ` ${oneLine(fields.signerName)}` : ""},`,
    "",
    `Attached is the Arizona 2026–2027 vendor contract${contractDescription ? ` ${contractDescription}` : ""}.`,
    "",
    "Please complete any blank fields, review the agreement, sign the vendor signature line, and return the completed contract with the required documents.",
    "",
    `File to attach: ${filename}`,
    "",
    "Thank you,",
  ].join("\n");
  return `mailto:${encodeURIComponent(recipient.trim())}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

import { DEFAULT_ACCESS_CONTACTS } from "./access";
import {
  CAMPUS_CONTACTS,
  normalizeCampus,
  type AccessContact,
  type AccessPermission,
  type AssignmentDirectory,
  type CampusContact,
} from "./vendor-clubs";

type RuntimeEnv = {
  DB?: D1Database;
};

type AccessRow = {
  email: string;
  display_name: string;
  permission: AccessPermission;
};

type CampusRow = {
  campus: string;
  state: string;
  contact_name: string;
  contact_role: string;
  email: string;
  asana_gid: string;
};

const ACCESS_PERMISSIONS: AccessPermission[] = [
  "Executive",
  "Procurement",
  "Accounting",
];

const normalizedEmail = (value: string) => value.trim().toLowerCase();

async function database() {
  try {
    const { env } = await import("cloudflare:workers");
    return (env as RuntimeEnv).DB;
  } catch {
    return undefined;
  }
}

function defaultDirectory(): AssignmentDirectory {
  return {
    accessContacts: DEFAULT_ACCESS_CONTACTS.map((contact) => ({ ...contact })),
    campusContacts: CAMPUS_CONTACTS.map((contact) => ({ ...contact })),
  };
}

async function ensureDirectorySchema(db: D1Database) {
  await db.batch([
    db.prepare(`
      CREATE TABLE IF NOT EXISTS access_contacts (
        email TEXT PRIMARY KEY NOT NULL,
        display_name TEXT NOT NULL,
        permission TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    `),
    db.prepare(`
      CREATE TABLE IF NOT EXISTS campus_assignments (
        campus TEXT PRIMARY KEY NOT NULL,
        state TEXT NOT NULL,
        contact_name TEXT NOT NULL,
        contact_role TEXT NOT NULL,
        email TEXT NOT NULL,
        asana_gid TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    `),
    db.prepare(
      "CREATE INDEX IF NOT EXISTS campus_assignments_email_idx ON campus_assignments (email)",
    ),
  ]);

  const [accessCount, campusCount] = await Promise.all([
    db
      .prepare("SELECT COUNT(*) AS count FROM access_contacts")
      .first<{ count: number }>(),
    db
      .prepare("SELECT COUNT(*) AS count FROM campus_assignments")
      .first<{ count: number }>(),
  ]);
  const updatedAt = new Date().toISOString();
  const seedStatements: D1PreparedStatement[] = [];
  if (!accessCount?.count) {
    seedStatements.push(
      ...DEFAULT_ACCESS_CONTACTS.map((contact) =>
        db
          .prepare(
            `INSERT OR IGNORE INTO access_contacts
             (email, display_name, permission, updated_at)
             VALUES (?, ?, ?, ?)`,
          )
          .bind(
            normalizedEmail(contact.email),
            contact.name,
            contact.permission,
            updatedAt,
          ),
      ),
    );
  }
  if (!campusCount?.count) {
    seedStatements.push(
      ...CAMPUS_CONTACTS.map((contact) =>
        db
          .prepare(
            `INSERT OR IGNORE INTO campus_assignments
             (campus, state, contact_name, contact_role, email, asana_gid, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
          )
          .bind(
            contact.campus,
            contact.state,
            contact.name,
            contact.role,
            normalizedEmail(contact.email),
            contact.asanaGid,
            updatedAt,
          ),
      ),
    );
  }
  if (seedStatements.length) await db.batch(seedStatements);
}

export async function getAssignmentDirectory(): Promise<AssignmentDirectory> {
  const db = await database();
  if (!db) return defaultDirectory();

  try {
    await ensureDirectorySchema(db);
    const [accessResult, campusResult] = await Promise.all([
      db
        .prepare(
          `SELECT email, display_name, permission
           FROM access_contacts
           ORDER BY permission, display_name`,
        )
        .all<AccessRow>(),
      db
        .prepare(
          `SELECT campus, state, contact_name, contact_role, email, asana_gid
           FROM campus_assignments
           ORDER BY state, campus`,
        )
        .all<CampusRow>(),
    ]);

    return {
      accessContacts: (accessResult.results ?? []).map((row) => ({
        email: row.email,
        name: row.display_name,
        permission: row.permission,
      })),
      campusContacts: (campusResult.results ?? []).map((row) => ({
        campus: row.campus,
        state: row.state,
        name: row.contact_name,
        role: row.contact_role,
        email: row.email,
        asanaGid: row.asana_gid,
      })),
    };
  } catch {
    return defaultDirectory();
  }
}

async function requireDatabase() {
  const db = await database();
  if (!db) {
    throw new Error("The assignment directory database is not available.");
  }
  return db;
}

function validEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

export async function saveAccessContact(contact: AccessContact) {
  const db = await requireDatabase();
  await ensureDirectorySchema(db);
  const email = normalizedEmail(contact.email);
  const name = contact.name.trim();
  if (!validEmail(email)) throw new Error("Enter a valid email address.");
  if (!name) throw new Error("Name is required.");
  if (!ACCESS_PERMISSIONS.includes(contact.permission)) {
    throw new Error("Choose a valid permission level.");
  }

  await db
    .prepare(
      `INSERT INTO access_contacts
       (email, display_name, permission, updated_at)
       VALUES (?, ?, ?, ?)
       ON CONFLICT(email) DO UPDATE SET
         display_name = excluded.display_name,
         permission = excluded.permission,
         updated_at = excluded.updated_at`,
    )
    .bind(email, name, contact.permission, new Date().toISOString())
    .run();
}

export async function deleteAccessContact(emailValue: string) {
  const db = await requireDatabase();
  await ensureDirectorySchema(db);
  const email = normalizedEmail(emailValue);
  if (!validEmail(email)) throw new Error("Enter a valid email address.");
  await db
    .prepare("DELETE FROM access_contacts WHERE email = ?")
    .bind(email)
    .run();
}

export async function saveCampusAssignment(contact: CampusContact) {
  const db = await requireDatabase();
  await ensureDirectorySchema(db);
  const campus = normalizeCampus(contact.campus);
  const knownCampus = CAMPUS_CONTACTS.find(
    (item) => item.campus.toLowerCase() === campus.toLowerCase(),
  );
  if (!knownCampus) throw new Error("Choose a valid LTS campus.");

  const email = normalizedEmail(contact.email);
  const name = contact.name.trim();
  const role = contact.role.trim();
  const asanaGid = contact.asanaGid.trim();
  if (!name) throw new Error("Contact name is required.");
  if (!role) throw new Error("Contact role is required.");
  if (!validEmail(email)) throw new Error("Enter a valid email address.");
  if (!/^\d+$/.test(asanaGid)) {
    throw new Error("Enter the contact’s numeric Asana user ID.");
  }

  await db
    .prepare(
      `INSERT INTO campus_assignments
       (campus, state, contact_name, contact_role, email, asana_gid, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(campus) DO UPDATE SET
         state = excluded.state,
         contact_name = excluded.contact_name,
         contact_role = excluded.contact_role,
         email = excluded.email,
         asana_gid = excluded.asana_gid,
         updated_at = excluded.updated_at`,
    )
    .bind(
      knownCampus.campus,
      knownCampus.state,
      name,
      role,
      email,
      asanaGid,
      new Date().toISOString(),
    )
    .run();
}

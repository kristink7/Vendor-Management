"use client";

import { useState } from "react";

export default function AccessGate() {
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, code }),
      });
      const payload = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(payload.error || "Sign-in failed.");
      window.location.assign("/");
    } catch (signInError) {
      setError(
        signInError instanceof Error
          ? signInError.message
          : "Sign-in failed.",
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="access-gate">
      <header className="access-gate-header">
        <div className="access-gate-brand" aria-label="Vendor Clubs">
          <span className="brand-mark">VC</span>
          <span>
            <strong>Vendor Clubs.</strong>
            <small>Approval manager</small>
          </span>
        </div>
        <span className="access-gate-status">INVITATION REQUIRED</span>
      </header>

      <section className="access-gate-body">
        <div className="access-gate-intro">
          <p className="eyebrow">CONTROLLED VESTIBULE</p>
          <h1>Authorized access only.</h1>
          <p>
            Vendor and club approvals contain operational information. Enter
            the invited email address and access code provided by the System
            Administrator.
          </p>
          <div className="access-gate-rule" />
          <dl>
            <div><dt>01</dt><dd>Email must match an active invitation</dd></div>
            <div><dt>02</dt><dd>Access codes are case-insensitive</dd></div>
            <div><dt>03</dt><dd>Sessions expire after twelve hours</dd></div>
          </dl>
        </div>

        <form className="access-gate-form" onSubmit={submit}>
          <div>
            <p className="eyebrow">SIGN IN</p>
            <h2>Enter the workspace</h2>
            <p>Both fields are required. Uninvited visitors are blocked.</p>
          </div>
          <label>
            <span>Email address</span>
            <input
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="name@organization.com"
            />
          </label>
          <label>
            <span>Access code</span>
            <input
              type="text"
              autoComplete="one-time-code"
              autoCapitalize="characters"
              spellCheck={false}
              required
              value={code}
              onChange={(event) => setCode(event.target.value)}
              placeholder="XXXX-XXXX-XXXX"
            />
          </label>
          {error && <div className="access-gate-error" role="alert">{error}</div>}
          <button type="submit" disabled={busy}>
            {busy ? "Checking access…" : "Continue to Vendor Clubs"}
          </button>
          <small>
            Need access? Contact the Vendor Clubs System Administrator.
          </small>
        </form>
      </section>
    </main>
  );
}

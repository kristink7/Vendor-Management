"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ASANA_PROJECT_URL,
  DAY_OPTION_GIDS,
  nextStage,
  normalizeCampus,
  ROLE_STAGE_TARGETS,
  SESSION_OPTION_GIDS,
  STAGES,
  stageDefinition,
  UPLOADED_DOCUMENT_OPTIONS,
  type AccessContact,
  type AccessPermission,
  type AssignmentDirectory,
  type CampusContact,
  type ClubRequest,
  type EditableRequestFields,
  type NewClubRequestInput,
  type NewRequestKind,
  type RoleKey,
  type StageKey,
} from "@/app/lib/vendor-clubs";
import { SEED_REQUESTS } from "@/app/lib/seed-data";
import {
  contractFileName,
  emailDraftLink,
  generateAzVendorContract,
  type AzContractFields,
} from "@/app/lib/contract-generator";
import type { AccessInvite } from "@/app/lib/auth-store";

type ViewKey =
  | "desk"
  | "pipeline"
  | "workflow"
  | "contracts"
  | "vendors"
  | "all"
  | "assignments"
  | "access"
  | "guide";
type DeskRole = RoleKey | "Executive" | "All roles";

type SyncResponse = {
  configured: boolean;
  syncedAt?: string;
  requests?: ClubRequest[];
  error?: string;
};

const ROLE_STAGE: Record<RoleKey, StageKey[]> = {
  Procurement: [
    "new",
    "no_documents",
    "docs",
    "waiting_contract",
    "contract",
    "incomplete",
  ],
  DSO: ["roster"],
  Accounting: ["invoice"],
};

type WorkflowOwner = "dso" | "vendor" | "procurement" | "accounting" | "shared";
type WorkflowSystem = "Asana" | "Email" | "Workday";

type WorkflowStep = {
  id: number;
  title: string;
  owner: string;
  ownerKey: WorkflowOwner;
  summary: string;
  description: string;
  systems: WorkflowSystem[];
  details: Array<{ label: string; value: string }>;
  gate?: string;
  branches?: Array<{ label: string; value: string }>;
  note?: string;
  noteTone?: "attention" | "standard";
};

type WorkflowPhase = {
  id: string;
  label: string;
  shortLabel: string;
  ownerSummary: string;
  steps: WorkflowStep[];
};

const WORKFLOW_PHASES: WorkflowPhase[] = [
  {
    id: "outreach",
    label: "Phase A · Outreach & intake",
    shortLabel: "Outreach & intake",
    ownerSummary: "DSO + Vendor",
    steps: [
      {
        id: 1,
        title: "Send vendor intake email",
        owner: "Director of School Operations",
        ownerKey: "dso",
        summary: "DSO sends · registration link + contract + application",
        description:
          "The DSO sends one intake email containing the Asana registration form link, LTS vendor contract, and vendor application.",
        systems: ["Email", "Asana"],
        details: [
          {
            label: "Attachments",
            value: "LTS vendor contract and vendor application PDFs.",
          },
          {
            label: "Communication",
            value:
              "Direct DSO-to-vendor email. Procurement begins after the registration is submitted.",
          },
          {
            label: "Output",
            value:
              "The vendor has the registration form, contract, and application.",
          },
        ],
        note:
          "The DSO owns the vendor conversation. Procurement supports Workday onboarding and contract approval.",
      },
      {
        id: 2,
        title: "Complete application & upload documents",
        owner: "Vendor",
        ownerKey: "vendor",
        summary: "Vendor submits · Asana registration form",
        description:
          "The vendor completes the application, signs the LTS Agreement, and uploads the complete registration package.",
        systems: ["Asana"],
        details: [
          {
            label: "Documents",
            value:
              "Vendor application, signed agreement, COI, fingerprint clearance card for every instructor, EIN, and 501(c)(3) letter when applicable.",
          },
          {
            label: "Routing",
            value:
              "The form creates the Asana task and routes the submission to Procurement.",
          },
        ],
        note:
          "The COI must name Vertex Education and the specific LTS campus as additional insureds at $1,000,000 aggregate.",
      },
    ],
  },
  {
    id: "documentation",
    label: "Phase B · Documentation & vendor setup",
    shortLabel: "Documentation & setup",
    ownerSummary: "Procurement",
    steps: [
      {
        id: 3,
        title: "Review the registration submission",
        owner: "Procurement",
        ownerKey: "procurement",
        summary: "Procurement owns · tracked in the Asana task",
        description:
          "Procurement reviews the submitted registration package for completeness and compliance.",
        systems: ["Asana"],
        details: [
          {
            label: "Reviews",
            value:
              "Application, signed agreement, COI coverage and named insureds, FPCC per instructor, EIN, and 501(c)(3) letter when applicable.",
          },
          {
            label: "Communication",
            value:
              "The review status remains in the task until Procurement reaches the document gate.",
          },
        ],
      },
      {
        id: 4,
        title: "Document-completeness gate",
        owner: "Procurement",
        ownerKey: "procurement",
        summary: "Decision · Asana + email follow-up",
        description:
          "Procurement confirms whether every required document is complete and compliant.",
        systems: ["Asana", "Email"],
        gate: "Approval gate · Procurement",
        branches: [
          {
            label: "Complete",
            value: "Proceed to the Workday vendor check.",
          },
          {
            label: "Incomplete",
            value:
              "Request missing items through an Asana comment and direct email. The task remains open.",
          },
        ],
        details: [
          {
            label: "Hard stop",
            value:
              "Workday vendor setup does not begin until Procurement verifies the document package.",
          },
        ],
        note:
          "An incomplete package stays with Procurement until the missing items are resolved.",
        noteTone: "attention",
      },
      {
        id: 5,
        title: "Check or create the vendor in Workday",
        owner: "Procurement",
        ownerKey: "procurement",
        summary: "Procurement · Workday is the vendor master",
        description:
          "Procurement searches Workday for the vendor and creates the vendor record when one does not already exist.",
        systems: ["Workday"],
        details: [
          {
            label: "Existing vendor",
            value:
              "Verify the record is active, skip creation, and continue to contract approval.",
          },
          {
            label: "New vendor",
            value:
              "Create the Workday vendor record before the contract can be approved.",
          },
          {
            label: "Communication",
            value: "Internal Procurement action; no vendor notification.",
          },
        ],
      },
      {
        id: 6,
        title: "Approve contract pending roster review",
        owner: "Procurement",
        ownerKey: "procurement",
        summary: "Procurement · adds the campus DSO as a collaborator",
        description:
          "Procurement updates the Asana status to “Approved — pending roster review” and adds the campus DSO to the task.",
        systems: ["Asana", "Workday"],
        details: [
          {
            label: "Contract",
            value: "The executed contract is stored in Workday.",
          },
          {
            label: "Handoff",
            value:
              "Adding the campus DSO as a collaborator surfaces the Asana notification.",
          },
          {
            label: "Communication",
            value:
              "Automated Asana notification to the DSO; no manual Procurement email.",
          },
        ],
        note:
          "If the status changes but the DSO is not added, the notification is missed and the request stalls.",
        noteTone: "attention",
      },
    ],
  },
  {
    id: "roster",
    label: "Phase C · Roster & final approval",
    shortLabel: "Roster & approval",
    ownerSummary: "DSO + Vendor",
    steps: [
      {
        id: 7,
        title: "Send the roster form",
        owner: "Director of School Operations",
        ownerKey: "dso",
        summary: "Asana notification → DSO emails the vendor",
        description:
          "After the Procurement handoff, the DSO emails the vendor the Final Club Roster & Fee Submission form.",
        systems: ["Asana", "Email"],
        details: [
          {
            label: "Roster form",
            value:
              "Collects vendor information, roster file, student count, tuition, instructor names, and start/end dates.",
          },
          {
            label: "Communication",
            value: "The DSO sends the roster form link directly to the vendor.",
          },
        ],
      },
      {
        id: 8,
        title: "Submit and validate the roster",
        owner: "Vendor / DSO",
        ownerKey: "shared",
        summary: "Vendor submits · DSO validates against FPCC",
        description:
          "The vendor submits the roster. The DSO reviews all roster and fee data and validates every instructor.",
        systems: ["Asana"],
        details: [
          {
            label: "DSO validates",
            value:
              "Roster, student count, tuition, dates, and each instructor name against the fingerprint clearance card on file.",
          },
          {
            label: "Routing",
            value:
              "The submission is logged in the task and moves to the roster-validation gate.",
          },
        ],
        note:
          "No instructor works with students without a valid fingerprint clearance card on file.",
      },
      {
        id: 9,
        title: "Roster-validation gate",
        owner: "Director of School Operations",
        ownerKey: "dso",
        summary: "Decision · sets “Ready to invoice”",
        description:
          "The DSO confirms whether the roster passes validation and records the decision in Asana.",
        systems: ["Asana", "Email"],
        gate: "Approval gate · DSO",
        branches: [
          {
            label: "Passes",
            value:
              "Approve the subtask, set “Contract Approved — Ready to invoice,” and confirm approval to the vendor.",
          },
          {
            label: "Fails",
            value:
              "Return the roster to the vendor for correction. Do not approve the subtask.",
          },
        ],
        details: [
          {
            label: "Accounting trigger",
            value:
              "The “Contract Approved — Ready to invoice” status creates the Accounting notification.",
          },
        ],
        note:
          "“Ready to invoice” is the required trigger. A plain “Approved” status does not hand the request to Accounting.",
        noteTone: "attention",
      },
    ],
  },
  {
    id: "invoice",
    label: "Phase D · Invoicing, payment & ongoing",
    shortLabel: "Invoicing & ongoing",
    ownerSummary: "Accounting + Procurement",
    steps: [
      {
        id: 10,
        title: "Apply fee & issue invoice",
        owner: "Accounting",
        ownerKey: "accounting",
        summary: "Accounting · Workday auto-send",
        description:
          "Accounting receives the Asana handoff, applies the vendor fee, and issues the invoice through Workday.",
        systems: ["Asana", "Workday"],
        details: [
          {
            label: "Fee",
            value:
              "15% for nonprofit vendors and 30% for for-profit vendors. The 501(c)(3) letter determines the rate.",
          },
          {
            label: "Communication",
            value:
              "The approved invoice is automatically sent to the vendor through Workday.",
          },
        ],
      },
      {
        id: 11,
        title: "Update status to “Approved Vendor”",
        owner: "Accounting",
        ownerKey: "accounting",
        summary: "Accounting · Net 30 from invoice date",
        description:
          "After the invoice is sent, Accounting moves the Asana task to Approved Vendor.",
        systems: ["Asana"],
        details: [
          {
            label: "Payment terms",
            value:
              "Net 30 from the invoice date. Exceptions require pre-authorization before the purchase agreement is finalized.",
          },
          {
            label: "Communication",
            value:
              "Terms are stated in the vendor application and contract; no separate terms email.",
          },
        ],
        note:
          "Any payment terms other than Net 30 require coordination between Accounting and Procurement.",
      },
      {
        id: 12,
        title: "Manage compliance, renewals & audits",
        owner: "Procurement / Accounting",
        ownerKey: "shared",
        summary: "Procurement tracks COIs · Accounting audits",
        description:
          "Procurement maintains COI renewals while Accounting performs roster and billing spot checks.",
        systems: ["Asana"],
        details: [
          {
            label: "COI renewals",
            value:
              "Procurement requests renewed certificates before expiration.",
          },
          {
            label: "Audit",
            value:
              "Accounting confirms that the approved roster matches what was invoiced.",
          },
          {
            label: "Routing",
            value:
              "Asana reminders prompt renewals; audit findings return to the DSO who approved the roster.",
          },
        ],
      },
    ],
  },
];

const isTeamRole = (role: DeskRole): role is RoleKey =>
  role === "Procurement" || role === "DSO" || role === "Accounting";

const formatDate = (value?: string) => {
  if (!value) return "Not set";
  const date = new Date(`${value.slice(0, 10)}T12:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(date);
};

const initials = (name: string) =>
  name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();

function Icon({
  name,
  size = 18,
}: {
  name:
    | "desk"
    | "pipeline"
    | "vendors"
    | "list"
    | "people"
    | "search"
    | "arrow"
    | "close"
    | "external"
    | "sync"
    | "check"
    | "alert"
    | "document"
    | "calendar"
    | "comment"
    | "plus"
    | "edit"
    | "upload"
    | "download";
  size?: number;
}) {
  const paths: Record<string, React.ReactNode> = {
    desk: <><path d="M4 5h16v11H4z" /><path d="M8 20h8M12 16v4" /></>,
    pipeline: <><path d="M4 5h4v14H4zM10 5h4v9h-4zM16 5h4v5h-4z" /></>,
    vendors: <><path d="M3 20h18M5 20V8l7-4 7 4v12M9 12h6M9 16h6" /></>,
    list: <><path d="M9 6h11M9 12h11M9 18h11" /><path d="M4 6h.01M4 12h.01M4 18h.01" /></>,
    people: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    arrow: <><path d="M5 12h14M13 6l6 6-6 6" /></>,
    close: <><path d="m6 6 12 12M18 6 6 18" /></>,
    external: <><path d="M15 3h6v6M10 14 21 3M18 13v7a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h7" /></>,
    sync: <><path d="M20 7h-5V2" /><path d="M20 7a9 9 0 1 0 1 8" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    alert: <><path d="M12 3 2.5 20h19L12 3Z" /><path d="M12 9v4M12 17h.01" /></>,
    document: <><path d="M6 2h9l4 4v16H6z" /><path d="M14 2v5h5M9 12h7M9 16h7" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
    comment: <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z" />,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    edit: <><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z" /></>,
    upload: <><path d="M12 16V4M7 9l5-5 5 5" /><path d="M5 20h14" /></>,
    download: <><path d="M12 4v12M7 11l5 5 5-5" /><path d="M5 20h14" /></>,
  };
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

function StagePill({ stage }: { stage: StageKey }) {
  return (
    <span className={`stage-pill stage-${stage}`}>
      <span className="stage-dot" />
      {stageDefinition(stage).shortLabel}
    </span>
  );
}

function RequestRow({
  request,
  onOpen,
}: {
  request: ClubRequest;
  onOpen: (request: ClubRequest) => void;
}) {
  return (
    <button className="request-row" onClick={() => onOpen(request)}>
      <div className="request-main">
        <div className="request-title-line">
          <span className="request-title">{request.vendor}</span>
          {!request.assignmentMatches && request.suggestedOwnerGid && (
            <span className="assignment-flag" title="Owner does not match the assignment map">
              <Icon name="alert" size={13} />
              Owner
            </span>
          )}
          {(request.missingDocuments.length > 0 || request.stage === "no_documents") && (
            <span className="document-flag" title="Asana lists documents as missing">
              <Icon name="document" size={13} />
              Docs
            </span>
          )}
        </div>
        <div className="request-meta">
          {request.club || "Club not named"} · {request.campus}, {request.state}
        </div>
      </div>
      <div className="request-stage">
        <StagePill stage={request.stage} />
      </div>
      <div className="request-documents request-documents-uploaded">
        <span>{request.uploadedDocuments.length}</span>
        <small>uploaded</small>
      </div>
      <div className={`request-documents ${request.missingDocuments.length ? "has-missing" : "is-complete"}`}>
        <span>{request.missingDocuments.length}</span>
        <small>missing</small>
      </div>
      <div className="request-date">
        <span>{formatDate(request.startDate)}</span>
        <small>club start</small>
      </div>
      <div className="request-owner">
        <span className="avatar">{initials(request.ownerName)}</span>
        <span>{request.ownerName}</span>
      </div>
      <span className="row-arrow"><Icon name="arrow" size={17} /></span>
    </button>
  );
}

function EmptyState({ children }: { children: React.ReactNode }) {
  return (
    <div className="empty-state">
      <span className="empty-check"><Icon name="check" size={19} /></span>
      <p>{children}</p>
    </div>
  );
}

export default function VendorClubManager({
  currentUserName,
  currentUserEmail,
  isSystemAdmin,
  isExecutive,
  canTakeAction,
  actionRole,
  allowedCampuses,
  asanaUserGids,
  accessLabel,
  initialDirectory,
}: {
  currentUserName: string;
  currentUserEmail: string;
  isSystemAdmin: boolean;
  isExecutive: boolean;
  canTakeAction: boolean;
  actionRole: RoleKey | null;
  allowedCampuses: string[];
  asanaUserGids: string[];
  accessLabel: string;
  initialDirectory: AssignmentDirectory;
}) {
  const [view, setView] = useState<ViewKey>("desk");
  const [role, setRole] = useState<DeskRole>(
    isSystemAdmin
      ? "All roles"
      : isExecutive
        ? "Executive"
        : actionRole ?? "All roles",
  );
  const [requests, setRequests] = useState<ClubRequest[]>(SEED_REQUESTS);
  const [configured, setConfigured] = useState(false);
  const [loading, setLoading] = useState(true);
  const [syncError, setSyncError] = useState("");
  const [syncedAt, setSyncedAt] = useState<string>();
  const [selected, setSelected] = useState<ClubRequest | null>(null);
  const [query, setQuery] = useState("");
  const [stateFilter, setStateFilter] = useState("All");
  const [toast, setToast] = useState("");
  const [intakeKind, setIntakeKind] = useState<NewRequestKind | null>(null);
  const [directory, setDirectory] =
    useState<AssignmentDirectory>(initialDirectory);

  const loadRequests = useCallback(async () => {
    setLoading(true);
    setSyncError("");
    try {
      const response = await fetch("/api/asana/requests", { cache: "no-store" });
      const payload = (await response.json()) as SyncResponse;
      if (!response.ok) throw new Error(payload.error || "Asana sync failed.");
      setConfigured(payload.configured);
      if (payload.configured && payload.requests?.length) {
        setRequests(payload.requests);
        setSyncedAt(payload.syncedAt);
        setSelected((current) =>
          current
            ? payload.requests?.find((item) => item.gid === current.gid) ?? null
            : null,
        );
      }
    } catch (error) {
      setSyncError(error instanceof Error ? error.message : "Asana sync failed.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => void loadRequests(), 0);
    return () => window.clearTimeout(timer);
  }, [loadRequests]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 3600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const userCanActOn = useCallback(
    (clubRequest: ClubRequest) => {
      if (isSystemAdmin || isExecutive) return true;
      if (!canTakeAction || !actionRole) return false;
      if (!ROLE_STAGE[actionRole].includes(clubRequest.stage)) return false;
      if (actionRole !== "DSO") return true;
      if (clubRequest.dsoGids?.length) {
        return asanaUserGids.some((gid) => clubRequest.dsoGids?.includes(gid));
      }
      return allowedCampuses.some(
        (campus) =>
          normalizeCampus(campus).toLowerCase() ===
          normalizeCampus(clubRequest.campus).toLowerCase(),
      );
    },
    [
      actionRole,
      allowedCampuses,
      asanaUserGids,
      canTakeAction,
      isExecutive,
      isSystemAdmin,
    ],
  );

  const deskRequests = useMemo(() => {
    const roleRequests =
      !isTeamRole(role)
        ? requests.filter((request) => request.stage !== "approved")
        : requests.filter((request) => ROLE_STAGE[role].includes(request.stage));
    if (
      !isSystemAdmin &&
      !isExecutive &&
      actionRole === "DSO" &&
      role === "DSO"
    ) {
      return roleRequests.filter(userCanActOn);
    }
    return roleRequests;
  }, [
    actionRole,
    isExecutive,
    isSystemAdmin,
    requests,
    role,
    userCanActOn,
  ]);
  const vendorWaitStages: StageKey[] = [
    "no_documents",
    "docs",
    "waiting_contract",
  ];
  const waiting = deskRequests.filter(
    (request) =>
      vendorWaitStages.includes(request.stage) &&
      (request.stage !== "docs" || request.missingDocuments.length > 0),
  );
  const waitingGids = new Set(waiting.map((request) => request.gid));
  const needsYou = deskRequests.filter(
    (request) =>
      !waitingGids.has(request.gid) ||
      !request.assignmentMatches,
  );
  const watching =
    !isTeamRole(role)
      ? []
      : requests.filter(
          (request) =>
            !ROLE_STAGE[role].includes(request.stage) &&
            request.stage !== "approved" &&
            request.stage !== "incomplete",
        );

  const pastStart = requests.filter((request) => {
    if (!request.startDate || request.stage === "approved") return false;
    return new Date(request.startDate) < new Date();
  }).length;

  const navigate = (target: ViewKey) => {
    setView(target);
    setSelected(null);
  };

  const signOut = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.assign("/");
  };

  const navItems: Array<{ key: ViewKey; label: string; icon: Parameters<typeof Icon>[0]["name"] }> = [
    { key: "desk", label: "My desk", icon: "desk" },
    { key: "pipeline", label: "Pipeline", icon: "pipeline" },
    { key: "workflow", label: "E2E Workflow", icon: "pipeline" },
    { key: "contracts", label: "Contracts", icon: "document" },
    { key: "vendors", label: "Vendors", icon: "vendors" },
    { key: "all", label: "All requests", icon: "list" },
    { key: "assignments", label: "Assignments", icon: "people" },
    ...(isSystemAdmin
      ? [{ key: "access" as const, label: "Access", icon: "people" as const }]
      : []),
    { key: "guide", label: "Guide", icon: "document" },
  ];
  const canSubmitRequest =
    isSystemAdmin || isExecutive || actionRole === "DSO";
  const submissionCampuses = isSystemAdmin || isExecutive
    ? directory.campusContacts.map((contact) => contact.campus)
    : allowedCampuses;

  return (
    <main className="app-shell">
      <header className="site-header">
        <button className="brand" onClick={() => navigate("desk")} aria-label="Vendor Clubs home">
          <span className="brand-mark">VC</span>
          <span>
            <strong>Vendor Clubs.</strong>
            <small>Approval manager</small>
          </span>
        </button>
        <nav className="main-nav" aria-label="Primary navigation">
          {navItems.map((item) => (
            <button
              key={item.key}
              className={view === item.key ? "active" : ""}
              onClick={() => navigate(item.key)}
            >
              <Icon name={item.icon} size={16} />
              {item.label}
            </button>
          ))}
        </nav>
        <div className="header-tools">
          <div
            className={`admin-identity ${
              isSystemAdmin
                ? "is-admin"
                : isExecutive
                  ? "is-executive"
                  : canTakeAction
                    ? "is-contact"
                    : "is-viewer"
            }`}
            title={accessLabel}
          >
            <span className="avatar">{initials(currentUserName)}</span>
            <span>
              <strong>{currentUserName}</strong>
              <small>{accessLabel}</small>
            </span>
          </div>
          <div className={`sync-status ${configured ? "live" : "preview"}`}>
            <span />
            {loading
              ? "Checking Asana"
              : configured
                ? `Synced ${syncedAt ? new Date(syncedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) : "now"}`
                : "Preview mode"}
          </div>
          <a
            className="asana-link"
            href={ASANA_PROJECT_URL}
            target="_blank"
            rel="noreferrer"
            title="Open the Asana project"
          >
            Asana <Icon name="external" size={14} />
          </a>
          <button
            className="signout-link"
            onClick={() => void signOut()}
          >
            Sign out
          </button>
        </div>
      </header>

      <div
        className={`admin-access-strip ${
          isSystemAdmin
            ? "access-admin"
            : isExecutive
              ? "access-executive"
            : canTakeAction
              ? "access-contact"
              : "access-viewer"
        }`}
      >
        {isSystemAdmin || canTakeAction ? (
          <Icon name="check" size={16} />
        ) : (
          <Icon name="people" size={16} />
        )}
        <strong>{accessLabel}</strong>
        <span>
          {isSystemAdmin
            ? "Full action access across every role and configured project."
            : isExecutive
              ? "Executive action access across every role and campus."
            : canTakeAction
              ? actionRole === "DSO"
                ? `Action access for ${allowedCampuses.join(", ")}; all other requests are view-only.`
                : `Action access during the ${actionRole} stage; all other requests are view-only.`
              : "You can view every request; actions are limited to designated contacts."}
        </span>
        <button className="access-strip-signout" onClick={() => void signOut()}>
          Sign out
        </button>
      </div>

      {!configured && !loading && (
        <div className="connection-banner">
          <div>
            <strong>The Asana connection is ready for its secure credential.</strong>
            <span>You’re viewing representative project data; write controls stay locked until connected.</span>
          </div>
          <span className="banner-badge">SAFE PREVIEW</span>
        </div>
      )}
      {syncError && (
        <div className="error-banner" role="alert">
          <Icon name="alert" size={17} />
          <span>{syncError}</span>
          <button onClick={() => void loadRequests()}>Try again</button>
        </div>
      )}

      {canSubmitRequest && (
        <section className="submission-bar" aria-label="Create a vendor club request">
          <div>
            <span className="submission-kicker">START A REQUEST</span>
            <strong>Bring a vendor or club into the approval process.</strong>
            <small>
              The campus assignment map routes a complete intake to Procurement.
            </small>
          </div>
          <div className="submission-actions">
            <button onClick={() => setIntakeKind("vendor")}>
              <Icon name="plus" size={16} />
              Add new vendor
            </button>
            <button onClick={() => setIntakeKind("club")}>
              <Icon name="plus" size={16} />
              Add new club
            </button>
          </div>
        </section>
      )}

      {isSystemAdmin && (
        <button
          type="button"
          className="admin-dashboard-shortcut"
          onClick={() => navigate("access")}
        >
          <span><Icon name="people" size={19} /></span>
          <strong>Access administration</strong>
          <small>Invite approved users, reset codes, and end access immediately.</small>
          <Icon name="arrow" size={18} />
        </button>
      )}

      <section className="page-frame">
        {view === "desk" && (
          <DeskView
            role={role}
            onRoleChange={setRole}
            isSystemAdmin={isSystemAdmin}
            canTakeAction={canTakeAction}
            actionRole={actionRole}
            requests={requests}
            needsYou={needsYou}
            waiting={waiting}
            watching={watching}
            pastStart={pastStart}
            onOpen={setSelected}
          />
        )}
        {view === "pipeline" && (
          <PipelineView requests={requests} onOpen={setSelected} />
        )}
        {view === "workflow" && <E2EWorkflowView />}
        {view === "contracts" && (
          <ContractBuilderView requests={requests} />
        )}
        {view === "vendors" && (
          <VendorView requests={requests} onOpen={setSelected} />
        )}
        {view === "all" && (
          <AllRequestsView
            requests={requests}
            query={query}
            setQuery={setQuery}
            stateFilter={stateFilter}
            setStateFilter={setStateFilter}
            onOpen={setSelected}
          />
        )}
        {view === "assignments" && (
          <AssignmentView
            requests={requests}
            directory={directory}
            configured={configured}
            isSystemAdmin={isSystemAdmin}
            onDirectoryChanged={setDirectory}
          />
        )}
        {view === "access" && isSystemAdmin && (
          <AccessAdminView currentUserEmail={currentUserEmail} />
        )}
        {view === "guide" && <ReferenceGuideView />}
      </section>

      {selected && (
        <RequestDrawer
          key={`${selected.gid}:${selected.stage}`}
          request={selected}
          relatedRequests={requests.filter(
            (request) =>
              request.vendor.trim().toLowerCase().replace(/\s+/g, " ") ===
                selected.vendor.trim().toLowerCase().replace(/\s+/g, " ") &&
              userCanActOn(request),
          )}
          configured={configured}
          isSystemAdmin={isSystemAdmin}
          isExecutive={isExecutive}
          actionRole={actionRole}
          canTakeAction={userCanActOn(selected)}
          accessLabel={accessLabel}
          onClose={() => setSelected(null)}
          onUpdated={async (message) => {
            setToast(message);
            await loadRequests();
          }}
        />
      )}

      {intakeKind && (
        <NewRequestModal
          kind={intakeKind}
          configured={configured}
          campuses={submissionCampuses}
          campusContacts={directory.campusContacts}
          requests={requests}
          onClose={() => setIntakeKind(null)}
          onCreated={async (message) => {
            setIntakeKind(null);
            setToast(message);
            await loadRequests();
          }}
        />
      )}

      {toast && (
        <div className="toast" role="status">
          <span><Icon name="check" size={16} /></span>
          {toast}
        </div>
      )}
    </main>
  );
}

function NewRequestModal({
  kind,
  configured,
  campuses,
  campusContacts,
  requests,
  onClose,
  onCreated,
}: {
  kind: NewRequestKind;
  configured: boolean;
  campuses: string[];
  campusContacts: CampusContact[];
  requests: ClubRequest[];
  onClose: () => void;
  onCreated: (message: string) => Promise<void>;
}) {
  const uniqueCampuses = Array.from(new Set(campuses)).sort();
  const defaultCampus = uniqueCampuses[0] ?? "";
  const defaultState =
    campusContacts.find((contact) => contact.campus === defaultCampus)?.state ??
    "";
  const [form, setForm] = useState<NewClubRequestInput>({
    kind,
    vendorName: "",
    legalName: "",
    contactName: "",
    phone: "",
    email: "",
    nonprofit: "",
    fein: "",
    physicalAddress: "",
    mailingAddress: "",
    vendorDocuments: "",
    club: "",
    campus: defaultCampus,
    state: defaultState,
    startDate: "",
    endDate: "",
    daysOffered: [],
    clubSession: "",
    instructorNames: "",
    tuition: "",
    notes: "",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const vendorOptions = Array.from(
    requests.reduce((map, request) => {
      if (request.vendor && !map.has(request.vendor)) {
        map.set(request.vendor, request);
      }
      return map;
    }, new Map<string, ClubRequest>()),
  ).sort(([left], [right]) => left.localeCompare(right));

  function update<Key extends keyof NewClubRequestInput>(
    key: Key,
    value: NewClubRequestInput[Key],
  ) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  const chooseVendor = (vendorName: string) => {
    const source = vendorOptions.find(([name]) => name === vendorName)?.[1];
    setForm((current) => ({
      ...current,
      vendorName,
      legalName: source?.legalName ?? "",
      contactName: source?.contactName ?? "",
      phone: source?.phone ?? "",
      email: source?.email ?? "",
      nonprofit:
        source?.nonprofit === "Yes" || source?.nonprofit === "No"
          ? source.nonprofit
          : "",
    }));
  };

  const chooseCampus = (campus: string) => {
    const state =
      campusContacts.find((contact) => contact.campus === campus)?.state ?? "";
    setForm((current) => ({ ...current, campus, state }));
  };

  const toggleDay = (day: string) => {
    setForm((current) => ({
      ...current,
      daysOffered: current.daysOffered.includes(day)
        ? current.daysOffered.filter((item) => item !== day)
        : [...current.daysOffered, day],
    }));
  };

  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!configured || busy) return;
    if (!form.daysOffered.length) {
      setError("Select at least one day offered.");
      return;
    }
    if (form.startDate && form.endDate && form.endDate < form.startDate) {
      setError("The end date must be on or after the start date.");
      return;
    }

    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/asana/actions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "createRequest", requestData: form }),
      });
      const payload = (await response.json()) as { error?: string };
      if (!response.ok) {
        throw new Error(payload.error || "The request could not be submitted.");
      }
      await onCreated(
        `${kind === "vendor" ? "New vendor" : "New club"} request sent to Procurement in Asana.`,
      );
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : "The request could not be submitted.",
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="modal-layer"
      role="dialog"
      aria-modal="true"
      aria-labelledby="new-request-title"
    >
      <button className="modal-scrim" onClick={onClose} aria-label="Close form" />
      <form className="intake-modal" onSubmit={submit}>
        <header className="intake-header">
          <div>
            <p className="eyebrow">DSO REQUEST INTAKE</p>
            <h2 id="new-request-title">
              {kind === "vendor" ? "Add a new vendor" : "Add a new club"}
            </h2>
            <p>
              Complete the required details once. The request will open in the
              New Request stage with Procurement assigned.
            </p>
          </div>
          <button
            type="button"
            className="icon-button"
            onClick={onClose}
            aria-label="Close"
          >
            <Icon name="close" />
          </button>
        </header>

        <div className="intake-body">
          <section className="intake-section">
            <div className="intake-section-title">
              <span>01</span>
              <div>
                <h3>Vendor information</h3>
                <p>
                  {kind === "vendor"
                    ? "Tell Procurement who the new organization is."
                    : "Choose an existing vendor, then confirm the details."}
                </p>
              </div>
            </div>
            <div className="form-grid">
              <label className="form-field form-field-wide">
                <span>Vendor / organization name *</span>
                {kind === "club" ? (
                  <select
                    required
                    value={form.vendorName}
                    onChange={(event) => chooseVendor(event.target.value)}
                  >
                    <option value="">Choose an existing vendor</option>
                    {vendorOptions.map(([vendor]) => (
                      <option value={vendor} key={vendor}>
                        {vendor}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    required
                    value={form.vendorName}
                    onChange={(event) =>
                      update("vendorName", event.target.value)
                    }
                    placeholder="Organization name"
                  />
                )}
              </label>
              <label className="form-field">
                <span>Legal business name *</span>
                <input
                  required
                  value={form.legalName}
                  onChange={(event) => update("legalName", event.target.value)}
                />
              </label>
              <label className="form-field">
                <span>Nonprofit status *</span>
                <select
                  required
                  value={form.nonprofit}
                  onChange={(event) =>
                    update(
                      "nonprofit",
                      event.target.value as NewClubRequestInput["nonprofit"],
                    )
                  }
                >
                  <option value="">Choose</option>
                  <option value="Yes">Yes</option>
                  <option value="No">No</option>
                </select>
              </label>
              <label className="form-field">
                <span>Vendor contact name *</span>
                <input
                  required
                  value={form.contactName}
                  onChange={(event) => update("contactName", event.target.value)}
                />
              </label>
              <label className="form-field">
                <span>Vendor email *</span>
                <input
                  required
                  type="email"
                  value={form.email}
                  onChange={(event) => update("email", event.target.value)}
                />
              </label>
              <label className="form-field">
                <span>Vendor phone *</span>
                <input
                  required
                  type="tel"
                  value={form.phone}
                  onChange={(event) => update("phone", event.target.value)}
                />
              </label>
              <label className="form-field">
                <span>FEIN {kind === "vendor" ? "*" : ""}</span>
                <input
                  required={kind === "vendor"}
                  value={form.fein}
                  onChange={(event) => update("fein", event.target.value)}
                  placeholder={kind === "club" ? "Optional if already on file" : ""}
                />
              </label>
              <label className="form-field form-field-wide">
                <span>Physical address {kind === "vendor" ? "*" : ""}</span>
                <input
                  required={kind === "vendor"}
                  value={form.physicalAddress}
                  onChange={(event) =>
                    update("physicalAddress", event.target.value)
                  }
                />
              </label>
              <label className="form-field form-field-wide">
                <span>Mailing address {kind === "vendor" ? "*" : ""}</span>
                <input
                  required={kind === "vendor"}
                  value={form.mailingAddress}
                  onChange={(event) =>
                    update("mailingAddress", event.target.value)
                  }
                  placeholder="Enter “Same as physical” when applicable"
                />
              </label>
              <label className="form-field form-field-wide">
                <span>
                  Vendor document package {kind === "vendor" ? "*" : ""}
                </span>
                <textarea
                  required={kind === "vendor"}
                  rows={3}
                  value={form.vendorDocuments}
                  onChange={(event) =>
                    update("vendorDocuments", event.target.value)
                  }
                  placeholder="Paste the shared folder link and note what is included"
                />
                <small>
                  Use a workspace-accessible link; do not paste passwords or
                  credentials.
                </small>
              </label>
            </div>
          </section>

          <section className="intake-section">
            <div className="intake-section-title">
              <span>02</span>
              <div>
                <h3>Club plan</h3>
                <p>
                  Define the campus, session, schedule, and program details.
                </p>
              </div>
            </div>
            <div className="form-grid">
              <label className="form-field form-field-wide">
                <span>Club / program name *</span>
                <input
                  required
                  value={form.club}
                  onChange={(event) => update("club", event.target.value)}
                />
              </label>
              <label className="form-field">
                <span>Campus *</span>
                <select
                  required
                  value={form.campus}
                  onChange={(event) => chooseCampus(event.target.value)}
                >
                  {uniqueCampuses.map((campus) => (
                    <option value={campus} key={campus}>
                      {campus}
                    </option>
                  ))}
                </select>
              </label>
              <label className="form-field">
                <span>State</span>
                <input value={form.state} readOnly aria-readonly="true" />
              </label>
              <label className="form-field">
                <span>Start date *</span>
                <input
                  required
                  type="date"
                  value={form.startDate}
                  onChange={(event) => update("startDate", event.target.value)}
                />
              </label>
              <label className="form-field">
                <span>End date *</span>
                <input
                  required
                  type="date"
                  min={form.startDate || undefined}
                  value={form.endDate}
                  onChange={(event) => update("endDate", event.target.value)}
                />
              </label>
              <label className="form-field">
                <span>Club session *</span>
                <select
                  required
                  value={form.clubSession}
                  onChange={(event) =>
                    update("clubSession", event.target.value)
                  }
                >
                  <option value="">Choose a quarter or semester</option>
                  {Object.keys(SESSION_OPTION_GIDS).map((session) => (
                    <option value={session} key={session}>
                      {session}
                    </option>
                  ))}
                </select>
              </label>
              <label className="form-field">
                <span>Per-student tuition *</span>
                <input
                  required
                  value={form.tuition}
                  onChange={(event) => update("tuition", event.target.value)}
                  placeholder="Example: $125 or No cost"
                />
              </label>
              <fieldset className="form-field form-field-wide day-field">
                <legend>Days offered *</legend>
                <div className="day-options">
                  {Object.keys(DAY_OPTION_GIDS).map((day) => (
                    <label key={day}>
                      <input
                        type="checkbox"
                        checked={form.daysOffered.includes(day)}
                        onChange={() => toggleDay(day)}
                      />
                      <span>{day.slice(0, 3)}</span>
                    </label>
                  ))}
                </div>
              </fieldset>
              <label className="form-field form-field-wide">
                <span>Instructor name(s) *</span>
                <input
                  required
                  value={form.instructorNames}
                  onChange={(event) =>
                    update("instructorNames", event.target.value)
                  }
                  placeholder="List every anticipated instructor"
                />
              </label>
            </div>
          </section>

          <section className="intake-section">
            <div className="intake-section-title">
              <span>03</span>
              <div>
                <h3>Final context</h3>
                <p>
                  Add anything Procurement should know before contacting the
                  vendor.
                </p>
              </div>
            </div>
            <label className="form-field">
              <span>Additional notes</span>
              <textarea
                rows={4}
                value={form.notes}
                onChange={(event) => update("notes", event.target.value)}
                placeholder="Schedule constraints, special campus context, or follow-up needed…"
              />
            </label>
          </section>

          {error && (
            <div className="intake-error" role="alert">
              <Icon name="alert" size={16} />
              {error}
            </div>
          )}
          {!configured && (
            <div className="intake-connection-note">
              <Icon name="alert" size={16} />
              Submission unlocks when the secure Asana connection is added.
            </div>
          )}
        </div>

        <footer className="intake-footer">
          <button type="button" className="secondary-button" onClick={onClose}>
            Cancel
          </button>
          <button
            type="submit"
            className="submit-request-button"
            disabled={!configured || busy}
          >
            <span>{busy ? "Creating in Asana…" : "Submit to Procurement"}</span>
            <Icon name="arrow" size={17} />
          </button>
        </footer>
      </form>
    </div>
  );
}

function PageIntro({
  eyebrow,
  title,
  copy,
  action,
}: {
  eyebrow: string;
  title: string;
  copy: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="page-intro">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h1>{title}</h1>
        <p className="intro-copy">{copy}</p>
      </div>
      {action}
    </div>
  );
}

function WorkflowSystemChip({ system }: { system: WorkflowSystem }) {
  return (
    <span className={`workflow-system system-${system.toLowerCase()}`}>
      {system}
    </span>
  );
}

function E2EWorkflowView() {
  const allStepIds = WORKFLOW_PHASES.flatMap((phase) =>
    phase.steps.map((step) => step.id),
  );
  const [openSteps, setOpenSteps] = useState<Set<number>>(
    () => new Set([4, 9]),
  );

  const toggleStep = (stepId: number) => {
    setOpenSteps((current) => {
      const next = new Set(current);
      if (next.has(stepId)) next.delete(stepId);
      else next.add(stepId);
      return next;
    });
  };

  return (
    <>
      <PageIntro
        eyebrow="END-TO-END PROCESS"
        title="E2E Workflow"
        copy="Follow the full vendor club process from the DSO’s first vendor email through document review, roster clearance, invoicing, and ongoing compliance."
        action={
          <div className="workflow-controls" aria-label="Workflow detail controls">
            <button
              type="button"
              onClick={() => setOpenSteps(new Set(allStepIds))}
            >
              Expand all
            </button>
            <button
              type="button"
              className="subtle"
              onClick={() => setOpenSteps(new Set())}
            >
              Collapse all
            </button>
          </div>
        }
      />

      <section className="workflow-overview">
        <div className="workflow-phase-track" aria-label="Workflow phases">
          {WORKFLOW_PHASES.map((phase, index) => (
            <div className="workflow-phase-card" key={phase.id}>
              <span>{String(index + 1).padStart(2, "0")}</span>
              <strong>{phase.shortLabel}</strong>
              <small>{phase.ownerSummary}</small>
            </div>
          ))}
        </div>
        <div className="workflow-key-trigger">
          <Icon name="pipeline" size={19} />
          <div>
            <strong>Asana approval status chain</strong>
            <p>
              {STAGES.filter((stage) => stage.key !== "incomplete")
                .map((stage) => stage.label)
                .join(" → ")}
            </p>
          </div>
        </div>
        <div className="workflow-key-trigger">
          <Icon name="alert" size={19} />
          <div>
            <strong>The Accounting handoff is status-driven.</strong>
            <p>
              Accounting is notified only when the DSO sets the Asana status to
              “Contract Approved — Ready to invoice.”
            </p>
          </div>
        </div>
        <div className="workflow-legend">
          <div className="workflow-owner-legend" aria-label="Workflow owners">
            <span><i className="legend-dso" />DSO</span>
            <span><i className="legend-vendor" />Vendor</span>
            <span><i className="legend-procurement" />Procurement</span>
            <span><i className="legend-accounting" />Accounting</span>
          </div>
          <div className="workflow-system-legend" aria-label="Workflow systems">
            <WorkflowSystemChip system="Asana" />
            <WorkflowSystemChip system="Email" />
            <WorkflowSystemChip system="Workday" />
          </div>
        </div>
      </section>

      <div className="e2e-workflow-map">
        {WORKFLOW_PHASES.map((phase) => (
          <section className="e2e-phase" key={phase.id}>
            <header className="e2e-phase-heading">
              <span>{phase.label}</span>
              <i />
              <small>{phase.ownerSummary}</small>
            </header>
            <div className="e2e-phase-steps">
              {phase.steps.map((step, index) => {
                const isOpen = openSteps.has(step.id);
                return (
                  <div className="e2e-step-wrap" key={step.id}>
                    {step.gate && (
                      <div className="e2e-gate-label">
                        <Icon name="alert" size={13} />
                        {step.gate}
                      </div>
                    )}
                    <article
                      className={`e2e-step owner-${step.ownerKey} ${
                        step.gate ? "is-gate" : ""
                      } ${isOpen ? "is-open" : ""}`}
                    >
                      <button
                        type="button"
                        className="e2e-step-summary"
                        aria-expanded={isOpen}
                        aria-controls={`workflow-step-${step.id}`}
                        onClick={() => toggleStep(step.id)}
                      >
                        <span className="e2e-step-number">{step.id}</span>
                        <span className="e2e-step-main">
                          <span className="e2e-step-topline">
                            <span className="e2e-owner">{step.owner}</span>
                            <span className="e2e-system-row">
                              {step.systems.map((system) => (
                                <WorkflowSystemChip
                                  key={system}
                                  system={system}
                                />
                              ))}
                            </span>
                          </span>
                          <strong>{step.title}</strong>
                          <small>{step.summary}</small>
                          <p>{step.description}</p>
                        </span>
                        <span className="e2e-step-toggle" aria-hidden="true">
                          {isOpen ? "−" : "+"}
                        </span>
                      </button>
                      {isOpen && (
                        <div
                          className="e2e-step-detail"
                          id={`workflow-step-${step.id}`}
                        >
                          {step.details.map((detail) => (
                            <div className="e2e-detail-row" key={detail.label}>
                              <strong>{detail.label}</strong>
                              <p>{detail.value}</p>
                            </div>
                          ))}
                          {step.branches && (
                            <div className="e2e-branches">
                              {step.branches.map((branch) => (
                                <div key={branch.label}>
                                  <span>{branch.label}</span>
                                  <p>{branch.value}</p>
                                </div>
                              ))}
                            </div>
                          )}
                          {step.note && (
                            <div
                              className={`e2e-note ${
                                step.noteTone === "attention"
                                  ? "attention"
                                  : ""
                              }`}
                            >
                              <Icon
                                name={
                                  step.noteTone === "attention"
                                    ? "alert"
                                    : "check"
                                }
                                size={15}
                              />
                              <p>{step.note}</p>
                            </div>
                          )}
                        </div>
                      )}
                    </article>
                    {index < phase.steps.length - 1 && (
                      <div className="e2e-connector" aria-hidden="true">
                        <span />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        ))}
      </div>
    </>
  );
}

const blankContractFields = (): AzContractFields => ({
  effectiveDate: "",
  campus: "",
  vendorName: "",
  ein: "",
  entityType: "",
  facilityLine1: "",
  facilityLine2: "",
  premises: "",
  daysHours: "",
  signerName: "",
  signatureDate: "",
});

function ContractBuilderView({ requests }: { requests: ClubRequest[] }) {
  const [requestGid, setRequestGid] = useState("");
  const [fields, setFields] = useState<AzContractFields>(blankContractFields);
  const [recipientEmail, setRecipientEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [downloadedFile, setDownloadedFile] = useState("");

  const sortedRequests = useMemo(
    () =>
      [...requests].sort((a, b) =>
        `${a.vendor} ${a.campus}`.localeCompare(`${b.vendor} ${b.campus}`),
      ),
    [requests],
  );

  function updateField<K extends keyof AzContractFields>(
    key: K,
    value: AzContractFields[K],
  ) {
    setFields((current) => ({ ...current, [key]: value }));
    setDownloadedFile("");
  }

  const selectRequest = (gid: string) => {
    setRequestGid(gid);
    setError("");
    setDownloadedFile("");
    if (!gid) {
      setFields(blankContractFields());
      setRecipientEmail("");
      return;
    }

    const request = requests.find((item) => item.gid === gid);
    if (!request) return;
    setFields({
      effectiveDate: "",
      campus: request.campus,
      vendorName: request.legalName || request.vendor,
      ein: request.fein ?? "",
      entityType:
        request.nonprofit === "Yes"
          ? "Non-Profit"
          : request.nonprofit === "No"
            ? "For-Profit"
            : "",
      facilityLine1: request.club,
      facilityLine2: "",
      premises: `Legacy Traditional School - ${request.campus}`,
      daysHours: request.daysOffered ?? "",
      signerName: request.contactName ?? "",
      signatureDate: "",
    });
    setRecipientEmail(request.email ?? "");
  };

  const downloadContract = async (event: React.FormEvent) => {
    event.preventDefault();
    setError("");
    setDownloadedFile("");

    setBusy(true);
    try {
      const blob = await generateAzVendorContract(fields);
      const filename = contractFileName(fields);
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
      setDownloadedFile(filename);
    } catch (contractError) {
      setError(
        contractError instanceof Error
          ? contractError.message
          : "The contract could not be generated.",
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageIntro
        eyebrow="AZ · 2026–2027"
        title="Contract builder"
        copy="Prefill what is already known, leave vendor-supplied details blank, and download an email-ready Arizona agreement."
      />

      <div className="contract-layout">
        <aside className="contract-template-card">
          <div className="contract-template-mark">
            <Icon name="document" size={25} />
          </div>
          <p className="eyebrow">LOCKED LEGAL TEMPLATE</p>
          <h2>Arizona vendor contract</h2>
          <p>
            Uses the approved 2026–2027 Legacy Traditional Schools agreement.
            The legal terms and signature line stay unchanged.
          </p>
          <div className="contract-template-meta">
            <span><strong>9</strong> pages</span>
            <span><strong>May 22, 2027</strong> term end</span>
          </div>
          <ol className="contract-steps">
            <li><span>1</span><div><strong>Choose a request</strong><small>Known Asana fields fill automatically.</small></div></li>
            <li><span>2</span><div><strong>Fill what you know</strong><small>Every field is optional in the builder.</small></div></li>
            <li><span>3</span><div><strong>Download and email</strong><small>The vendor can complete the remaining lines.</small></div></li>
          </ol>
          <div className="contract-privacy-note">
            <Icon name="check" size={15} />
            <span>The contract is created in your browser and is not stored by this app.</span>
          </div>
        </aside>

        <form className="contract-form" onSubmit={downloadContract}>
          <section className="contract-form-section contract-request-picker">
            <div className="contract-section-heading">
              <div><span>01</span><h2>Start with a request</h2></div>
              <small>Optional, but fastest</small>
            </div>
            <label>
              <span>Vendor-club request</span>
              <select value={requestGid} onChange={(event) => selectRequest(event.target.value)}>
                <option value="">Start a blank Arizona contract</option>
                {sortedRequests.map((request) => (
                  <option value={request.gid} key={request.gid}>
                    {request.vendor} · {request.club || "Club not named"} · {request.campus}
                  </option>
                ))}
              </select>
              <small>Choosing a request fills vendor, campus, program, tax status, and contact details when available.</small>
            </label>
          </section>

          <div className="contract-optional-note" role="note">
            <Icon name="check" size={17} />
            <div>
              <strong>No fields are required</strong>
              <span>Complete only the information you have. Blank items remain as fill-in lines for the vendor in the Word contract.</span>
            </div>
          </div>

          <section className="contract-form-section">
            <div className="contract-section-heading">
              <div><span>02</span><h2>Agreement details</h2></div>
              <small>Fill what you know</small>
            </div>
            <div className="contract-field-grid">
              <label>
                <span>Effective date</span>
                <input type="date" value={fields.effectiveDate} onChange={(event) => updateField("effectiveDate", event.target.value)} />
              </label>
              <label>
                <span>LTS campus</span>
                <input value={fields.campus} onChange={(event) => updateField("campus", event.target.value)} placeholder="Chandler" />
              </label>
              <label className="contract-field-wide">
                <span>Vendor legal name</span>
                <input value={fields.vendorName} onChange={(event) => updateField("vendorName", event.target.value)} placeholder="Legal name shown on the W-9" />
              </label>
              <label>
                <span>EIN</span>
                <input value={fields.ein} onChange={(event) => updateField("ein", event.target.value)} placeholder="XX-XXXXXXX" />
              </label>
              <label>
                <span>Entity type</span>
                <select value={fields.entityType} onChange={(event) => updateField("entityType", event.target.value as AzContractFields["entityType"])}>
                  <option value="">Choose one</option>
                  <option value="For-Profit">For-Profit</option>
                  <option value="Non-Profit">Non-Profit</option>
                </select>
              </label>
            </div>
          </section>

          <section className="contract-form-section">
            <div className="contract-section-heading">
              <div><span>03</span><h2>Facilities and schedule</h2></div>
              <small>Fill what you know</small>
            </div>
            <div className="contract-field-grid">
              <label className="contract-field-wide">
                <span>Facility or program</span>
                <input value={fields.facilityLine1} onChange={(event) => updateField("facilityLine1", event.target.value)} placeholder="Robotics enrichment class in Room 204" />
                <small>Describe the approved room, area, or program use.</small>
              </label>
              <label className="contract-field-wide">
                <span>Additional facility detail</span>
                <input value={fields.facilityLine2} onChange={(event) => updateField("facilityLine2", event.target.value)} placeholder="Optional second line" />
              </label>
              <label className="contract-field-wide">
                <span>Premises</span>
                <input value={fields.premises} onChange={(event) => updateField("premises", event.target.value)} placeholder="Legacy Traditional School - Chandler" />
              </label>
              <label className="contract-field-wide">
                <span>Days and hours</span>
                <input value={fields.daysHours} onChange={(event) => updateField("daysHours", event.target.value)} placeholder="Tuesdays, 3:30–4:30 PM" />
              </label>
            </div>
          </section>

          <section className="contract-form-section">
            <div className="contract-section-heading">
              <div><span>04</span><h2>Signature and email prep</h2></div>
              <small>Optional prefills</small>
            </div>
            <div className="contract-field-grid">
              <label>
                <span>Printed signer name</span>
                <input value={fields.signerName} onChange={(event) => updateField("signerName", event.target.value)} placeholder="Vendor representative" />
              </label>
              <label>
                <span>Signature date</span>
                <input type="date" value={fields.signatureDate} onChange={(event) => updateField("signatureDate", event.target.value)} />
                <small>Leave blank when the vendor should date it.</small>
              </label>
              <label className="contract-field-wide">
                <span>Vendor email</span>
                <input type="email" value={recipientEmail} onChange={(event) => setRecipientEmail(event.target.value)} placeholder="vendor@example.com" />
                <small>Used only to address the email draft after download.</small>
              </label>
            </div>
          </section>

          {error && <div className="contract-error" role="alert"><Icon name="alert" size={16} /> {error}</div>}

          <footer className="contract-actions">
            <button type="button" className="contract-reset" onClick={() => selectRequest("")} disabled={busy}>Clear form</button>
            <button type="submit" className="contract-download" disabled={busy}>
              <Icon name="document" size={17} />
              {busy ? "Generating Word document…" : "Generate Word contract"}
            </button>
          </footer>

          {downloadedFile && (
            <div className="contract-next-step" role="status">
              <div>
                <span><Icon name="check" size={16} /></span>
                <div><strong>Contract downloaded</strong><small>{downloadedFile}</small></div>
              </div>
              {recipientEmail ? (
                <a href={emailDraftLink(fields, recipientEmail, downloadedFile)}>
                  Open email draft <Icon name="arrow" size={15} />
                </a>
              ) : (
                <small>Add the vendor email above to open a prepared email draft.</small>
              )}
              <p>Attach the downloaded Word file to the email before sending.</p>
            </div>
          )}
        </form>
      </div>
    </>
  );
}

function ReferenceGuideView() {
  const workflow = [
    ["1", "New request", "Procurement", "Confirm the intake is complete and begin vendor review."],
    ["2", "Documents", "Procurement", "Collect and review required vendor documents."],
    ["3", "Contract", "Procurement", "Complete contract review and approval."],
    ["4", "Campus review", "DSO", "Review the roster and fingerprint clearance cards."],
    ["5", "Invoice", "Accounting", "Create the initial invoice after the campus handoff."],
    ["6", "Approved", "Complete", "The club is ready for the approved operating period."],
  ];
  const roles = [
    ["Workspace viewer", "View all requests, vendors, pipeline stages, assignments, and this guide."],
    ["DSO", "Submit vendor or club requests and action campus-review work assigned to their campus."],
    ["Procurement", "Action intake, document, contract, and incomplete-submission stages."],
    ["Accounting", "Action invoice-stage work."],
    ["Executive", "View and action every request across all teams and campuses."],
    ["System Administrator", "All Executive capabilities plus exclusive maintenance of the assignment directory."],
  ];
  const roleGuides = [
    {
      role: "Workspace Viewer",
      focus: "Read-only monitoring, routing questions, and access boundaries.",
      file: "/guides/workspace-viewer-user-guide.docx",
    },
    {
      role: "DSO",
      focus: "Campus intake, vendor outreach, roster review, and FPCC validation.",
      file: "/guides/dso-user-guide.docx",
    },
    {
      role: "Procurement",
      focus: "Documents, Workday vendor setup, contracts, campus handoff, and COI renewal.",
      file: "/guides/procurement-user-guide.docx",
    },
    {
      role: "Accounting",
      focus: "Fee determination, Workday invoicing, final status, and billing controls.",
      file: "/guides/accounting-user-guide.docx",
    },
    {
      role: "Executive",
      focus: "Cross-role oversight, exception management, and controlled intervention.",
      file: "/guides/executive-user-guide.docx",
    },
    {
      role: "System Administrator",
      focus: "Access governance, assignment-directory stewardship, and release controls.",
      file: "/guides/system-administrator-user-guide.docx",
    },
  ];

  return (
    <>
      <PageIntro
        eyebrow="SITE REFERENCE"
        title="How to use this site"
        copy="A quick guide to the vendor club workflow, role permissions, Asana updates, and document handling."
      />
      <div className="guide-layout">
        <section className="guide-library guide-wide">
          <div className="guide-library-heading">
            <div>
              <p className="eyebrow">DOWNLOADABLE PLAYBOOKS</p>
              <h2>Role guides & master SOP</h2>
            </div>
            <p>Download the Word guide for your role or use the master SOP for the full controlled process, ownership model, handoffs, and exception paths.</p>
          </div>
          <a
            className="guide-master-card"
            href="/guides/vendor-club-approval-master-sop.docx"
            download
          >
            <span className="guide-file-icon"><Icon name="document" size={22} /></span>
            <span className="guide-master-copy">
              <small>MASTER SOP · VERSION 1.0</small>
              <strong>Vendor Club Approval Manager — Master Standard Operating Procedure</strong>
              <span>End-to-end intake, document, contract, roster, invoice, records, access, and governance requirements.</span>
            </span>
            <span className="guide-download-action">Download Word <Icon name="download" size={17} /></span>
          </a>
          <div className="role-guide-grid">
            {roleGuides.map((guide) => (
              <a href={guide.file} download key={guide.role}>
                <span className="role-guide-label">ROLE GUIDE</span>
                <strong>{guide.role}</strong>
                <p>{guide.focus}</p>
                <span className="role-guide-download">Download Word <Icon name="download" size={15} /></span>
              </a>
            ))}
          </div>
        </section>

        <section className="guide-section guide-start">
          <p className="eyebrow">START HERE</p>
          <h2>Working a request</h2>
          <ol className="guide-steps">
            <li><span>1</span><div><strong>Find the request</strong><p>Use My desk for role-specific work, Pipeline for the full process, or All requests to search and filter.</p></div></li>
            <li><span>2</span><div><strong>Open the request drawer</strong><p>Select any request to review its current owner, handoff, dates, vendor fields, attachments, and document checklist.</p></div></li>
            <li><span>3</span><div><strong>Complete your action</strong><p>Authorized contacts can edit fields, upload documents, correct the owner, mark checklist items received, comment, or advance the request.</p></div></li>
            <li><span>4</span><div><strong>Confirm the handoff</strong><p>Every saved action writes to the matching Asana task. Refresh if you need to confirm a change made directly in Asana.</p></div></li>
          </ol>
        </section>

        <section className="guide-section">
          <p className="eyebrow">PROCESS MAP</p>
          <h2>Vendor club handoffs</h2>
          <div className="guide-workflow">
            {workflow.map(([step, stage, owner, copy]) => (
              <div key={stage}>
                <span>{step}</span>
                <div><strong>{stage}</strong><small>{owner}</small><p>{copy}</p></div>
              </div>
            ))}
          </div>
        </section>

        <section className="guide-section guide-docs">
          <p className="eyebrow">DOCUMENTS</p>
          <h2>Attachments and the checklist</h2>
          <div className="guide-callout">
            <Icon name="alert" size={19} />
            <div><strong>“Documents Uploaded” and “Documents Missing” mirror Asana.</strong><p>Use the document status panel to see both fields. Selecting a document type during upload updates the uploaded field and clears its matching missing item.</p></div>
          </div>
          <div className="guide-two-column">
            <div><h3>Attachments</h3><p>The actual files on the Asana task. Authorized contacts can upload PDF, Word, Excel, CSV, and image files, up to 90 MB each.</p></div>
            <div><h3>Document checklist</h3><p>The Asana “Missing Documents” field. Mark an item received only after the corresponding document has been reviewed.</p></div>
          </div>
        </section>

        <section className="guide-section">
          <p className="eyebrow">ACCESS</p>
          <h2>Who can take action</h2>
          <div className="guide-role-list">
            {roles.map(([role, access]) => (
              <div key={role}><strong>{role}</strong><p>{access}</p></div>
            ))}
          </div>
        </section>

        <section className="guide-section guide-wide">
          <p className="eyebrow">COMMON TASKS</p>
          <h2>Quick reference</h2>
          <div className="guide-quick-grid">
            <article><Icon name="edit" /><h3>Edit request fields</h3><p>Open a request, choose Edit fields, make the changes, and select Save to Asana.</p></article>
            <article><Icon name="upload" /><h3>Upload documents</h3><p>Choose one or more files, then decide whether to add them only to this task or to selected tasks for the same vendor.</p></article>
            <article><Icon name="plus" /><h3>Add a vendor or club</h3><p>DSOs, Executives, and the System Administrator can start intake from the buttons in the site header.</p></article>
            <article><Icon name="sync" /><h3>Refresh Asana data</h3><p>Use Refresh in the header after changes are made outside this site.</p></article>
            <article><Icon name="people" /><h3>Correct an owner</h3><p>Open a flagged request and choose Apply owner to use the assignment directory.</p></article>
            <article><Icon name="comment" /><h3>Leave a handoff note</h3><p>Post a comment from the request drawer. It appears on the Asana task for project members.</p></article>
          </div>
        </section>
      </div>
    </>
  );
}

function DeskView({
  role,
  onRoleChange,
  isSystemAdmin,
  canTakeAction,
  actionRole,
  requests,
  needsYou,
  waiting,
  watching,
  pastStart,
  onOpen,
}: {
  role: DeskRole;
  onRoleChange: (role: DeskRole) => void;
  isSystemAdmin: boolean;
  canTakeAction: boolean;
  actionRole: RoleKey | null;
  requests: ClubRequest[];
  needsYou: ClubRequest[];
  waiting: ClubRequest[];
  watching: ClubRequest[];
  pastStart: number;
  onOpen: (request: ClubRequest) => void;
}) {
  const executiveTeams: Array<{
    role: RoleKey;
    title: string;
    note: string;
  }> = [
    {
      role: "Procurement",
      title: "Procurement",
      note: "Intake, documents, contracts, and incomplete submissions",
    },
    {
      role: "DSO",
      title: "Campus review · DSO",
      note: "Rosters and fingerprint clearance reviews",
    },
    {
      role: "Accounting",
      title: "Accounting",
      note: "Invoice creation and final financial handoff",
    },
  ];
  const executiveOpenCount = requests.filter(
    (request) => request.stage !== "approved",
  ).length;

  return (
    <>
      <PageIntro
        eyebrow="THE WORK IN FRONT OF YOU"
        title={
          isSystemAdmin && role === "All roles"
            ? "Admin desk"
            : role === "Executive"
              ? "Executive desk"
            : !canTakeAction && role === "All roles"
              ? "Workspace overview"
              : actionRole === role
                ? "My desk"
                : `${role} queue`
        }
        copy={
          isSystemAdmin && role === "All roles"
            ? "Every active handoff across Procurement, campus review, and Accounting in one administrator queue."
            : role === "Executive"
              ? "Every active handoff, organized by the team currently responsible for moving it forward."
            : !canTakeAction && role === "All roles"
              ? "A read-only view of every active handoff across Procurement, campus review, and Accounting."
              : actionRole === role
                ? "The handoffs assigned to your role and campus responsibility."
                : "Explore the work moving through this team’s stage."
        }
        action={
          <label className="role-picker">
            <span>Viewing as</span>
            <select value={role} onChange={(event) => onRoleChange(event.target.value as DeskRole)}>
              <option>All roles</option>
              <option>Executive</option>
              <option>Procurement</option>
              <option>DSO</option>
              <option>Accounting</option>
            </select>
          </label>
        }
      />

      <div className="desk-stats">
        <article className="primary-stat">
          <span className="stat-number">
            {role === "Executive" ? executiveOpenCount : needsYou.length}
          </span>
          <div>
            <strong>
              {role === "Executive"
                ? "open across teams"
                : canTakeAction
                  ? "on your desk"
                  : "in this view"}
            </strong>
            <small>
              {role === "Executive"
                ? "organized by current owner"
                : role === "All roles"
                  ? "across every role"
                  : `in ${role.toLowerCase()}`}
            </small>
          </div>
        </article>
        <article>
          <span className="stat-number">{pastStart}</span>
          <div><strong>past start date</strong><small>still in an open stage</small></div>
        </article>
        <article>
          <span className="stat-number">{requests.filter((request) => request.stage !== "approved").length}</span>
          <div><strong>open network-wide</strong><small>across all campuses</small></div>
        </article>
        <article>
          <span className="stat-number">{requests.filter((request) => !request.assignmentMatches && request.suggestedOwnerGid).length}</span>
          <div><strong>owner mismatches</strong><small>found by the assignment map</small></div>
        </article>
      </div>

      {role === "Executive" ? (
        executiveTeams.map((team) => {
          const teamRequests = requests.filter(
            (request) =>
              request.stage !== "approved" &&
              ROLE_STAGE[team.role].includes(request.stage),
          );
          return (
            <WorkSection
              key={team.role}
              title={team.title}
              count={teamRequests.length}
              note={team.note}
              requests={teamRequests}
              onOpen={onOpen}
            />
          );
        })
      ) : (
        <>
          <WorkSection title="Needs you" count={needsYou.length} note="Ready for a decision or handoff" requests={needsYou} onOpen={onOpen} />
          <WorkSection title="Waiting on vendor" count={waiting.length} note="Procurement document requests still open" requests={waiting} onOpen={onOpen} />
          <WorkSection title="Watching" count={watching.length} note="Moving through another team’s stage" requests={watching.slice(0, 5)} onOpen={onOpen} />
        </>
      )}
    </>
  );
}

function WorkSection({
  title,
  count,
  note,
  requests,
  onOpen,
}: {
  title: string;
  count: number;
  note: string;
  requests: ClubRequest[];
  onOpen: (request: ClubRequest) => void;
}) {
  return (
    <section className="work-section">
      <div className="section-heading">
        <div><h2>{title} <span>{count}</span></h2><p>{note}</p></div>
      </div>
      <div className="request-list">
        {requests.length ? (
          requests.map((request) => <RequestRow key={request.gid} request={request} onOpen={onOpen} />)
        ) : (
          <EmptyState>No requests are waiting here.</EmptyState>
        )}
      </div>
    </section>
  );
}

function PipelineView({
  requests,
  onOpen,
}: {
  requests: ClubRequest[];
  onOpen: (request: ClubRequest) => void;
}) {
  const pipelineStages = STAGES.filter((stage) => stage.key !== "incomplete");
  return (
    <>
      <PageIntro eyebrow="FULL PROCESS" title="Pipeline" copy="See every request in its current handoff stage, from intake through the first invoice." />
      <div className="pipeline-board">
        {pipelineStages.map((stage) => {
          const cards = requests.filter((request) => request.stage === stage.key);
          return (
            <section className={`pipeline-column column-${stage.key}`} key={stage.key}>
              <header>
                <span className="column-step">{stage.step}</span>
                <div><h2>{stage.shortLabel}</h2><span>{cards.length}</span></div>
                <small>{stage.owner === "—" ? "Process complete" : `${stage.owner} owns this stage`}</small>
              </header>
              <div className="pipeline-cards">
                {cards.map((request) => (
                  <button key={request.gid} className="pipeline-card" onClick={() => onOpen(request)}>
                    <div className="card-topline">
                      <span>{request.state}</span>
                      <span className="card-flags">
                        {(request.missingDocuments.length > 0 || request.stage === "no_documents") && (
                          <span title="Documents missing">
                            <Icon name="document" size={15} />
                          </span>
                        )}
                        {!request.assignmentMatches && request.suggestedOwnerGid && (
                          <span title="Assignment needs attention">
                            <Icon name="alert" size={15} />
                          </span>
                        )}
                      </span>
                    </div>
                    <strong>{request.vendor}</strong>
                    <p>{request.club || "Club not named"}</p>
                    <div className="card-campus">{request.campus}</div>
                    <div className="card-footer">
                      <span className="avatar">{initials(request.ownerName)}</span>
                      <span>{formatDate(request.startDate)}</span>
                    </div>
                  </button>
                ))}
                {!cards.length && <div className="column-empty">No requests</div>}
              </div>
            </section>
          );
        })}
      </div>
    </>
  );
}

function VendorView({
  requests,
  onOpen,
}: {
  requests: ClubRequest[];
  onOpen: (request: ClubRequest) => void;
}) {
  const groups = Array.from(
    requests.reduce((map, request) => {
      const key = request.vendor || request.title;
      map.set(key, [...(map.get(key) ?? []), request]);
      return map;
    }, new Map<string, ClubRequest[]>()),
  ).sort((a, b) => a[0].localeCompare(b[0]));

  return (
    <>
      <PageIntro eyebrow="VENDOR NETWORK" title="Vendors" copy="A roll-up of organizations operating one club or many, across every LTS campus and state." />
      <div className="vendor-grid">
        {groups.map(([vendor, vendorRequests]) => {
          const states = Array.from(new Set(vendorRequests.map((item) => item.state))).filter(Boolean);
          const open = vendorRequests.filter((item) => item.stage !== "approved").length;
          return (
            <article className="vendor-card" key={vendor}>
              <div className="vendor-monogram">{initials(vendor)}</div>
              <div className="vendor-card-body">
                <p className="eyebrow">{states.join(" · ") || "STATE NOT SET"}</p>
                <h2>{vendor}</h2>
                <p>{vendorRequests.length} campus {vendorRequests.length === 1 ? "request" : "requests"} · {open} open</p>
                <div className="vendor-campus-list">
                  {vendorRequests.slice(0, 4).map((request) => (
                    <button key={request.gid} onClick={() => onOpen(request)}>
                      <span>{request.campus}</span>
                      <StagePill stage={request.stage} />
                    </button>
                  ))}
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </>
  );
}

function AllRequestsView({
  requests,
  query,
  setQuery,
  stateFilter,
  setStateFilter,
  onOpen,
}: {
  requests: ClubRequest[];
  query: string;
  setQuery: (value: string) => void;
  stateFilter: string;
  setStateFilter: (value: string) => void;
  onOpen: (request: ClubRequest) => void;
}) {
  type SortKey = "vendor" | "stage" | "uploaded" | "missing" | "startDate" | "owner";
  const [sort, setSort] = useState<{ key: SortKey; direction: "asc" | "desc" }>({
    key: "vendor",
    direction: "asc",
  });
  const filtered = requests.filter((request) => {
    const haystack = `${request.vendor} ${request.club} ${request.campus} ${request.ownerName}`.toLowerCase();
    return haystack.includes(query.toLowerCase()) && (stateFilter === "All" || request.state.includes(stateFilter));
  });
  const sorted = [...filtered].sort((left, right) => {
    const valueFor = (request: ClubRequest) => {
      switch (sort.key) {
        case "vendor": return `${request.vendor} ${request.club} ${request.campus}`.toLocaleLowerCase();
        case "stage": return stageDefinition(request.stage).shortLabel.toLocaleLowerCase();
        case "uploaded": return request.uploadedDocuments.length;
        case "missing": return request.missingDocuments.length;
        case "startDate": return request.startDate ? new Date(request.startDate).getTime() : Number.POSITIVE_INFINITY;
        case "owner": return request.ownerName.toLocaleLowerCase();
      }
    };
    const leftValue = valueFor(left);
    const rightValue = valueFor(right);
    const comparison = typeof leftValue === "number" && typeof rightValue === "number"
      ? leftValue - rightValue
      : String(leftValue).localeCompare(String(rightValue), undefined, { sensitivity: "base" });
    return sort.direction === "asc" ? comparison : -comparison;
  });
  const updateSort = (key: SortKey) => {
    setSort((current) => ({
      key,
      direction: current.key === key && current.direction === "asc" ? "desc" : "asc",
    }));
  };
  const sortLabel = (key: SortKey, label: string) => (
    <button
      type="button"
      className="table-sort-button"
      aria-label={`Sort by ${label}`}
      aria-pressed={sort.key === key}
      onClick={() => updateSort(key)}
    >
      <span>{label}</span>
      <span className={`sort-indicator ${sort.key === key ? "is-active" : ""}`} aria-hidden="true">
        {sort.key === key ? (sort.direction === "asc" ? "↑" : "↓") : "↕"}
      </span>
    </button>
  );
  return (
    <>
      <PageIntro eyebrow="SEARCH + FILTER" title="All requests" copy="Find any vendor-club request, regardless of who owns the next step." />
      <div className="table-tools">
        <label className="search-box">
          <Icon name="search" size={18} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search vendor, club, campus, or owner" />
        </label>
        <label className="filter-select">
          <span>State</span>
          <select value={stateFilter} onChange={(event) => setStateFilter(event.target.value)}>
            <option>All</option><option>AZ</option><option>NV</option><option>SC</option><option>TX</option>
          </select>
        </label>
        <span className="result-count">{filtered.length} requests</span>
      </div>
      <div className="all-table">
        <div className="table-header">
          {sortLabel("vendor", "Vendor + club")}
          {sortLabel("stage", "Status")}
          {sortLabel("uploaded", "Documents uploaded")}
          {sortLabel("missing", "Documents missing")}
          {sortLabel("startDate", "Start date")}
          {sortLabel("owner", "Owner")}
          <span />
        </div>
        {sorted.map((request) => <RequestRow key={request.gid} request={request} onOpen={onOpen} />)}
        {!filtered.length && <EmptyState>No requests match these filters.</EmptyState>}
      </div>
    </>
  );
}

type InviteResponse = {
  error?: string;
  code?: string;
  invite?: AccessInvite;
  invites?: AccessInvite[];
};

function formatAccessDate(value: string | null) {
  if (!value) return "No expiration";
  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(new Date(value));
}

function AccessAdminView({ currentUserEmail }: { currentUserEmail: string }) {
  const [invites, setInvites] = useState<AccessInvite[]>([]);
  const [email, setEmail] = useState("");
  const [expires, setExpires] = useState("14");
  const [loading, setLoading] = useState(true);
  const [busyEmail, setBusyEmail] = useState("");
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const [generated, setGenerated] = useState<{
    email: string;
    code: string;
    expiresAt: string | null;
  } | null>(null);

  const loadInvites = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/admin/invites", { cache: "no-store" });
      const payload = (await response.json()) as InviteResponse;
      if (!response.ok || !payload.invites) {
        throw new Error(payload.error || "Access records could not be loaded.");
      }
      setInvites(payload.invites);
    } catch (loadError) {
      setError(
        loadError instanceof Error
          ? loadError.message
          : "Access records could not be loaded.",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => void loadInvites(), 0);
    return () => window.clearTimeout(timer);
  }, [loadInvites]);

  const generate = async (
    invitedEmail: string,
    expiresInDays: number | null,
  ) => {
    setBusyEmail(invitedEmail);
    setError("");
    setCopied(false);
    try {
      const response = await fetch("/api/admin/invites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: invitedEmail, expiresInDays }),
      });
      const payload = (await response.json()) as InviteResponse;
      if (!response.ok || !payload.code || !payload.invite || !payload.invites) {
        throw new Error(payload.error || "The access code could not be generated.");
      }
      setInvites(payload.invites);
      setGenerated({
        email: payload.invite.email,
        code: payload.code,
        expiresAt: payload.invite.expiresAt,
      });
      setEmail("");
    } catch (generateError) {
      setError(
        generateError instanceof Error
          ? generateError.message
          : "The access code could not be generated.",
      );
    } finally {
      setBusyEmail("");
    }
  };

  const submitInvite = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    await generate(email, expires === "never" ? null : Number(expires));
  };

  const revoke = async (invite: AccessInvite) => {
    if (!window.confirm(`Revoke access for ${invite.email}?`)) return;
    setBusyEmail(invite.email);
    setError("");
    try {
      const response = await fetch(
        `/api/admin/invites?email=${encodeURIComponent(invite.email)}`,
        { method: "DELETE" },
      );
      const payload = (await response.json()) as InviteResponse;
      if (!response.ok || !payload.invites) {
        throw new Error(payload.error || "Access could not be revoked.");
      }
      setInvites(payload.invites);
      if (generated?.email === invite.email) setGenerated(null);
    } catch (revokeError) {
      setError(
        revokeError instanceof Error
          ? revokeError.message
          : "Access could not be revoked.",
      );
    } finally {
      setBusyEmail("");
    }
  };

  const invitationMessage = () =>
    generated
      ? `You're invited to create your Vendor Club Approval Manager account!\nInternal Legacy Traditional Schools workspace for vendor-club approvals, campus assignments, and Asana handoffs.\n\nTo create your account, open ${window.location.origin}/access and enter:\nEmail: ${generated.email}\nAccess code: ${generated.code}\n\nYour access code is unique to you. Welcome!`
      : "";
  const activeCount = invites.filter((invite) => invite.status === "active").length;
  const pendingCount = invites.filter(
    (invite) => invite.status === "active" && !invite.lastUsedAt,
  ).length;

  return (
    <>
      <PageIntro
        eyebrow="SYSTEM ADMINISTRATOR"
        title="Access control"
        copy="Invite specific email addresses, issue expiring access codes, and revoke access immediately. Only you can see or use this dashboard."
        action={<span className="source-chip">ADMIN ONLY</span>}
      />

      <section className="access-admin-summary" aria-label="Access summary">
        <article><strong>{activeCount}</strong><span>active invitations</span></article>
        <article><strong>{pendingCount}</strong><span>not yet used</span></article>
        <article><strong>12h</strong><span>session duration</span></article>
      </section>

      <section className="access-admin-grid">
        <form className="access-invite-form" onSubmit={submitInvite}>
          <div>
            <p className="eyebrow">CREATE AN INVITATION</p>
            <h2>Add an approved email</h2>
            <p>
              Generating a new code for an existing email immediately ends its
              current sessions and replaces its previous code.
            </p>
          </div>
          <label>
            <span>Email address</span>
            <input
              type="email"
              required
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="person@organization.com"
            />
          </label>
          <label>
            <span>Code expires</span>
            <select value={expires} onChange={(event) => setExpires(event.target.value)}>
              <option value="7">In 7 days</option>
              <option value="14">In 14 days</option>
              <option value="30">In 30 days</option>
              <option value="90">In 90 days</option>
              <option value="never">Never</option>
            </select>
          </label>
          <button type="submit" disabled={Boolean(busyEmail)}>
            <Icon name="plus" size={16} />
            {busyEmail && busyEmail === email
              ? "Generating…"
              : "Generate access code"}
          </button>
        </form>

        <section className="generated-invite" aria-live="polite">
          {generated ? (
            <>
              <p className="eyebrow">CODE READY</p>
              <h2>{generated.email}</h2>
              <code>{generated.code}</code>
              <p>
                This is the only time the complete code is displayed. Share it
                with the invited person through a trusted channel.
              </p>
              <div>
                <button
                  type="button"
                  onClick={async () => {
                    await navigator.clipboard.writeText(invitationMessage());
                    setCopied(true);
                  }}
                >
                  {copied ? "Invite copied" : "Copy invite"}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    window.location.href = `mailto:${encodeURIComponent(generated.email)}?subject=${encodeURIComponent("Your Vendor Clubs access")}&body=${encodeURIComponent(invitationMessage())}`;
                  }}
                >
                  Open email draft
                </button>
              </div>
            </>
          ) : (
            <div className="generated-invite-empty">
              <Icon name="people" size={24} />
              <strong>No new code yet</strong>
              <p>A newly generated invitation will appear here once.</p>
            </div>
          )}
        </section>
      </section>

      {error && <div className="access-admin-error" role="alert">{error}</div>}

      <section className="access-ledger">
        <header>
          <div>
            <p className="eyebrow">ACCESS LEDGER</p>
            <h2>Invited users</h2>
          </div>
          <button type="button" onClick={() => void loadInvites()} disabled={loading}>
            {loading ? "Refreshing…" : "Refresh"}
          </button>
        </header>
        <div className="access-ledger-scroll">
          <table>
            <thead>
              <tr>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Code</th>
                <th>Expires</th>
                <th>Last sign-in</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {invites.map((invite) => (
                <tr key={invite.email}>
                  <td><strong>{invite.email}</strong></td>
                  <td>{invite.role === "admin" ? "Administrator" : "Viewer"}</td>
                  <td><span className={`access-status is-${invite.status}`}>{invite.status}</span></td>
                  <td>•••• {invite.codeHint}</td>
                  <td>{formatAccessDate(invite.expiresAt)}</td>
                  <td>{invite.lastUsedAt ? formatAccessDate(invite.lastUsedAt) : "Not yet used"}</td>
                  <td>
                    <div className="access-row-actions">
                      <button
                        type="button"
                        disabled={busyEmail === invite.email}
                        onClick={() => void generate(invite.email, invite.role === "admin" ? null : 14)}
                      >
                        New code
                      </button>
                      {invite.email !== currentUserEmail && (
                        <button
                          type="button"
                          className="danger"
                          disabled={busyEmail === invite.email}
                          onClick={() => void revoke(invite)}
                        >
                          Revoke
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {!loading && !invites.length && (
                <tr><td colSpan={7}>No invitations yet. Add the first approved email above.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}

function AssignmentView({
  requests,
  directory,
  configured,
  isSystemAdmin,
  onDirectoryChanged,
}: {
  requests: ClubRequest[];
  directory: AssignmentDirectory;
  configured: boolean;
  isSystemAdmin: boolean;
  onDirectoryChanged: (directory: AssignmentDirectory) => void;
}) {
  const [editor, setEditor] = useState<
    | { kind: "access"; record?: AccessContact }
    | { kind: "campus"; record: CampusContact }
    | null
  >(null);
  const requestCounts = requests.reduce((map, request) => {
    map.set(request.campus, (map.get(request.campus) ?? 0) + 1);
    return map;
  }, new Map<string, number>());
  const permissions: AccessPermission[] = [
    "Executive",
    "Procurement",
    "Accounting",
  ];
  return (
    <>
      <PageIntro
        eyebrow="ASSIGNMENT DIRECTORY"
        title="Campus contacts"
        copy="The live routing directory for campus, Procurement, Accounting, and executive access."
        action={
          <span className="source-chip">
            <Icon name="document" size={15} />
            {isSystemAdmin ? "ADMIN-MANAGED DIRECTORY" : "MANAGED IN THIS SITE"}
          </span>
        }
      />
      <section className="directory-control-panel">
        <div>
          <p className="eyebrow">ACCESS + CONNECTION</p>
          <h2>Role access</h2>
          <p>
            These records control who can act during each handoff. Only the
            System Administrator can make changes.
          </p>
        </div>
        <div className={`pat-status ${configured ? "connected" : ""}`}>
          <span />
          <div>
            <strong>Asana PAT</strong>
            <small>
              {configured ? "Securely connected" : "Credential still needed"}
            </small>
          </div>
        </div>
      </section>
      <div className="role-access-grid">
        {permissions.map((permission) => {
          const contacts = directory.accessContacts.filter(
            (contact) => contact.permission === permission,
          );
          return (
            <section className="role-access-card" key={permission}>
              <header>
                <div>
                  <span>{permission}</span>
                  <strong>{contacts.length}</strong>
                </div>
                {isSystemAdmin && (
                  <button
                    onClick={() =>
                      setEditor({
                        kind: "access",
                        record: { name: "", email: "", permission },
                      })
                    }
                  >
                    <Icon name="plus" size={14} /> Add person
                  </button>
                )}
              </header>
              <div className="role-contact-list">
                {contacts.map((contact) => (
                  <div key={contact.email}>
                    <span className="avatar">{initials(contact.name)}</span>
                    <span>
                      <strong>{contact.name}</strong>
                      <small>{contact.email}</small>
                    </span>
                    {isSystemAdmin && (
                      <button
                        onClick={() =>
                          setEditor({ kind: "access", record: contact })
                        }
                      >
                        Edit
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </section>
          );
        })}
      </div>
      <div className="assignment-summary">
        <div><strong>{directory.campusContacts.length}</strong><span>campuses mapped</span></div>
        <div><strong>{new Set(directory.campusContacts.map((contact) => contact.asanaGid)).size}</strong><span>unique contacts</span></div>
        <div><strong>4</strong><span>states covered</span></div>
        <div><strong>{requests.filter((request) => !request.assignmentMatches && request.suggestedOwnerGid).length}</strong><span>requests to correct</span></div>
      </div>
      <div className="assignment-table">
        <div className="assignment-header">
          <span>Campus</span><span>State</span><span>Assigned contact</span><span>Role</span><span>Asana</span><span>Open</span>
        </div>
        {directory.campusContacts.map((contact) => (
          <div className="assignment-row" key={`${contact.campus}-${contact.email}`}>
            <strong>{contact.campus}</strong>
            <span className="state-token">{contact.state}</span>
            <span className="person-cell">
              <span className="avatar">{initials(contact.name)}</span>
              <span><strong>{contact.name}</strong><small>{contact.email}</small></span>
              {isSystemAdmin && (
                <button
                  className="assignment-edit-button"
                  onClick={() => setEditor({ kind: "campus", record: contact })}
                >
                  Edit
                </button>
              )}
            </span>
            <span>{contact.role}</span>
            <span className="matched"><Icon name="check" size={14} /> Matched</span>
            <span>{requestCounts.get(contact.campus) ?? 0}</span>
          </div>
        ))}
      </div>
      {editor && (
        <DirectoryEditor
          editor={editor}
          onClose={() => setEditor(null)}
          onSaved={(nextDirectory) => {
            onDirectoryChanged(nextDirectory);
            setEditor(null);
          }}
        />
      )}
    </>
  );
}

function DirectoryEditor({
  editor,
  onClose,
  onSaved,
}: {
  editor:
    | { kind: "access"; record?: AccessContact }
    | { kind: "campus"; record: CampusContact };
  onClose: () => void;
  onSaved: (directory: AssignmentDirectory) => void;
}) {
  const existingAccessEmail =
    editor.kind === "access" ? editor.record?.email ?? "" : "";
  const [accessRecord, setAccessRecord] = useState<AccessContact>(
    editor.kind === "access"
      ? editor.record ?? {
          name: "",
          email: "",
          permission: "Executive",
        }
      : { name: "", email: "", permission: "Executive" },
  );
  const [campusRecord, setCampusRecord] = useState<CampusContact>(
    editor.kind === "campus"
      ? editor.record
      : {
          campus: "",
          state: "",
          name: "",
          role: "",
          email: "",
          asanaGid: "",
        },
  );
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");

  const save = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setBusy("save");
    setError("");
    try {
      const response = await fetch("/api/admin/directory", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          kind: editor.kind,
          record: editor.kind === "access" ? accessRecord : campusRecord,
        }),
      });
      const payload = (await response.json()) as {
        error?: string;
        directory?: AssignmentDirectory;
      };
      if (!response.ok || !payload.directory) {
        throw new Error(payload.error || "The directory update failed.");
      }
      onSaved(payload.directory);
    } catch (saveError) {
      setError(
        saveError instanceof Error
          ? saveError.message
          : "The directory update failed.",
      );
    } finally {
      setBusy("");
    }
  };

  const remove = async () => {
    if (!existingAccessEmail) return;
    setBusy("delete");
    setError("");
    try {
      const response = await fetch(
        `/api/admin/directory?email=${encodeURIComponent(existingAccessEmail)}`,
        { method: "DELETE" },
      );
      const payload = (await response.json()) as {
        error?: string;
        directory?: AssignmentDirectory;
      };
      if (!response.ok || !payload.directory) {
        throw new Error(
          payload.error || "The access record could not be removed.",
        );
      }
      onSaved(payload.directory);
    } catch (removeError) {
      setError(
        removeError instanceof Error
          ? removeError.message
          : "The access record could not be removed.",
      );
    } finally {
      setBusy("");
    }
  };

  return (
    <div
      className="modal-layer"
      role="dialog"
      aria-modal="true"
      aria-labelledby="directory-editor-title"
    >
      <button
        className="modal-scrim"
        onClick={onClose}
        aria-label="Close editor"
      />
      <form className="directory-modal" onSubmit={save}>
        <header>
          <div>
            <p className="eyebrow">SYSTEM ADMINISTRATOR</p>
            <h2 id="directory-editor-title">
              {editor.kind === "access"
                ? existingAccessEmail
                  ? "Edit role access"
                  : "Add role access"
                : `Edit ${campusRecord.campus}`}
            </h2>
          </div>
          <button
            type="button"
            className="icon-button"
            onClick={onClose}
            aria-label="Close"
          >
            <Icon name="close" />
          </button>
        </header>
        <div className="directory-modal-body">
          {editor.kind === "access" ? (
            <div className="form-grid">
              <label className="form-field form-field-wide">
                <span>Name *</span>
                <input
                  required
                  value={accessRecord.name}
                  onChange={(event) =>
                    setAccessRecord((current) => ({
                      ...current,
                      name: event.target.value,
                    }))
                  }
                />
              </label>
              <label className="form-field form-field-wide">
                <span>Email *</span>
                <input
                  required
                  type="email"
                  disabled={Boolean(existingAccessEmail)}
                  value={accessRecord.email}
                  onChange={(event) =>
                    setAccessRecord((current) => ({
                      ...current,
                      email: event.target.value,
                    }))
                  }
                />
                {existingAccessEmail && (
                  <small>
                    Remove and re-add this person to change their email.
                  </small>
                )}
              </label>
              <label className="form-field form-field-wide">
                <span>Permission *</span>
                <select
                  required
                  value={accessRecord.permission}
                  onChange={(event) =>
                    setAccessRecord((current) => ({
                      ...current,
                      permission: event.target.value as AccessPermission,
                    }))
                  }
                >
                  <option value="Executive">Executive</option>
                  <option value="Procurement">Procurement</option>
                  <option value="Accounting">Accounting</option>
                </select>
              </label>
            </div>
          ) : (
            <div className="form-grid">
              <label className="form-field">
                <span>Campus</span>
                <input readOnly value={campusRecord.campus} />
              </label>
              <label className="form-field">
                <span>State</span>
                <input readOnly value={campusRecord.state} />
              </label>
              <label className="form-field">
                <span>Assigned contact *</span>
                <input
                  required
                  value={campusRecord.name}
                  onChange={(event) =>
                    setCampusRecord((current) => ({
                      ...current,
                      name: event.target.value,
                    }))
                  }
                />
              </label>
              <label className="form-field">
                <span>Role *</span>
                <input
                  required
                  value={campusRecord.role}
                  onChange={(event) =>
                    setCampusRecord((current) => ({
                      ...current,
                      role: event.target.value,
                    }))
                  }
                />
              </label>
              <label className="form-field form-field-wide">
                <span>Email *</span>
                <input
                  required
                  type="email"
                  value={campusRecord.email}
                  onChange={(event) =>
                    setCampusRecord((current) => ({
                      ...current,
                      email: event.target.value,
                    }))
                  }
                />
              </label>
              <label className="form-field form-field-wide">
                <span>Asana user ID *</span>
                <input
                  required
                  inputMode="numeric"
                  pattern="[0-9]+"
                  value={campusRecord.asanaGid}
                  onChange={(event) =>
                    setCampusRecord((current) => ({
                      ...current,
                      asanaGid: event.target.value,
                    }))
                  }
                />
                <small>
                  This ID assigns the Asana task to the correct campus contact.
                </small>
              </label>
            </div>
          )}
          {error && (
            <div className="intake-error">
              <Icon name="alert" size={15} /> {error}
            </div>
          )}
        </div>
        <footer>
          {editor.kind === "access" && existingAccessEmail ? (
            <button
              type="button"
              className="danger-button"
              disabled={Boolean(busy)}
              onClick={() => void remove()}
            >
              {busy === "delete" ? "Removing…" : "Remove access"}
            </button>
          ) : (
            <span />
          )}
          <div>
            <button
              type="button"
              className="secondary-button"
              onClick={onClose}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="submit-request-button"
              disabled={Boolean(busy)}
            >
              {busy === "save" ? "Saving…" : "Save changes"}
            </button>
          </div>
        </footer>
      </form>
    </div>
  );
}

function DetailItem({ label, children }: { label: string; children?: React.ReactNode }) {
  return (
    <div className="detail-item">
      <span>{label}</span>
      <strong>{children || "Not provided"}</strong>
    </div>
  );
}

const editableFieldsFor = (request: ClubRequest): EditableRequestFields => ({
  vendorName: request.vendor,
  legalName: request.legalName ?? "",
  club: request.club,
  startDate: request.startDate?.slice(0, 10) ?? "",
  endDate: request.endDate?.slice(0, 10) ?? "",
  contactName: request.contactName ?? "",
  email: request.email ?? "",
  phone: request.phone ?? "",
  tuition: request.tuition ?? "",
  nonprofit:
    request.nonprofit === "Yes" || request.nonprofit === "No"
      ? request.nonprofit
      : "",
  instructorNames: request.instructorNames ?? "",
});

function RequestDrawer({
  request,
  relatedRequests,
  configured,
  isSystemAdmin,
  isExecutive,
  actionRole,
  canTakeAction,
  accessLabel,
  onClose,
  onUpdated,
}: {
  request: ClubRequest;
  relatedRequests: ClubRequest[];
  configured: boolean;
  isSystemAdmin: boolean;
  isExecutive: boolean;
  actionRole: RoleKey | null;
  canTakeAction: boolean;
  accessLabel: string;
  onClose: () => void;
  onUpdated: (message: string) => Promise<void>;
}) {
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [comment, setComment] = useState("");
  const [editingFields, setEditingFields] = useState(false);
  const [fieldDraft, setFieldDraft] = useState<EditableRequestFields>(() =>
    editableFieldsFor(request),
  );
  const [pendingUpload, setPendingUpload] = useState<File[]>([]);
  const [applyToVendorTasks, setApplyToVendorTasks] = useState(false);
  const [selectedTaskGids, setSelectedTaskGids] = useState<string[]>([
    request.gid,
  ]);
  const [selectedDocumentOptionGids, setSelectedDocumentOptionGids] = useState<
    string[]
  >([]);
  const availableTargetStages = STAGES.filter(
    (stage) =>
      stage.key !== request.stage &&
      (isSystemAdmin ||
        isExecutive ||
        (actionRole ? ROLE_STAGE_TARGETS[actionRole].includes(stage.key) : false)),
  );
  const suggestedTarget = nextStage(request.stage);
  const defaultTarget =
    suggestedTarget &&
    availableTargetStages.some((stage) => stage.key === suggestedTarget)
      ? suggestedTarget
      : availableTargetStages[0]?.key;
  const [targetStage, setTargetStage] = useState<StageKey | "">(
    defaultTarget ?? "",
  );

  const perform = async (action: Record<string, unknown>, message: string, busyKey: string) => {
    if (!configured || !canTakeAction) return false;
    setBusy(busyKey);
    setError("");
    try {
      const response = await fetch("/api/asana/actions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...action, taskGid: request.gid }),
      });
      const payload = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(payload.error || "The Asana update failed.");
      await onUpdated(message);
      if (busyKey === "comment") setComment("");
      return true;
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : "The Asana update failed.");
      return false;
    } finally {
      setBusy("");
    }
  };

  const openUploadReview = (files: FileList | null) => {
    if (!files?.length || !configured || !canTakeAction) return;
    setPendingUpload(Array.from(files));
    setApplyToVendorTasks(false);
    setSelectedTaskGids([request.gid]);
    setSelectedDocumentOptionGids([]);
    setError("");
  };

  const uploadDocuments = async () => {
    if (
      !pendingUpload.length ||
      !selectedTaskGids.length ||
      !configured ||
      !canTakeAction
    ) return;
    setBusy("upload");
    setError("");
    try {
      for (const file of pendingUpload) {
        const formData = new FormData();
        selectedTaskGids.forEach((taskGid) =>
          formData.append("taskGid", taskGid),
        );
        selectedDocumentOptionGids.forEach((optionGid) =>
          formData.append("documentOptionGid", optionGid),
        );
        formData.append("file", file);
        const response = await fetch("/api/asana/attachments", {
          method: "POST",
          body: formData,
        });
        const payload = (await response.json()) as { error?: string };
        if (!response.ok) {
          throw new Error(payload.error || `Could not upload ${file.name}.`);
        }
      }
      await onUpdated(
        `${pendingUpload.length} ${
          pendingUpload.length === 1 ? "document" : "documents"
        } uploaded to ${selectedTaskGids.length} ${
          selectedTaskGids.length === 1 ? "task" : "tasks"
        } for ${request.vendor}.`,
      );
      setPendingUpload([]);
    } catch (uploadError) {
      setError(
        uploadError instanceof Error
          ? uploadError.message
          : "The document upload failed.",
      );
    } finally {
      setBusy("");
    }
  };

  return (
    <div className="drawer-layer" role="dialog" aria-modal="true" aria-label={`${request.vendor} request details`}>
      <button className="drawer-scrim" onClick={onClose} aria-label="Close details" />
      <aside className="request-drawer">
        <header className="drawer-header">
          <div>
            <p className="eyebrow">{request.state} · {request.campus}</p>
            <h2>{request.vendor}</h2>
            <p>{request.club || "Club not named"} {request.ltsc ? `· ${request.ltsc}` : ""}</p>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="Close"><Icon name="close" /></button>
        </header>
        <div className="drawer-body">
          <section className="status-rail">
            {STAGES.filter((stage) => stage.key !== "incomplete").map((stage, index) => {
              const currentIndex = STAGES.findIndex((item) => item.key === request.stage);
              const stageIndex = STAGES.findIndex((item) => item.key === stage.key);
              const state = stage.key === request.stage ? "current" : stageIndex < currentIndex ? "done" : "future";
              return (
                <div className={`rail-step ${state}`} key={stage.key}>
                  <span>{state === "done" ? <Icon name="check" size={13} /> : index + 1}</span>
                  <div><strong>{stage.shortLabel}</strong><small>{stage.owner}</small></div>
                </div>
              );
            })}
          </section>

          <section className="drawer-section action-panel">
            <div className="section-kicker">CURRENT HANDOFF</div>
            {isSystemAdmin && (
              <div className="admin-override-note">
                <Icon name="check" size={14} />
                System Administrator · All role actions enabled
              </div>
            )}
            {isExecutive && (
              <div className="admin-override-note executive-permission">
                <Icon name="check" size={14} />
                Executive · All role actions enabled
              </div>
            )}
            {!isSystemAdmin && !isExecutive && canTakeAction && (
              <div className="admin-override-note contact-permission">
                <Icon name="check" size={14} />
                {accessLabel} · Action permitted for this request
              </div>
            )}
            <div className="action-title">
              <div><StagePill stage={request.stage} /><h3>{stageDefinition(request.stage).step}</h3></div>
              <div className="owner-block"><span className="avatar">{initials(request.ownerName)}</span><span><small>Owner</small><strong>{request.ownerName}</strong></span></div>
            </div>
            {!request.assignmentMatches && request.suggestedOwnerGid && (
              <div className="assignment-callout">
                <Icon name="alert" size={18} />
                <div><strong>Assignment needs attention</strong><span>This stage should be owned by {request.suggestedOwnerName}.</span></div>
                <button disabled={!configured || !canTakeAction || Boolean(busy)} onClick={() => void perform({ action: "syncAssignment" }, `Assigned to ${request.suggestedOwnerName} in Asana.`, "assignment")}>
                  {busy === "assignment" ? "Updating…" : "Apply owner"}
                </button>
              </div>
            )}
            {availableTargetStages.length > 0 && (
              <div className="status-update-control">
                <label htmlFor={`status-target-${request.gid}`}>
                  <span>Move to status</span>
                  <select
                    id={`status-target-${request.gid}`}
                    value={targetStage}
                    disabled={!configured || !canTakeAction || Boolean(busy)}
                    onChange={(event) =>
                      setTargetStage(event.target.value as StageKey)
                    }
                  >
                    {availableTargetStages.map((stage) => (
                      <option key={stage.key} value={stage.key}>
                        {stage.label}
                      </option>
                    ))}
                  </select>
                </label>
                <button
                  className="primary-action"
                  disabled={
                    !configured ||
                    !canTakeAction ||
                    !targetStage ||
                    Boolean(busy)
                  }
                  onClick={() =>
                    targetStage &&
                    void perform(
                      { action: "advance", targetStage },
                      `Moved to ${stageDefinition(targetStage).shortLabel} in Asana.`,
                      "advance",
                    )
                  }
                >
                  <span>
                    {busy === "advance"
                      ? "Updating Asana..."
                      : `Move to ${stageDefinition(targetStage || request.stage).shortLabel}`}
                  </span>
                  <Icon name="arrow" size={17} />
                </button>
              </div>
            )}
            {!canTakeAction ? (
              <p className="locked-note">This request is view-only for your account.</p>
            ) : !configured ? (
              <p className="locked-note">Write actions unlock when the secure Asana connection is added.</p>
            ) : null}
          </section>

          {error && <div className="drawer-error"><Icon name="alert" size={15} /> {error}</div>}

          <section className="drawer-section">
            <div className="section-title">
              <h3>Request details</h3>
              {configured && canTakeAction ? (
                <button
                  type="button"
                  className="section-edit-button"
                  disabled={Boolean(busy)}
                  onClick={() => {
                    setFieldDraft(editableFieldsFor(request));
                    setEditingFields((current) => !current);
                    setError("");
                  }}
                >
                  <Icon name="edit" size={13} />
                  {editingFields ? "Cancel editing" : "Edit fields"}
                </button>
              ) : (
                <span>Asana fields</span>
              )}
            </div>
            {editingFields ? (
              <form
                className="request-field-form"
                onSubmit={(event) => {
                  event.preventDefault();
                  void perform(
                    { action: "updateFields", fields: fieldDraft },
                    "Request fields updated in Asana.",
                    "fields",
                  ).then((saved) => {
                    if (saved) setEditingFields(false);
                  });
                }}
              >
                <div className="request-field-grid">
                  <label>
                    <span>Vendor name *</span>
                    <input
                      required
                      value={fieldDraft.vendorName}
                      onChange={(event) =>
                        setFieldDraft((current) => ({
                          ...current,
                          vendorName: event.target.value,
                        }))
                      }
                    />
                  </label>
                  <label>
                    <span>Legal business name</span>
                    <input
                      value={fieldDraft.legalName}
                      onChange={(event) =>
                        setFieldDraft((current) => ({
                          ...current,
                          legalName: event.target.value,
                        }))
                      }
                    />
                  </label>
                  <label className="request-field-wide">
                    <span>Club or program *</span>
                    <input
                      required
                      value={fieldDraft.club}
                      onChange={(event) =>
                        setFieldDraft((current) => ({
                          ...current,
                          club: event.target.value,
                        }))
                      }
                    />
                  </label>
                  <label>
                    <span>Club start</span>
                    <input
                      type="date"
                      value={fieldDraft.startDate}
                      onChange={(event) =>
                        setFieldDraft((current) => ({
                          ...current,
                          startDate: event.target.value,
                        }))
                      }
                    />
                  </label>
                  <label>
                    <span>Club end</span>
                    <input
                      type="date"
                      value={fieldDraft.endDate}
                      onChange={(event) =>
                        setFieldDraft((current) => ({
                          ...current,
                          endDate: event.target.value,
                        }))
                      }
                    />
                  </label>
                  <label>
                    <span>Nonprofit</span>
                    <select
                      value={fieldDraft.nonprofit}
                      onChange={(event) =>
                        setFieldDraft((current) => ({
                          ...current,
                          nonprofit: event.target
                            .value as EditableRequestFields["nonprofit"],
                        }))
                      }
                    >
                      <option value="">Not set</option>
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>
                  </label>
                  <label>
                    <span>Student tuition</span>
                    <input
                      value={fieldDraft.tuition}
                      onChange={(event) =>
                        setFieldDraft((current) => ({
                          ...current,
                          tuition: event.target.value,
                        }))
                      }
                    />
                  </label>
                  <label>
                    <span>Vendor contact</span>
                    <input
                      value={fieldDraft.contactName}
                      onChange={(event) =>
                        setFieldDraft((current) => ({
                          ...current,
                          contactName: event.target.value,
                        }))
                      }
                    />
                  </label>
                  <label>
                    <span>Vendor email</span>
                    <input
                      type="email"
                      value={fieldDraft.email}
                      onChange={(event) =>
                        setFieldDraft((current) => ({
                          ...current,
                          email: event.target.value,
                        }))
                      }
                    />
                  </label>
                  <label>
                    <span>Vendor phone</span>
                    <input
                      type="tel"
                      value={fieldDraft.phone}
                      onChange={(event) =>
                        setFieldDraft((current) => ({
                          ...current,
                          phone: event.target.value,
                        }))
                      }
                    />
                  </label>
                  <label className="request-field-wide">
                    <span>Instructor names</span>
                    <textarea
                      rows={3}
                      value={fieldDraft.instructorNames}
                      onChange={(event) =>
                        setFieldDraft((current) => ({
                          ...current,
                          instructorNames: event.target.value,
                        }))
                      }
                    />
                  </label>
                </div>
                <div className="field-form-actions">
                  <button
                    type="button"
                    className="secondary-button"
                    disabled={Boolean(busy)}
                    onClick={() => {
                      setFieldDraft(editableFieldsFor(request));
                      setEditingFields(false);
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="submit-request-button"
                    disabled={Boolean(busy)}
                  >
                    {busy === "fields" ? "Saving…" : "Save to Asana"}
                  </button>
                </div>
              </form>
            ) : (
              <div className="detail-grid">
                <DetailItem label="Vendor name">{request.vendor}</DetailItem>
                <DetailItem label="Legal business name">{request.legalName}</DetailItem>
                <DetailItem label="Club or program">{request.club}</DetailItem>
                <DetailItem label="Nonprofit">{request.nonprofit}</DetailItem>
                <DetailItem label="Club start"><Icon name="calendar" size={14} /> {formatDate(request.startDate)}</DetailItem>
                <DetailItem label="Club end">{formatDate(request.endDate)}</DetailItem>
                <DetailItem label="Student tuition">{request.tuition}</DetailItem>
                <DetailItem label="Campus contact">{request.dsoNames.join(", ") || request.suggestedOwnerName}</DetailItem>
                <DetailItem label="Vendor contact">{request.contactName}</DetailItem>
                <DetailItem label="Vendor email">{request.email}</DetailItem>
                <DetailItem label="Vendor phone">{request.phone}</DetailItem>
                <DetailItem label="Instructor names">{request.instructorNames}</DetailItem>
              </div>
            )}
          </section>

          <section className="drawer-section">
            <div className="section-title">
              <h3>Attachments</h3>
              <span>
                {request.attachments.length
                  ? `${request.attachments.length} attached`
                  : "Documents missing"}
              </span>
            </div>
            {!request.attachments.length && (
              <div className="missing-attachment-alert">
                <Icon name="alert" size={18} />
                <div>
                  <strong>Documents missing</strong>
                  <span>This Asana task has no attachments.</span>
                </div>
              </div>
            )}
            {request.attachments.length > 0 && (
              <div className="attachment-list">
                {request.attachments.map((attachment) => (
                  <a
                    href={attachment.permanentUrl || request.permalinkUrl}
                    key={attachment.gid}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <span className="document-icon">
                      <Icon name="document" size={16} />
                    </span>
                    <span>
                      <strong>{attachment.name}</strong>
                      <small>Attached to the Asana task</small>
                    </span>
                    <Icon name="external" size={14} />
                  </a>
                ))}
              </div>
            )}
            {configured && canTakeAction && (
              <label
                className={`upload-control ${
                  busy === "upload" ? "uploading" : ""
                }`}
              >
                <input
                  type="file"
                  multiple
                  accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.png,.jpg,.jpeg"
                  disabled={Boolean(busy)}
                  onChange={(event) => {
                    const input = event.currentTarget;
                    openUploadReview(input.files);
                    input.value = "";
                  }}
                />
                <Icon name="upload" size={17} />
                <span>
                  <strong>
                    {busy === "upload"
                      ? "Uploading to Asana…"
                      : "Upload documents"}
                  </strong>
                  <small>PDF, Word, Excel, CSV, or image · up to 90 MB each</small>
                </span>
              </label>
            )}
          </section>

          <section className="drawer-section">
            <div className="section-title"><h3>Document status</h3><span>{request.uploadedDocuments.length} uploaded / {request.missingDocuments.length} missing</span></div>
            <div className="document-status-block">
              <h4>Documents uploaded</h4>
              {request.uploadedDocuments.length ? (
                <div className="uploaded-document-list">
                  {request.uploadedDocuments.map((document) => (
                    <div key={document.gid}>
                      <span><Icon name="check" size={13} /></span>
                      <strong>{document.name}</strong>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="document-empty-note">None marked in Asana.</p>
              )}
            </div>
            <h4 className="missing-document-heading">Documents missing</h4>
            {request.missingDocuments.length ? (
              <div className="document-list">
                {request.missingDocuments.map((document) => (
                  <div key={document.gid}>
                    <span className="document-icon"><Icon name="document" size={16} /></span>
                    <div><strong>{document.name}</strong><small>Marked missing in Asana</small></div>
                    <button disabled={!configured || !canTakeAction || Boolean(busy)} onClick={() => void perform({ action: "documentReceived", documentOptionGid: document.gid }, `${document.name} marked received in Asana.`, document.gid)}>
                      {busy === document.gid ? "Saving…" : "Mark received"}
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="package-complete"><Icon name="check" size={17} /> No missing documents are flagged.</div>
            )}
          </section>

          <section className="drawer-section">
            <div className="section-title"><h3>Add an Asana comment</h3><span>Visible to project members</span></div>
            <textarea value={comment} onChange={(event) => setComment(event.target.value)} placeholder="Share a handoff note or vendor update…" rows={4} disabled={!configured || !canTakeAction} />
            <div className="comment-actions">
              <a href={request.permalinkUrl} target="_blank" rel="noreferrer"><Icon name="external" size={14} /> Open full task</a>
              <button disabled={!configured || !canTakeAction || !comment.trim() || Boolean(busy)} onClick={() => void perform({ action: "comment", text: comment }, "Comment added to Asana.", "comment")}>
                <Icon name="comment" size={15} /> {busy === "comment" ? "Posting…" : "Post comment"}
              </button>
            </div>
          </section>
        </div>
      </aside>
      {pendingUpload.length > 0 && (
        <div className="bulk-upload-layer">
          <button
            type="button"
            className="bulk-upload-scrim"
            aria-label="Cancel bulk upload"
            onClick={() => setPendingUpload([])}
          />
          <section
            className="bulk-upload-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="bulk-upload-title"
          >
            <header>
              <div>
                <p className="eyebrow">UPLOAD REVIEW</p>
                <h2 id="bulk-upload-title">Apply to all tasks for this vendor?</h2>
                <p>
                  Choose exactly which {request.vendor} tasks should receive
                  {pendingUpload.length === 1 ? " this document" : " these documents"}.
                </p>
              </div>
              <button
                type="button"
                className="bulk-upload-close"
                aria-label="Cancel upload"
                onClick={() => setPendingUpload([])}
              >
                <Icon name="close" size={17} />
              </button>
            </header>

            <div className="bulk-upload-body">
              <div className="bulk-file-summary">
                <span className="document-icon"><Icon name="document" size={16} /></span>
                <div>
                  <strong>
                    {pendingUpload.length} {pendingUpload.length === 1 ? "file" : "files"} ready
                  </strong>
                  <small>{pendingUpload.map((file) => file.name).join(", ")}</small>
                </div>
              </div>

              <fieldset className="bulk-scope-options">
                <legend>Where should the files be added?</legend>
                <label>
                  <input
                    type="radio"
                    name="upload-scope"
                    checked={!applyToVendorTasks}
                    onChange={() => {
                      setApplyToVendorTasks(false);
                      setSelectedTaskGids([request.gid]);
                    }}
                  />
                  <span>
                    <strong>Only this task</strong>
                    <small>{request.campus} Â· {request.club || "Club not named"}</small>
                  </span>
                </label>
                <label className={relatedRequests.length < 2 ? "is-disabled" : ""}>
                  <input
                    type="radio"
                    name="upload-scope"
                    disabled={relatedRequests.length < 2}
                    checked={applyToVendorTasks}
                    onChange={() => {
                      setApplyToVendorTasks(true);
                      setSelectedTaskGids(relatedRequests.map((item) => item.gid));
                    }}
                  />
                  <span>
                    <strong>Choose vendor tasks</strong>
                    <small>
                      {relatedRequests.length < 2
                        ? "No other authorized tasks for this vendor"
                        : `${relatedRequests.length} authorized tasks available`}
                    </small>
                  </span>
                </label>
              </fieldset>

              {applyToVendorTasks && (
                <fieldset className="bulk-task-picker">
                  <legend>Select the tasks that apply</legend>
                  {relatedRequests.map((item) => (
                    <label key={item.gid}>
                      <input
                        type="checkbox"
                        checked={selectedTaskGids.includes(item.gid)}
                        onChange={() =>
                          setSelectedTaskGids((current) =>
                            current.includes(item.gid)
                              ? current.filter((gid) => gid !== item.gid)
                              : [...current, item.gid],
                          )
                        }
                      />
                      <span>
                        <strong>{item.campus}</strong>
                        <small>{item.club || "Club not named"}</small>
                      </span>
                      <StagePill stage={item.stage} />
                    </label>
                  ))}
                </fieldset>
              )}

              <fieldset className="bulk-document-types">
                <legend>Update “Documents Uploaded” <span>optional</span></legend>
                <p>Selecting a type also clears its matching “Documents Missing” item on each chosen task.</p>
                <div>
                  {UPLOADED_DOCUMENT_OPTIONS.map((option) => (
                    <label key={option.gid}>
                      <input
                        type="checkbox"
                        checked={selectedDocumentOptionGids.includes(option.gid)}
                        onChange={() =>
                          setSelectedDocumentOptionGids((current) =>
                            current.includes(option.gid)
                              ? current.filter((gid) => gid !== option.gid)
                              : [...current, option.gid],
                          )
                        }
                      />
                      <span>{option.name}</span>
                    </label>
                  ))}
                </div>
              </fieldset>
            </div>

            <footer>
              <span>
                {selectedTaskGids.length
                  ? `${pendingUpload.length * selectedTaskGids.length} file ${
                      pendingUpload.length * selectedTaskGids.length === 1 ? "copy" : "copies"
                    } will be added`
                  : "Select at least one task"}
              </span>
              <div>
                <button
                  type="button"
                  className="secondary-button"
                  disabled={busy === "upload"}
                  onClick={() => setPendingUpload([])}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  className="submit-request-button"
                  disabled={busy === "upload" || selectedTaskGids.length === 0}
                  onClick={() => void uploadDocuments()}
                >
                  {busy === "upload"
                    ? "Uploading to Asanaâ€¦"
                    : `Upload to ${selectedTaskGids.length} ${
                        selectedTaskGids.length === 1 ? "task" : "tasks"
                      }`}
                </button>
              </div>
            </footer>
          </section>
        </div>
      )}
    </div>
  );
}

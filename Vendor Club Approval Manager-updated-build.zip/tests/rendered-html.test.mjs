import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import test from "node:test";

async function loadWorker(label) {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set(label, `${process.pid}-${Date.now()}-${Math.random()}`);
  return (await import(workerUrl.href)).default;
}

const environment = {
  ASSETS: {
    fetch: async () => new Response("Not found", { status: 404 }),
  },
};

const executionContext = {
  waitUntil() {},
  passThroughOnException() {},
};

async function render(path = "/", init = {}) {
  const worker = await loadWorker("render");
  return worker.fetch(
    new Request(`http://localhost${path}`, {
      headers: { accept: "text/html", ...(init.headers ?? {}) },
      ...init,
    }),
    environment,
    executionContext,
  );
}

test("server-renders the controlled vestibule for anonymous visitors", async () => {
  const rootResponse = await render("/", { redirect: "manual" });
  assert.equal(rootResponse.status, 307);
  assert.equal(rootResponse.headers.get("location"), "http://localhost/access");

  const response = await render("/access");
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /Vendor Clubs\./);
  assert.match(html, /Authorized access only/);
  assert.match(html, /Invitation required/i);
  assert.match(html, /Email address/);
  assert.match(html, /Access code/);
  assert.doesNotMatch(html, /Admin desk/);
  assert.doesNotMatch(html, /My desk/);
});

test("rejects anonymous reads of operational data", async () => {
  for (const path of [
    "/api/asana/requests",
    "/api/admin/directory",
    "/api/admin/invites",
  ]) {
    const response = await render(path, { headers: { accept: "application/json" } });
    assert.equal(response.status, 401, path);
    assert.match(await response.text(), /sign in/i);
  }
});

test("rejects anonymous operational writes and uploads", async () => {
  const action = await render("/api/asana/actions", {
    method: "POST",
    headers: { "content-type": "application/json", accept: "application/json" },
    body: JSON.stringify({ action: "comment", taskGid: "test", text: "blocked" }),
  });
  assert.equal(action.status, 401);

  const formData = new FormData();
  formData.append("taskGid", "test");
  formData.append("file", new File(["test"], "test.pdf", { type: "application/pdf" }));
  const upload = await render("/api/asana/attachments", {
    method: "POST",
    headers: { accept: "application/json" },
    body: formData,
  });
  assert.equal(upload.status, 401);
});

test("blocks protected document assets without an authenticated session", async () => {
  for (const path of [
    "/guides/system-administrator-user-guide.docx",
    "/contracts/az-26-27-vendor-contract-template.docx",
  ]) {
    const response = await render(path, { redirect: "manual" });
    assert.equal(response.status, 302, path);
    assert.equal(response.headers.get("location"), "/");
  }
});

test("rejects cross-site sign-in submissions", async () => {
  const response = await render("/api/auth/login", {
    method: "POST",
    headers: {
      accept: "application/json",
      "content-type": "application/json",
      origin: "https://untrusted.example",
      "sec-fetch-site": "cross-site",
    },
    body: JSON.stringify({ email: "person@example.com", code: "AAAA-BBBB-CCCC" }),
  });
  assert.equal(response.status, 403);
});

test("ships the current Asana status and vendor bulk-document workflow", async () => {
  const [workflow, asana, access, manager, attachmentsRoute] = await Promise.all([
    readFile(new URL("../app/lib/vendor-clubs.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/lib/asana.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/lib/access.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/components/VendorClubManager.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/api/asana/attachments/route.ts", import.meta.url), "utf8"),
  ]);

  assert.match(workflow, /No documents submitted/);
  assert.match(workflow, /Waiting on contract/);
  assert.match(workflow, /uploadedDocuments: "1217200537737052"/);
  assert.match(asana, /markDocumentsUploaded/);
  assert.match(manager, /Apply to all tasks for this vendor\?/);
  assert.match(manager, /Asana approval status chain/);
  assert.match(manager, /Select the tasks that apply/);
  assert.match(manager, /Documents uploaded/);
  assert.match(manager, /Documents missing/);
  assert.match(manager, /request\.uploadedDocuments\.length}<\/span>/);
  assert.match(manager, /request\.missingDocuments\.length}<\/span>/);
  assert.match(manager, /Move to status/);
  assert.match(manager, /ROLE_STAGE_TARGETS/);
  assert.match(access, /ROLE_STAGE_TARGETS\[access\.actionRole\]/);
  assert.doesNotMatch(access, /nextStage\(request\.stage\) === targetStage/);
  assert.match(attachmentsRoute, /same vendor/);
  assert.match(attachmentsRoute, /taskGids\.length > 25/);
});

test("ships the admin access ledger and server-side security controls", async () => {
  const [
    layout,
    page,
    accessPage,
    authStore,
    loginRoute,
    manager,
    worker,
    hosting,
    migration,
    envExample,
  ] = await Promise.all([
    readFile(new URL("../app/layout.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/access/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/lib/auth-store.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/api/auth/login/route.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/components/VendorClubManager.tsx", import.meta.url), "utf8"),
    readFile(new URL("../worker/index.ts", import.meta.url), "utf8"),
    readFile(new URL("../.openai/hosting.json", import.meta.url), "utf8"),
    readFile(
      new URL("../drizzle/0001_premium_jamie_braddock.sql", import.meta.url),
      "utf8",
    ),
    readFile(new URL("../.env.example", import.meta.url), "utf8"),
  ]);

  assert.match(layout, /Vendor Club Approval Manager/);
  assert.match(page, /getSessionFromCookieHeader/);
  assert.match(page, /redirect\("\/access"\)/);
  assert.match(accessPage, /AccessGate/);
  assert.match(accessPage, /getSessionFromCookieHeader/);
  assert.match(authStore, /crypto\.subtle\.sign\("HMAC"/);
  assert.match(authStore, /PBKDF2_ITERATIONS = 100_000/);
  assert.match(authStore, /iterations > PBKDF2_ITERATIONS/);
  assert.match(authStore, /pbkdf2-sha256/);
  assert.match(authStore, /derivedCodeHash\(email, normalizeCode\(code\), salt\)/);
  assert.match(authStore, /usedAdminRecovery/);
  assert.match(authStore, /created_by = 'system recovery'/);
  assert.match(authStore, /HttpOnly; SameSite=Lax/);
  assert.match(authStore, /MAX_ATTEMPTS = 5/);
  assert.match(authStore, /SESSION_TTL_SECONDS = 12 \* 60 \* 60/);
  assert.match(authStore, /Only the System Administrator can manage access/);
  assert.match(loginRoute, /Access sign-in failed/);
  assert.match(manager, /function AccessAdminView/);
  assert.match(manager, /Generate access code/);
  assert.match(manager, /Open email draft/);
  assert.match(manager, /Revoke/);
  assert.match(worker, /url\.pathname\.startsWith\("\/guides\/"\)/);
  assert.match(worker, /url\.pathname\.startsWith\("\/contracts\/"\)/);
  assert.match(hosting, /"d1": "DB"/);
  assert.match(migration, /CREATE TABLE `access_invites`/);
  assert.match(migration, /CREATE TABLE `access_sessions`/);
  assert.match(migration, /CREATE TABLE `access_attempts`/);
  assert.match(envExample, /^AUTH_PEPPER=$/m);
  assert.match(envExample, /^BOOTSTRAP_ADMIN_CODE=$/m);

  await access(new URL("../public/og-card.png", import.meta.url));
  await access(new URL("../public/favicon.svg", import.meta.url));
  await access(
    new URL(
      "../public/contracts/az-26-27-vendor-contract-template.docx",
      import.meta.url,
    ),
  );
});
